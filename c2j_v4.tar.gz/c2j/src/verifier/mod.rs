//! 검증 모듈
//!
//! 1. 컴파일 검증: 생성된 .java를 javac로 컴파일
//! 2. 실행 검증:   원본 .class와 생성 .class의 실행 결과 비교

use std::process::Command;
use std::path::{Path, PathBuf};
use std::fs;
use crate::utils::{Result, C2JError};

pub struct Verifier;

#[derive(Debug)]
pub struct VerifyResult {
    pub compile_ok: bool,
    pub runtime_ok: Option<bool>,
    pub compile_error: Option<String>,
    pub original_output: Option<String>,
    pub generated_output: Option<String>,
}

impl Verifier {
    /// javac 로 .java 컴파일 검증
    pub fn verify_compile(java_path: &Path) -> Result<VerifyResult> {
        let output = Command::new("javac")
            .arg("-encoding").arg("UTF-8")
            .arg("-source").arg("11")
            .arg("-target").arg("11")
            .arg(java_path)
            .output()
            .map_err(|e| C2JError::CompilationFailed(format!("javac not found: {}", e)))?;

        if output.status.success() {
            Ok(VerifyResult {
                compile_ok: true,
                runtime_ok: None,
                compile_error: None,
                original_output: None,
                generated_output: None,
            })
        } else {
            let err = String::from_utf8_lossy(&output.stderr).to_string();
            Ok(VerifyResult {
                compile_ok: false,
                runtime_ok: None,
                compile_error: Some(err),
                original_output: None,
                generated_output: None,
            })
        }
    }

    /// 원본 + 생성 .class의 main() 실행 결과 비교
    pub fn verify_runtime(
        original_class_dir: &Path,
        generated_class_dir: &Path,
        class_name: &str,
        args: &[&str],
    ) -> Result<VerifyResult> {
        let orig_out = Self::run_class(original_class_dir, class_name, args)?;
        let gen_out  = Self::run_class(generated_class_dir, class_name, args)?;

        let ok = orig_out == gen_out;
        Ok(VerifyResult {
            compile_ok: true,
            runtime_ok: Some(ok),
            compile_error: None,
            original_output: Some(orig_out),
            generated_output: Some(gen_out),
        })
    }

    fn run_class(class_dir: &Path, class_name: &str, args: &[&str]) -> Result<String> {
        let mut cmd = Command::new("java");
        cmd.arg("-cp").arg(class_dir).arg(class_name);
        for arg in args { cmd.arg(arg); }

        let output = cmd.output()
            .map_err(|e| C2JError::VerificationFailed(format!("java not found: {}", e)))?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();

        // 예외 발생 여부 포함
        Ok(format!("stdout:{}\nstderr:{}\nexit:{}", stdout, stderr, output.status.code().unwrap_or(-1)))
    }
}
