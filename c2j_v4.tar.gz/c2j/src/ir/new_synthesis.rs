//! new + dup + invokespecial <init> 합성
//!
//! JVM bytecode 패턴:
//!   new #Foo        → 스택: [uninit_ref]
//!   dup             → 스택: [uninit_ref, uninit_ref]
//!   (args...)
//!   invokespecial Foo.<init>(...)V  → 스택: [initialized_ref]
//!
//! 이를 하나의 IrExpr::NewObject(cls, args)로 합성합니다.
//!
//! super() / this() 패턴:
//!   aload_0
//!   (args...)
//!   invokespecial SuperClass.<init>(...)V
//! → super(args) 또는 this(args)

use crate::ir::{IrStmt, IrExpr};
use crate::analysis::stack::JvmType;

/// IrStmt 목록에서 new+dup+invokespecial 패턴을 찾아 NewObject로 합성
pub fn synthesize_new_objects(stmts: &mut Vec<IrStmt>) {
    let mut i = 0;
    while i < stmts.len() {
        // ExprStmt(SpecialCall(<init>)) 패턴 찾기
        if let IrStmt::ExprStmt(IrExpr::SpecialCall(obj, cls, mth, _, args, _)) = &stmts[i] {
            if mth == "<init>" {
                let cls = cls.clone();
                let args = args.clone();
                let obj = *obj.clone();

                // obj가 NewObject(cls, [])인지 확인 (new + dup이 만든 uninit ref)
                if let IrExpr::NewObject(new_cls, existing_args) = &obj {
                    if existing_args.is_empty() && new_cls == &cls {
                        // 패턴 발견! SpecialCall을 NewObject(cls, args)로 교체
                        let new_expr = IrExpr::NewObject(cls.clone(), args.clone());

                        // 앞의 Assign에서 이 uninit ref를 사용한 경우 교체
                        if let Some(assign_idx) = find_preceding_assign(stmts, i, &cls) {
                            if let IrStmt::Assign(name, ty, _) = &stmts[assign_idx] {
                                let name = name.clone();
                                let ty = ty.clone();
                                stmts[assign_idx] = IrStmt::Assign(name, ty, new_expr);
                                stmts.remove(i);
                                i = if i == 0 { 0 } else { i - 1 };
                                continue;
                            }
                        }
                        // 할당이 없으면 ExprStmt로 남김
                        stmts[i] = IrStmt::ExprStmt(new_expr);
                    }
                }

                // super()/this() 패턴: obj == This 또는 LocalVar("this", ...)
                if is_this_ref(&obj) {
                    let call = if cls.ends_with(&extract_own_class(&stmts, i)) {
                        // this() 호출
                        format_this_call(args.clone())
                    } else {
                        // super() 호출
                        format_super_call(args.clone())
                    };
                    stmts[i] = call;
                }
            }
        }
        i += 1;
    }
}

/// stmts[before_idx] 이전에서 NewObject(cls, []) 를 할당한 Assign 찾기
fn find_preceding_assign(stmts: &[IrStmt], before_idx: usize, cls: &str) -> Option<usize> {
    for j in (0..before_idx).rev() {
        if let IrStmt::Assign(_, _, IrExpr::NewObject(ncls, args)) = &stmts[j] {
            if ncls == cls && args.is_empty() {
                return Some(j);
            }
        }
    }
    None
}

fn is_this_ref(expr: &IrExpr) -> bool {
    matches!(expr, IrExpr::This)
        || matches!(expr, IrExpr::LocalVar(n, _) if n == "this")
}

fn extract_own_class(_stmts: &[IrStmt], _idx: usize) -> String {
    // 클래스 이름 추출은 상위 컨텍스트에서 전달받아야 함 — 여기서는 빈 문자열
    String::new()
}

fn format_super_call(args: Vec<IrExpr>) -> IrStmt {
    IrStmt::ExprStmt(IrExpr::SpecialCall(
        Box::new(IrExpr::This),
        "super".into(),
        "<init>".into(),
        String::new(),
        args,
        JvmType::Void,
    ))
}

fn format_this_call(args: Vec<IrExpr>) -> IrStmt {
    IrStmt::ExprStmt(IrExpr::SpecialCall(
        Box::new(IrExpr::This),
        "this".into(),
        "<init>".into(),
        String::new(),
        args,
        JvmType::Void,
    ))
}

/// 재귀적으로 IrStmt 내부의 NewObject를 완성
pub fn fix_new_in_expr(expr: &mut IrExpr) {
    match expr {
        IrExpr::VirtualCall(obj, _, _, _, args, _)
        | IrExpr::SpecialCall(obj, _, _, _, args, _)
        | IrExpr::InterfaceCall(obj, _, _, _, args, _) => {
            fix_new_in_expr(obj);
            for a in args.iter_mut() { fix_new_in_expr(a); }
        }
        IrExpr::StaticCall(_, _, _, args, _)
        | IrExpr::DynamicCall(_, _, args, _)
        | IrExpr::NewObject(_, args) => {
            for a in args.iter_mut() { fix_new_in_expr(a); }
        }
        IrExpr::BinaryOp(a, _, b, _) => {
            fix_new_in_expr(a); fix_new_in_expr(b);
        }
        IrExpr::UnaryOp(_, a, _) | IrExpr::Cast(a, _)
        | IrExpr::ArrayLength(a) | IrExpr::Checkcast(a, _)
        | IrExpr::InstanceOf(a, _) => { fix_new_in_expr(a); }
        IrExpr::ArrayAccess(a, b, _) => {
            fix_new_in_expr(a); fix_new_in_expr(b);
        }
        IrExpr::NewArray(_, sz) | IrExpr::InstanceField(sz, _, _, _) => {
            fix_new_in_expr(sz);
        }
        IrExpr::NewMultiArray(_, dims) => {
            for d in dims.iter_mut() { fix_new_in_expr(d); }
        }
        IrExpr::Ternary(c, t, f, _) => {
            fix_new_in_expr(c); fix_new_in_expr(t); fix_new_in_expr(f);
        }
        _ => {}
    }
}
