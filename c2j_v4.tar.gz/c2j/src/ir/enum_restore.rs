//! Java enum 완전 복원
//!
//! enum은 컴파일 시 다음과 같이 변환됩니다:
//!   - java.lang.Enum 상속 클래스
//!   - static final 필드들이 enum 상수
//!   - values() / valueOf() 정적 메서드
//!   - $VALUES 내부 배열
//!   - ordinal(), name() 은 Enum 상속
//!
//! 복원 전략:
//!   1. super_class == "java/lang/Enum" 감지
//!   2. static final 필드 중 타입이 클래스 자신인 것 → enum 상수
//!   3. $VALUES 필드 제거
//!   4. values()/valueOf() 자동 생성으로 처리
//!   5. <clinit>에서 enum 상수 초기화 추출

use crate::classfile::structures::{ClassFile, FieldInfo, MethodInfo, AccessFlags};
use crate::constantpool::ConstantPoolEntry;

/// enum 상수 정보
#[derive(Debug, Clone)]
pub struct EnumConstant {
    pub name: String,
    pub ordinal: u32,
    /// 생성자 인수 (name/ordinal 이후 추가 인수)
    pub extra_args: Vec<EnumArg>,
}

#[derive(Debug, Clone)]
pub enum EnumArg {
    Int(i32),
    Long(i64),
    Float(f32),
    Double(f64),
    String(String),
    Unknown,
}

/// enum 분석 결과
#[derive(Debug, Clone)]
pub struct EnumInfo {
    pub constants: Vec<EnumConstant>,
    /// 추가 생성자 파라미터 타입 (name/ordinal 제외)
    pub extra_param_types: Vec<String>,
    /// enum에 추가 필드가 있는지
    pub has_extra_fields: bool,
    /// enum body 메서드 (values/valueOf 제외)
    pub has_abstract_methods: bool,
}

/// ClassFile이 enum인지 판단
pub fn is_enum_class(
    class_file: &ClassFile,
    cp: &Vec<Option<ConstantPoolEntry>>,
) -> bool {
    if !class_file.access_flags.is_enum() { return false; }

    // super_class가 java/lang/Enum인지 확인
    if class_file.super_class == 0 { return false; }
    if let Some(Some(ConstantPoolEntry::Class(ni))) = cp.get(class_file.super_class as usize) {
        if let Some(Some(ConstantPoolEntry::Utf8(name))) = cp.get(*ni as usize) {
            return name == "java/lang/Enum";
        }
    }
    false
}

/// enum 상수 추출
pub fn extract_enum_constants(
    class_file: &ClassFile,
    cp: &Vec<Option<ConstantPoolEntry>>,
) -> EnumInfo {
    let this_class_name = get_class_name(cp, class_file.this_class);

    let mut constants: Vec<EnumConstant> = Vec::new();
    let mut extra_fields = false;

    // static final 필드 중 타입이 자신인 것 → enum 상수
    for field in &class_file.fields {
        let flags = field.access_flags;
        if !flags.is_static() || !flags.is_final() { continue; }

        let desc = get_utf8(cp, field.descriptor_index).unwrap_or("").to_string();
        let name = get_utf8(cp, field.name_index).unwrap_or("").to_string();

        // $VALUES나 내부 배열 필드 건너뜀
        if name.starts_with('$') || name == "ENUM$VALUES" { continue; }

        // 타입이 자신(L{className};)인지 확인
        let expected = format!("L{};", this_class_name);
        if desc == expected {
            constants.push(EnumConstant {
                name: name.clone(),
                ordinal: constants.len() as u32,
                extra_args: Vec::new(),
            });
        } else if !name.contains("$") {
            extra_fields = true;
        }
    }

    // <clinit>에서 enum 상수 초기화 인수 추출 시도
    for method in &class_file.methods {
        let mname = get_utf8(cp, method.name_index).unwrap_or("");
        if mname != "<clinit>" { continue; }
        // 실제 인수 추출은 bytecode 분석 필요 — 여기서는 이름만 확인
        break;
    }

    // 추상 메서드 감지 (enum body)
    let has_abstract = class_file.methods.iter().any(|m| m.access_flags.is_abstract());

    // 생성자 파라미터 분석 (<init> descriptor)
    let extra_params = class_file.methods.iter()
        .filter(|m| get_utf8(cp, m.name_index).unwrap_or("") == "<init>")
        .find_map(|m| {
            let desc = get_utf8(cp, m.descriptor_index).unwrap_or("");
            // (Ljava/lang/String;I...) 에서 첫 두 파라미터(String, int) 이후
            extract_extra_params(desc)
        })
        .unwrap_or_default();

    EnumInfo {
        constants,
        extra_param_types: extra_params,
        has_extra_fields: extra_fields,
        has_abstract_methods: has_abstract,
    }
}

/// enum 선언 Java 소스 생성
pub fn gen_enum_declaration(
    class_name: &str,
    info: &EnumInfo,
    interfaces: &[String],
    body_fields: &str,
    body_methods: &str,
) -> String {
    let mut out = String::new();

    // implements
    let impl_str = if interfaces.is_empty() {
        String::new()
    } else {
        format!(" implements {}", interfaces.join(", "))
    };

    out.push_str(&format!("public enum {}{} {{\n", class_name, impl_str));

    // enum 상수들
    if info.constants.is_empty() {
        out.push_str("    ;\n");
    } else {
        let consts: Vec<String> = info.constants.iter().map(|c| {
            if c.extra_args.is_empty() {
                c.name.clone()
            } else {
                let args: Vec<String> = c.extra_args.iter().map(|a| match a {
                    EnumArg::Int(n)    => n.to_string(),
                    EnumArg::Long(n)   => format!("{}L", n),
                    EnumArg::Float(f)  => format!("{}f", f),
                    EnumArg::Double(d) => format!("{}d", d),
                    EnumArg::String(s) => format!("\"{}\"", s),
                    EnumArg::Unknown   => "/* ? */".into(),
                }).collect();
                format!("{}({})", c.name, args.join(", "))
            }
        }).collect();

        // 상수가 많으면 여러 줄로
        if consts.len() > 4 {
            out.push_str("    ");
            out.push_str(&consts.join(",\n    "));
            out.push_str(";\n");
        } else {
            out.push_str("    ");
            out.push_str(&consts.join(", "));
            out.push_str(";\n");
        }
    }

    // 추가 필드
    if !body_fields.is_empty() {
        out.push('\n');
        for line in body_fields.lines() {
            out.push_str("    ");
            out.push_str(line);
            out.push('\n');
        }
    }

    // 메서드 (values/valueOf 제외)
    if !body_methods.is_empty() {
        out.push('\n');
        for line in body_methods.lines() {
            out.push_str("    ");
            out.push_str(line);
            out.push('\n');
        }
    }

    out.push('}');
    out
}

// ─── 유틸리티 ──────────────────────────────────────────────────────────────

fn get_utf8(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<&str> {
    cp.get(idx as usize)?.as_ref().and_then(|e| {
        if let ConstantPoolEntry::Utf8(s) = e { Some(s.as_str()) } else { None }
    })
}

fn get_class_name(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> String {
    if let Some(Some(ConstantPoolEntry::Class(ni))) = cp.get(idx as usize) {
        get_utf8(cp, *ni).unwrap_or("?").to_string()
    } else { "?".into() }
}

fn extract_extra_params(desc: &str) -> Option<Vec<String>> {
    // "(Ljava/lang/String;I...)..." 패턴 파싱
    let inner = desc.strip_prefix('(')?.split(')').next()?;
    use crate::analysis::types::parse_type_sequence;
    use crate::analysis::stack::JvmType;
    use crate::analysis::types::jvm_type_to_java;

    let all = parse_type_sequence(inner);
    if all.len() <= 2 { return Some(Vec::new()); }

    // 첫 두 파라미터(String, int)는 name/ordinal이므로 제외
    let extra: Vec<String> = all[2..].iter()
        .map(|t| jvm_type_to_java(t, true))
        .collect();

    Some(extra)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_enum_constant_gen_simple() {
        let info = EnumInfo {
            constants: vec![
                EnumConstant { name: "MONDAY".into(), ordinal: 0, extra_args: vec![] },
                EnumConstant { name: "TUESDAY".into(), ordinal: 1, extra_args: vec![] },
                EnumConstant { name: "WEDNESDAY".into(), ordinal: 2, extra_args: vec![] },
            ],
            extra_param_types: vec![],
            has_extra_fields: false,
            has_abstract_methods: false,
        };
        let src = gen_enum_declaration("Day", &info, &[], "", "");
        assert!(src.contains("MONDAY"), "MONDAY 누락");
        assert!(src.contains("TUESDAY"), "TUESDAY 누락");
        assert!(src.starts_with("public enum Day"), "선언 오류: {}", src);
        assert!(src.contains(';'), "세미콜론 누락");
    }

    #[test]
    fn test_enum_with_args() {
        let info = EnumInfo {
            constants: vec![
                EnumConstant {
                    name: "SMALL".into(), ordinal: 0,
                    extra_args: vec![EnumArg::Int(1)],
                },
                EnumConstant {
                    name: "LARGE".into(), ordinal: 1,
                    extra_args: vec![EnumArg::Int(10)],
                },
            ],
            extra_param_types: vec!["int".into()],
            has_extra_fields: true,
            has_abstract_methods: false,
        };
        let src = gen_enum_declaration("Size", &info, &[], "", "");
        assert!(src.contains("SMALL(1)"), "SMALL(1) 누락: {}", src);
        assert!(src.contains("LARGE(10)"), "LARGE(10) 누락");
    }
}
