//! Java 15+ Text Block 복원
//!
//! Text block은 컴파일 시 일반 String 상수로 변환됩니다.
//! ldc 명령어로 로드되는 String 중 \n을 포함하고 여러 줄인 경우
//! text block 형태로 복원합니다.
//!
//! 원본:
//!   String s = """
//!       Hello,
//!       World!
//!       """;
//!
//! 컴파일 후:
//!   ldc "Hello,\nWorld!\n"
//!
//! 복원:
//!   String s = """
//!       Hello,
//!       World!
//!       """;

/// String 리터럴이 text block으로 복원 가능한지 판단하고
/// 가능하면 text block 형태의 Java 소스 문자열을 반환합니다.
pub fn try_text_block(s: &str) -> Option<String> {
    // 조건: 개행 문자가 2개 이상 포함된 경우
    let newline_count = s.chars().filter(|&c| c == '\n').count();
    if newline_count < 2 {
        return None;
    }

    // 각 줄로 분리
    let lines: Vec<&str> = s.split('\n').collect();

    // 공통 들여쓰기(indent) 계산 — 빈 줄 제외
    let common_indent = lines.iter()
        .filter(|l| !l.trim().is_empty())
        .map(|l| l.len() - l.trim_start().len())
        .min()
        .unwrap_or(0);

    // text block 생성
    let mut out = String::new();
    out.push_str("\"\"\"\n");

    for line in &lines {
        if line.trim().is_empty() {
            out.push('\n');
        } else {
            // 공통 indent 제거 후 표준 4-space 들여쓰기 추가
            let stripped = if line.len() >= common_indent {
                &line[common_indent..]
            } else {
                line.trim_start()
            };
            out.push_str("    ");
            out.push_str(stripped);
            out.push('\n');
        }
    }

    // 마지막 줄이 빈 줄이면 closing """ 앞에 위치
    out.push_str("    \"\"\"");

    Some(out)
}

/// String 리터럴을 최적의 Java 표현으로 변환
/// - 여러 줄 → text block (Java 15+)
/// - 한 줄 → 일반 "..." 리터럴
pub fn string_to_java_literal(s: &str, use_text_block: bool) -> String {
    if use_text_block {
        if let Some(tb) = try_text_block(s) {
            return tb;
        }
    }
    // 일반 리터럴
    format!("\"{}\"", escape_java_string(s))
}

/// Java String 이스케이프
pub fn escape_java_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '"'  => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\x08' => out.push_str("\\b"),
            '\x0C' => out.push_str("\\f"),
            c if (c as u32) < 0x20 || c as u32 == 0x7F => {
                out.push_str(&format!("\\u{:04X}", c as u32));
            }
            c => out.push(c),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_single_line_no_text_block() {
        let result = try_text_block("Hello, World!");
        assert!(result.is_none());
    }

    #[test]
    fn test_one_newline_no_text_block() {
        let result = try_text_block("Hello\nWorld");
        assert!(result.is_none(), "개행 1개는 text block 아님");
    }

    #[test]
    fn test_multiline_text_block() {
        let s = "SELECT *\nFROM users\nWHERE id = 1\n";
        let result = try_text_block(s);
        assert!(result.is_some());
        let tb = result.unwrap();
        assert!(tb.starts_with("\"\"\""), "text block 시작 없음: {}", tb);
        assert!(tb.contains("SELECT *"), "내용 누락: {}", tb);
        assert!(tb.ends_with("\"\"\""), "text block 종료 없음: {}", tb);
    }

    #[test]
    fn test_json_text_block() {
        let json = "{\n  \"name\": \"C2J\",\n  \"version\": \"1.0\"\n}\n";
        let result = try_text_block(json);
        assert!(result.is_some());
    }

    #[test]
    fn test_escape_java_string() {
        assert_eq!(escape_java_string("Hello \"World\""), "Hello \\\"World\\\"");
        assert_eq!(escape_java_string("line1\nline2"), "line1\\nline2");
        assert_eq!(escape_java_string("tab\there"), "tab\\there");
    }

    #[test]
    fn test_string_to_java_literal_single() {
        let result = string_to_java_literal("hello", true);
        assert_eq!(result, "\"hello\"");
    }

    #[test]
    fn test_string_to_java_literal_multiline() {
        let s = "line1\nline2\nline3\n";
        let result = string_to_java_literal(s, true);
        assert!(result.starts_with("\"\"\""), "text block 기대: {}", result);
    }
}
