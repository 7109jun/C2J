//! Java 21 Pattern Switch 복원
//!
//! Java 21에서 switch 표현식/문의 패턴 매칭은 invokedynamic +
//! typeSwitch / enumSwitch bootstrap method로 컴파일됩니다.
//!
//! 패턴:
//!   invokedynamic #N "typeSwitch" "(...)[I"  → 패턴 인덱스 반환
//!   tableswitch/lookupswitch                  → 분기
//!   instanceof / checkcast                    → 각 패턴 블록
//!
//! 복원:
//!   switch (obj) {
//!       case Integer i -> ...
//!       case String s  -> ...
//!       case null      -> ...
//!       default        -> ...
//!   }

use crate::constantpool::{ConstantPool, ConstantPoolEntry};
use crate::ir::{IrExpr, IrStmt};
use crate::analysis::stack::JvmType;
use crate::analysis::types::simple_class_name;

/// 패턴 switch의 단일 케이스
#[derive(Debug, Clone)]
pub enum PatternCase {
    TypePattern(String, String),    // (type, binding_var)  e.g. Integer i
    NullPattern,                    // case null
    GuardedPattern(Box<PatternCase>, IrExpr),  // pattern when guard
    Constant(IrExpr),              // 상수 패턴 (기존 switch와 동일)
    Default,
}

/// 패턴 switch 전체
#[derive(Debug, Clone)]
pub struct PatternSwitch {
    pub selector: IrExpr,
    pub cases: Vec<(PatternCase, Vec<IrStmt>)>,
    pub is_expression: bool,       // switch 식인지 문인지
    pub result_type: Option<JvmType>,
}

/// invokedynamic 이름으로 패턴 switch인지 판단
pub fn is_type_switch_indy(name: &str) -> bool {
    matches!(name, "typeSwitch" | "enumSwitch" | "switchTable")
}

/// PatternSwitch → Java 21 소스 문자열
pub fn gen_pattern_switch(ps: &PatternSwitch, indent: &str) -> String {
    let mut out = String::new();
    let inner = format!("{}    ", indent);

    if ps.is_expression {
        out.push_str(&format!("{}switch ({}) {{\n", indent, gen_expr_simple(&ps.selector)));
    } else {
        out.push_str(&format!("{}switch ({}) {{\n", indent, gen_expr_simple(&ps.selector)));
    }

    for (pattern, stmts) in &ps.cases {
        let case_label = match pattern {
            PatternCase::TypePattern(ty, var) =>
                format!("case {} {}", simple_class_name(ty), var),
            PatternCase::NullPattern =>
                "case null".into(),
            PatternCase::GuardedPattern(p, guard) => {
                let base = match p.as_ref() {
                    PatternCase::TypePattern(ty, var) =>
                        format!("case {} {}", simple_class_name(ty), var),
                    _ => "case _".into(),
                };
                format!("{} when {}", base, gen_expr_simple(guard))
            }
            PatternCase::Constant(e) =>
                format!("case {}", gen_expr_simple(e)),
            PatternCase::Default =>
                "default".into(),
        };

        if ps.is_expression {
            // switch 식: case X -> expr
            out.push_str(&format!("{}    {} -> {{\n", indent, case_label));
            for s in stmts {
                out.push_str(&format!("{}        /* stmt */\n", indent));
            }
            out.push_str(&format!("{}    }}\n", indent));
        } else {
            // switch 문: case X: stmts
            out.push_str(&format!("{}    {}:\n", indent, case_label));
            for _ in stmts {
                out.push_str(&format!("{}        /* stmt */\n", indent));
            }
        }
    }

    out.push_str(&format!("{}}}\n", indent));
    out
}

fn gen_expr_simple(expr: &IrExpr) -> String {
    match expr {
        IrExpr::LocalVar(n, _) => n.clone(),
        IrExpr::This => "this".into(),
        IrExpr::IntLit(n) => n.to_string(),
        IrExpr::StringLit(s) => format!("\"{}\"", s),
        IrExpr::Null => "null".into(),
        _ => "/*expr*/".into(),
    }
}

/// Bytecode에서 typeSwitch 패턴 감지
/// invokedynamic "typeSwitch" 직후의 tableswitch 구조를 분석
pub fn detect_pattern_switch_from_stmts(stmts: &[IrStmt]) -> Option<PatternSwitch> {
    // typeSwitch indy → int 결과 → switch
    // 패턴: ExprStmt(DynamicCall("typeSwitch",...)) 다음에 Switch가 오면 감지
    for i in 0..stmts.len() {
        if let IrStmt::Switch(key, cases, default_pc) = &stmts[i] {
            // key가 DynamicCall("typeSwitch", ...) 이면 패턴 switch
            if let IrExpr::DynamicCall(name, _, args, _) = key {
                if is_type_switch_indy(name) && !args.is_empty() {
                    let selector = args[0].clone();
                    // 각 case에 TypePattern 할당 (타입 정보는 CP에서 복원 필요)
                    let pattern_cases: Vec<(PatternCase, Vec<IrStmt>)> = cases.iter()
                        .enumerate()
                        .map(|(idx, (val, _pc))| {
                            let pat = PatternCase::TypePattern(
                                format!("Type{}", idx),
                                format!("p{}", idx),
                            );
                            (pat, Vec::new())
                        })
                        .collect();

                    return Some(PatternSwitch {
                        selector,
                        cases: pattern_cases,
                        is_expression: false,
                        result_type: None,
                    });
                }
            }
        }
    }
    None
}
