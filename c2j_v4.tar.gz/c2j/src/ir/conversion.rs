//! Bytecode → IR 변환
//!
//! CFG의 각 Basic Block을 순회하며 스택 분석 결과를 이용해
//! 스택 기반 bytecode를 변수 기반 IrStmt 목록으로 변환합니다.

use std::collections::HashMap;
use crate::bytecode::instruction::Opcode;
use crate::bytecode::decoder::{Instruction, InstructionOperand};
use crate::analysis::cfg::{ControlFlowGraph, EdgeKind};
use crate::analysis::stack::{JvmType, StackAnalyzer, ValueSource, ConstantValue};
use crate::analysis::locals::LocalVarAnalysis;
use crate::analysis::types::{parse_method_descriptor, jvm_type_to_java, simple_class_name};
use crate::constantpool::{ConstantPool, ConstantPoolEntry};
use crate::ir::{IrStmt, IrExpr, BinaryOp, UnaryOp, CompareOp};
use crate::utils::{Result, C2JError};

pub struct IrBuilder<'a> {
    cp: &'a ConstantPool,
    locals: &'a LocalVarAnalysis,
    temp_counter: u32,
    // PC → IrExpr 스택 (스택을 임시변수로 flatten)
    stack: Vec<IrExpr>,
}

impl<'a> IrBuilder<'a> {
    pub fn new(cp: &'a ConstantPool, locals: &'a LocalVarAnalysis) -> Self {
        IrBuilder { cp, locals, temp_counter: 0, stack: Vec::new() }
    }

    fn fresh_temp(&mut self, ty: JvmType) -> (String, JvmType) {
        let name = format!("_t{}", self.temp_counter);
        self.temp_counter += 1;
        (name, ty)
    }

    fn pop(&mut self) -> IrExpr {
        self.stack.pop().unwrap_or(IrExpr::Null)
    }

    fn push(&mut self, expr: IrExpr) {
        self.stack.push(expr);
    }

    fn peek(&self) -> Option<&IrExpr> {
        self.stack.last()
    }

    /// 단일 Basic Block → IrStmt 목록
    pub fn convert_block(&mut self, instrs: &[Instruction]) -> Result<Vec<IrStmt>> {
        let mut stmts: Vec<IrStmt> = Vec::new();
        self.stack.clear();

        for instr in instrs {
            let pc = instr.pc;
            self.convert_instr(instr, pc, &mut stmts)?;
        }

        Ok(stmts)
    }

    fn convert_instr(&mut self, instr: &Instruction, pc: u32, out: &mut Vec<IrStmt>) -> Result<()> {
        use Opcode::*;

        match &instr.opcode {
            // ── NOP ───────────────────────────────────────────────────────
            Nop | Breakpoint => {}

            // ── 상수 push ──────────────────────────────────────────────────
            AconstNull => self.push(IrExpr::Null),
            IconstM1   => self.push(IrExpr::IntLit(-1)),
            Iconst0    => self.push(IrExpr::IntLit(0)),
            Iconst1    => self.push(IrExpr::IntLit(1)),
            Iconst2    => self.push(IrExpr::IntLit(2)),
            Iconst3    => self.push(IrExpr::IntLit(3)),
            Iconst4    => self.push(IrExpr::IntLit(4)),
            Iconst5    => self.push(IrExpr::IntLit(5)),
            Lconst0    => self.push(IrExpr::LongLit(0)),
            Lconst1    => self.push(IrExpr::LongLit(1)),
            Fconst0    => self.push(IrExpr::FloatLit(0.0)),
            Fconst1    => self.push(IrExpr::FloatLit(1.0)),
            Fconst2    => self.push(IrExpr::FloatLit(2.0)),
            Dconst0    => self.push(IrExpr::DoubleLit(0.0)),
            Dconst1    => self.push(IrExpr::DoubleLit(1.0)),

            Bipush | Sipush => {
                if let InstructionOperand::IntValue(n) = instr.operands {
                    self.push(IrExpr::IntLit(n));
                }
            }

            Ldc | LdcW | Ldc2W => {
                let expr = self.ldc_expr(&instr.operands)?;
                self.push(expr);
            }

            // ── Load (로컬 → 스택) ─────────────────────────────────────────
            Iload | Iload0 | Iload1 | Iload2 | Iload3 => {
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                self.push(IrExpr::LocalVar(name, JvmType::Int));
            }
            Lload | Lload0 | Lload1 | Lload2 | Lload3 => {
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                self.push(IrExpr::LocalVar(name, JvmType::Long));
            }
            Fload | Fload0 | Fload1 | Fload2 | Fload3 => {
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                self.push(IrExpr::LocalVar(name, JvmType::Float));
            }
            Dload | Dload0 | Dload1 | Dload2 | Dload3 => {
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                self.push(IrExpr::LocalVar(name, JvmType::Double));
            }
            Aload | Aload0 | Aload1 | Aload2 | Aload3 => {
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                if slot == 0 && !self.locals.is_static {
                    self.push(IrExpr::This);
                } else {
                    let name = self.locals.get_name(slot, pc);
                    let ty = self.locals.get_type(slot, pc);
                    self.push(IrExpr::LocalVar(name, ty));
                }
            }

            // ── Array Load ─────────────────────────────────────────────────
            Iaload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Int)); }
            Laload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Long)); }
            Faload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Float)); }
            Daload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Double)); }
            Aaload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Reference(None))); }
            Baload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Byte)); }
            Caload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Char)); }
            Saload => { let idx = self.pop(); let arr = self.pop(); self.push(IrExpr::ArrayAccess(Box::new(arr), Box::new(idx), JvmType::Short)); }

            // ── Store (스택 → 로컬) ────────────────────────────────────────
            Istore | Istore0 | Istore1 | Istore2 | Istore3 => {
                let val = self.pop();
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                out.push(IrStmt::Assign(name, JvmType::Int, val));
            }
            Lstore | Lstore0 | Lstore1 | Lstore2 | Lstore3 => {
                let val = self.pop();
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                out.push(IrStmt::Assign(name, JvmType::Long, val));
            }
            Fstore | Fstore0 | Fstore1 | Fstore2 | Fstore3 => {
                let val = self.pop();
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                out.push(IrStmt::Assign(name, JvmType::Float, val));
            }
            Dstore | Dstore0 | Dstore1 | Dstore2 | Dstore3 => {
                let val = self.pop();
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                out.push(IrStmt::Assign(name, JvmType::Double, val));
            }
            Astore | Astore0 | Astore1 | Astore2 | Astore3 => {
                let val = self.pop();
                let slot = self.slot_of(&instr.opcode, &instr.operands);
                let name = self.locals.get_name(slot, pc);
                let ty = val.get_type();
                out.push(IrStmt::Assign(name, ty, val));
            }

            // ── Array Store ────────────────────────────────────────────────
            Iastore | Lastore | Fastore | Dastore | Aastore | Bastore | Castore | Sastore => {
                let val = self.pop(); let idx = self.pop(); let arr = self.pop();
                out.push(IrStmt::ArrayStore(arr, idx, val));
            }

            // ── Stack ops ─────────────────────────────────────────────────
            Pop => { self.pop_as_stmt(out); }
            Pop2 => { self.pop_as_stmt(out); self.pop_as_stmt(out); }

            Dup => {
                let v = self.peek().cloned().unwrap_or(IrExpr::Null);
                // 중요: 부작용 있는 식은 임시변수로 분리
                if self.has_side_effects(&v) {
                    let ty = v.get_type();
                    let (tmp, _) = self.fresh_temp(ty.clone());
                    out.push(IrStmt::Assign(tmp.clone(), ty.clone(), self.pop()));
                    let var = IrExpr::LocalVar(tmp.clone(), ty.clone());
                    self.push(var.clone());
                    self.push(var);
                } else {
                    self.push(v);
                }
            }

            DupX1 => {
                let v1 = self.pop(); let v2 = self.pop();
                let (t1, ty1) = self.fresh_temp(v1.get_type());
                out.push(IrStmt::Assign(t1.clone(), ty1.clone(), v1));
                let vref = IrExpr::LocalVar(t1, ty1);
                self.push(vref.clone()); self.push(v2); self.push(vref);
            }
            DupX2 => {
                let v1 = self.pop(); let v2 = self.pop(); let v3 = self.pop();
                let (t1, ty1) = self.fresh_temp(v1.get_type());
                out.push(IrStmt::Assign(t1.clone(), ty1.clone(), v1));
                let vref = IrExpr::LocalVar(t1, ty1);
                self.push(vref.clone()); self.push(v3); self.push(v2); self.push(vref);
            }
            Dup2 => {
                let v1 = self.pop(); let v2 = self.pop();
                let (t1, ty1) = self.fresh_temp(v1.get_type());
                let (t2, ty2) = self.fresh_temp(v2.get_type());
                out.push(IrStmt::Assign(t2.clone(), ty2.clone(), v2));
                out.push(IrStmt::Assign(t1.clone(), ty1.clone(), v1));
                let r1 = IrExpr::LocalVar(t1, ty1);
                let r2 = IrExpr::LocalVar(t2, ty2);
                self.push(r2.clone()); self.push(r1.clone());
                self.push(r2); self.push(r1);
            }
            Dup2X1 => {
                let v1 = self.pop(); let v2 = self.pop(); let v3 = self.pop();
                let (t1, ty1) = self.fresh_temp(v1.get_type());
                let (t2, ty2) = self.fresh_temp(v2.get_type());
                out.push(IrStmt::Assign(t2.clone(), ty2.clone(), v2));
                out.push(IrStmt::Assign(t1.clone(), ty1.clone(), v1));
                let r1 = IrExpr::LocalVar(t1, ty1);
                let r2 = IrExpr::LocalVar(t2, ty2);
                self.push(r2.clone()); self.push(r1.clone());
                self.push(v3); self.push(r2); self.push(r1);
            }
            Dup2X2 => {
                let v1 = self.pop(); let v2 = self.pop();
                let v3 = self.pop(); let v4 = self.pop();
                self.push(v2.clone()); self.push(v1.clone());
                self.push(v4); self.push(v3); self.push(v2); self.push(v1);
            }
            Swap => { let a = self.pop(); let b = self.pop(); self.push(a); self.push(b); }

            // ── 산술 ──────────────────────────────────────────────────────
            Iadd | Isub | Imul | Idiv | Irem | Iand | Ior | Ixor | Ishl | Ishr | Iushr => {
                let b = self.pop(); let a = self.pop();
                let op = Self::int_binop(&instr.opcode);
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Int));
            }
            Ladd | Lsub | Lmul | Ldiv | Lrem | Land | Lor | Lxor | Lshl | Lshr | Lushr => {
                let b = self.pop(); let a = self.pop();
                let op = Self::long_binop(&instr.opcode);
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Long));
            }
            Fadd | Fsub | Fmul | Fdiv | Frem => {
                let b = self.pop(); let a = self.pop();
                let op = Self::float_binop(&instr.opcode);
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Float));
            }
            Dadd | Dsub | Dmul | Ddiv | Drem => {
                let b = self.pop(); let a = self.pop();
                let op = Self::double_binop(&instr.opcode);
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Double));
            }
            Ineg => { let a = self.pop(); self.push(IrExpr::UnaryOp(UnaryOp::Neg, Box::new(a), JvmType::Int)); }
            Lneg => { let a = self.pop(); self.push(IrExpr::UnaryOp(UnaryOp::Neg, Box::new(a), JvmType::Long)); }
            Fneg => { let a = self.pop(); self.push(IrExpr::UnaryOp(UnaryOp::Neg, Box::new(a), JvmType::Float)); }
            Dneg => { let a = self.pop(); self.push(IrExpr::UnaryOp(UnaryOp::Neg, Box::new(a), JvmType::Double)); }

            Iinc => {
                if let InstructionOperand::LocalVarIndexAndConst(slot, delta) = instr.operands {
                    let name = self.locals.get_name(slot, pc);
                    out.push(IrStmt::Iinc(name, delta));
                }
            }

            // ── 형 변환 ───────────────────────────────────────────────────
            I2l => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Long)); }
            I2f => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Float)); }
            I2d => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Double)); }
            L2i => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Int)); }
            L2f => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Float)); }
            L2d => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Double)); }
            F2i => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Int)); }
            F2l => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Long)); }
            F2d => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Double)); }
            D2i => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Int)); }
            D2l => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Long)); }
            D2f => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Float)); }
            I2b => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Byte)); }
            I2c => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Char)); }
            I2s => { let a = self.pop(); self.push(IrExpr::Cast(Box::new(a), JvmType::Short)); }

            // ── 비교 (→ int) ──────────────────────────────────────────────
            Lcmp => {
                let b = self.pop(); let a = self.pop();
                self.push(IrExpr::BinaryOp(Box::new(a), BinaryOp::LCmp, Box::new(b), JvmType::Int));
            }
            Fcmpl | Fcmpg => {
                let b = self.pop(); let a = self.pop();
                let op = if instr.opcode == Fcmpl { BinaryOp::FCmpL } else { BinaryOp::FCmpG };
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Int));
            }
            Dcmpl | Dcmpg => {
                let b = self.pop(); let a = self.pop();
                let op = if instr.opcode == Dcmpl { BinaryOp::DCmpL } else { BinaryOp::DCmpG };
                self.push(IrExpr::BinaryOp(Box::new(a), op, Box::new(b), JvmType::Int));
            }

            // ── 조건 분기 ─────────────────────────────────────────────────
            Ifeq | Ifne | Iflt | Ifge | Ifgt | Ifle => {
                let a = self.pop();
                let (cmp_op, zero) = Self::if_unary_cmp(&instr.opcode);
                let cond = IrExpr::CompareOp(Box::new(a), cmp_op, Box::new(IrExpr::IntLit(0)));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }
            IfIcmpeq | IfIcmpne | IfIcmplt | IfIcmpge | IfIcmpgt | IfIcmple => {
                let b = self.pop(); let a = self.pop();
                let cmp_op = Self::if_icmp_op(&instr.opcode);
                let cond = IrExpr::CompareOp(Box::new(a), cmp_op, Box::new(b));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }
            IfAcmpeq => {
                let b = self.pop(); let a = self.pop();
                let cond = IrExpr::CompareOp(Box::new(a), CompareOp::RefEq, Box::new(b));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }
            IfAcmpne => {
                let b = self.pop(); let a = self.pop();
                let cond = IrExpr::CompareOp(Box::new(a), CompareOp::RefNe, Box::new(b));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }
            Ifnull => {
                let a = self.pop();
                let cond = IrExpr::CompareOp(Box::new(a), CompareOp::Null, Box::new(IrExpr::Null));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }
            Ifnonnull => {
                let a = self.pop();
                let cond = IrExpr::CompareOp(Box::new(a), CompareOp::NotNull, Box::new(IrExpr::Null));
                let target = self.branch_target(instr);
                out.push(IrStmt::If(cond, target, None));
            }

            // ── 무조건 분기 ───────────────────────────────────────────────
            Goto | GotoW => {
                let target = self.branch_target(instr);
                out.push(IrStmt::Goto(target));
            }

            // ── Switch ─────────────────────────────────────────────────────
            Tableswitch => {
                let key = self.pop();
                if let InstructionOperand::TableSwitch { default_offset, low, offsets, .. } = &instr.operands {
                    let def_pc = (instr.pc as i64 + *default_offset as i64) as u32;
                    let cases: Vec<(i32, u32)> = offsets.iter().enumerate().map(|(i, off)| {
                        let match_val = *low + i as i32;
                        let target = (instr.pc as i64 + *off as i64) as u32;
                        (match_val, target)
                    }).collect();
                    out.push(IrStmt::Switch(key, cases, def_pc));
                }
            }
            Lookupswitch => {
                let key = self.pop();
                if let InstructionOperand::LookupSwitch { default_offset, pairs } = &instr.operands {
                    let def_pc = (instr.pc as i64 + *default_offset as i64) as u32;
                    let cases: Vec<(i32, u32)> = pairs.iter().map(|(mv, off)| {
                        (*mv, (instr.pc as i64 + *off as i64) as u32)
                    }).collect();
                    out.push(IrStmt::Switch(key, cases, def_pc));
                }
            }

            // ── 반환 ──────────────────────────────────────────────────────
            Ireturn | Lreturn | Freturn | Dreturn | Areturn => {
                let v = self.pop();
                out.push(IrStmt::Return(Some(v)));
            }
            Return => { out.push(IrStmt::Return(None)); }
            Athrow => {
                let v = self.pop();
                out.push(IrStmt::Throw(v));
            }

            // ── 필드 ──────────────────────────────────────────────────────
            Getstatic => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, fld, ty) = self.resolve_fieldref(idx);
                    self.push(IrExpr::StaticField(cls, fld, ty));
                }
            }
            Putstatic => {
                let val = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, fld, _ty) = self.resolve_fieldref(idx);
                    out.push(IrStmt::FieldPut(None, cls, fld, val, true));
                }
            }
            Getfield => {
                let obj = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, fld, ty) = self.resolve_fieldref(idx);
                    self.push(IrExpr::InstanceField(Box::new(obj), cls, fld, ty));
                }
            }
            Putfield => {
                let val = self.pop(); let obj = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, fld, _ty) = self.resolve_fieldref(idx);
                    out.push(IrStmt::FieldPut(Some(obj), cls, fld, val, false));
                }
            }

            // ── 메서드 호출 ───────────────────────────────────────────────
            Invokevirtual => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, mth, desc) = self.resolve_methodref(idx);
                    let (params, ret) = parse_method_descriptor(&desc);
                    let mut args: Vec<IrExpr> = (0..params.len()).map(|_| self.pop()).collect();
                    args.reverse();
                    let obj = self.pop();
                    let expr = IrExpr::VirtualCall(Box::new(obj), cls, mth, desc, args, ret.clone());
                    if ret == JvmType::Void { out.push(IrStmt::ExprStmt(expr)); }
                    else { self.push(expr); }
                }
            }
            Invokespecial => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, mth, desc) = self.resolve_methodref(idx);
                    let (params, ret) = parse_method_descriptor(&desc);
                    let mut args: Vec<IrExpr> = (0..params.len()).map(|_| self.pop()).collect();
                    args.reverse();
                    let obj = self.pop();
                    if mth == "<init>" {
                        // 생성자: new Object(...) 패턴
                        // obj은 이미 스택에 dup된 uninit ref
                        let expr = IrExpr::SpecialCall(Box::new(obj), cls.clone(), mth, desc, args, JvmType::Void);
                        out.push(IrStmt::ExprStmt(expr));
                    } else {
                        let expr = IrExpr::SpecialCall(Box::new(obj), cls, mth, desc, args, ret.clone());
                        if ret == JvmType::Void { out.push(IrStmt::ExprStmt(expr)); }
                        else { self.push(expr); }
                    }
                }
            }
            Invokestatic => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (cls, mth, desc) = self.resolve_methodref(idx);
                    let (params, ret) = parse_method_descriptor(&desc);
                    let mut args: Vec<IrExpr> = (0..params.len()).map(|_| self.pop()).collect();
                    args.reverse();
                    let expr = IrExpr::StaticCall(cls, mth, desc, args, ret.clone());
                    if ret == JvmType::Void { out.push(IrStmt::ExprStmt(expr)); }
                    else { self.push(expr); }
                }
            }
            Invokeinterface => {
                if let InstructionOperand::InvokeInterface(idx, _) = instr.operands {
                    let (cls, mth, desc) = self.resolve_methodref(idx);
                    let (params, ret) = parse_method_descriptor(&desc);
                    let mut args: Vec<IrExpr> = (0..params.len()).map(|_| self.pop()).collect();
                    args.reverse();
                    let obj = self.pop();
                    let expr = IrExpr::InterfaceCall(Box::new(obj), cls, mth, desc, args, ret.clone());
                    if ret == JvmType::Void { out.push(IrStmt::ExprStmt(expr)); }
                    else { self.push(expr); }
                }
            }
            Invokedynamic => {
                // Java 8+ lambda / method reference
                // Bootstrap method 참조를 그대로 저장
                if let InstructionOperand::InvokeDynamic(idx) = instr.operands {
                    let (name, desc) = self.resolve_indy(idx);
                    let (params, ret) = parse_method_descriptor(&desc);
                    let mut args: Vec<IrExpr> = (0..params.len()).map(|_| self.pop()).collect();
                    args.reverse();
                    let expr = IrExpr::DynamicCall(name, desc, args, ret.clone());
                    if ret == JvmType::Void { out.push(IrStmt::ExprStmt(expr)); }
                    else { self.push(expr); }
                }
            }

            // ── 객체 생성 ─────────────────────────────────────────────────
            New => {
                // new는 dup + invokespecial <init> 패턴으로 나타남
                // 여기서는 uninit ref만 스택에 올려두고,
                // invokespecial <init> 시점에 NewObject로 합칩니다
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let cls = self.resolve_class(idx);
                    self.push(IrExpr::NewObject(cls, Vec::new())); // args는 나중에 채움
                }
            }

            // ── 배열 생성 ─────────────────────────────────────────────────
            Newarray => {
                let count = self.pop();
                if let InstructionOperand::NewArray(arr_ty) = &instr.operands {
                    let ty = JvmType::from_descriptor_char(arr_ty.to_java_type().chars().next().unwrap_or('I'))
                        .unwrap_or(JvmType::Int);
                    self.push(IrExpr::NewArray(ty, Box::new(count)));
                }
            }
            Anewarray => {
                let count = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let cls = self.resolve_class(idx);
                    self.push(IrExpr::NewArray(JvmType::Reference(Some(cls)), Box::new(count)));
                }
            }
            Multianewarray => {
                if let InstructionOperand::MultiNewArray(idx, dims) = instr.operands {
                    let mut dim_exprs: Vec<IrExpr> = (0..dims).map(|_| self.pop()).collect();
                    dim_exprs.reverse();
                    let cls = self.resolve_class(idx);
                    self.push(IrExpr::NewMultiArray(JvmType::Reference(Some(cls)), dim_exprs));
                }
            }

            // ── 배열 / 타입 ───────────────────────────────────────────────
            Arraylength => {
                let arr = self.pop();
                self.push(IrExpr::ArrayLength(Box::new(arr)));
            }
            Checkcast => {
                let obj = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let cls = self.resolve_class(idx);
                    self.push(IrExpr::Checkcast(Box::new(obj), cls));
                }
            }
            Instanceof => {
                let obj = self.pop();
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let cls = self.resolve_class(idx);
                    self.push(IrExpr::InstanceOf(Box::new(obj), cls));
                }
            }

            // ── Monitor ───────────────────────────────────────────────────
            Monitorenter => { let obj = self.pop(); out.push(IrStmt::MonitorEnter(obj)); }
            Monitorexit  => { let obj = self.pop(); out.push(IrStmt::MonitorExit(obj)); }

            // ── Jsr / Ret (Java <=5 서브루틴, try-finally 컴파일에 사용) ──
            Jsr | JsrW => {
                // 반환주소를 스택에 올림 (임시변수로 처리)
                let (tmp, _) = self.fresh_temp(JvmType::ReturnAddress);
                self.push(IrExpr::LocalVar(tmp, JvmType::ReturnAddress));
                let target = self.branch_target(instr);
                out.push(IrStmt::Goto(target));
            }
            Ret => { /* 서브루틴 반환 — CFG 복원에서 처리 */ }

            Wide => { /* wide prefix — 다음 instruction이 처리 */ }
            LdcDynamic => {}
        }

        Ok(())
    }

    // ── 헬퍼 ──────────────────────────────────────────────────────────────

    fn pop_as_stmt(&mut self, out: &mut Vec<IrStmt>) {
        if let Some(expr) = self.stack.pop() {
            if self.has_side_effects(&expr) {
                out.push(IrStmt::ExprStmt(expr));
            }
        }
    }

    fn has_side_effects(&self, expr: &IrExpr) -> bool {
        matches!(expr,
            IrExpr::VirtualCall(..) | IrExpr::StaticCall(..) |
            IrExpr::SpecialCall(..) | IrExpr::InterfaceCall(..) |
            IrExpr::DynamicCall(..) | IrExpr::NewObject(..) |
            IrExpr::NewArray(..) | IrExpr::NewMultiArray(..)
        )
    }

    fn slot_of(&self, opcode: &Opcode, operands: &InstructionOperand) -> u16 {
        match operands {
            InstructionOperand::LocalVarIndex(i) | InstructionOperand::WideLocalVarIndex(i) => *i,
            _ => match opcode {
                Opcode::Iload0|Opcode::Lload0|Opcode::Fload0|Opcode::Dload0|Opcode::Aload0
               |Opcode::Istore0|Opcode::Lstore0|Opcode::Fstore0|Opcode::Dstore0|Opcode::Astore0 => 0,
                Opcode::Iload1|Opcode::Lload1|Opcode::Fload1|Opcode::Dload1|Opcode::Aload1
               |Opcode::Istore1|Opcode::Lstore1|Opcode::Fstore1|Opcode::Dstore1|Opcode::Astore1 => 1,
                Opcode::Iload2|Opcode::Lload2|Opcode::Fload2|Opcode::Dload2|Opcode::Aload2
               |Opcode::Istore2|Opcode::Lstore2|Opcode::Fstore2|Opcode::Dstore2|Opcode::Astore2 => 2,
                _ => 3,
            }
        }
    }

    fn branch_target(&self, instr: &Instruction) -> u32 {
        if let InstructionOperand::BranchOffset(off) = instr.operands {
            (instr.pc as i64 + off as i64) as u32
        } else { instr.pc + instr.byte_size }
    }

    fn ldc_expr(&self, operands: &InstructionOperand) -> Result<IrExpr> {
        if let InstructionOperand::ConstantPoolIndex(idx) = operands {
            match self.cp.get(*idx) {
                Ok(ConstantPoolEntry::Integer(n)) => return Ok(IrExpr::IntLit(*n)),
                Ok(ConstantPoolEntry::Float(f)) => return Ok(IrExpr::FloatLit(*f)),
                Ok(ConstantPoolEntry::Long(n)) => return Ok(IrExpr::LongLit(*n)),
                Ok(ConstantPoolEntry::Double(d)) => return Ok(IrExpr::DoubleLit(*d)),
                Ok(ConstantPoolEntry::String(si)) => {
                    let s = self.cp.get_utf8(*si).unwrap_or("").to_string();
                    return Ok(IrExpr::StringLit(s));
                }
                Ok(ConstantPoolEntry::Class(ni)) => {
                    let name = self.cp.get_utf8(*ni).unwrap_or("").to_string();
                    return Ok(IrExpr::ClassLit(name));
                }
                _ => {}
            }
        }
        Ok(IrExpr::Null)
    }

    fn resolve_fieldref(&self, idx: u16) -> (String, String, JvmType) {
        if let Ok(ConstantPoolEntry::Fieldref(ci, ni)) = self.cp.get(idx) {
            let ci = *ci; let ni = *ni;
            let cls = self.resolve_class(ci);
            if let Ok(ConstantPoolEntry::NameAndType(name_i, desc_i)) = self.cp.get(ni) {
                let name = self.cp.get_utf8(*name_i).unwrap_or("?").to_string();
                let desc = self.cp.get_utf8(*desc_i).unwrap_or("I").to_string();
                let ty = crate::analysis::types::parse_single_type(&desc).unwrap_or(JvmType::Int);
                return (cls, name, ty);
            }
        }
        ("?".into(), "?".into(), JvmType::Int)
    }

    fn resolve_methodref(&self, idx: u16) -> (String, String, String) {
        let entry = self.cp.get(idx);
        let (ci, ni) = match entry {
            Ok(ConstantPoolEntry::Methodref(c, n))
            | Ok(ConstantPoolEntry::InterfaceMethodref(c, n)) => (*c, *n),
            _ => return ("?".into(), "?".into(), "()V".into()),
        };
        let cls = self.resolve_class(ci);
        if let Ok(ConstantPoolEntry::NameAndType(name_i, desc_i)) = self.cp.get(ni) {
            let name = self.cp.get_utf8(*name_i).unwrap_or("?").to_string();
            let desc = self.cp.get_utf8(*desc_i).unwrap_or("()V").to_string();
            return (cls, name, desc);
        }
        (cls, "?".into(), "()V".into())
    }

    fn resolve_indy(&self, idx: u16) -> (String, String) {
        if let Ok(ConstantPoolEntry::InvokeDynamic(_, ni)) = self.cp.get(idx) {
            let ni = *ni;
            if let Ok(ConstantPoolEntry::NameAndType(name_i, desc_i)) = self.cp.get(ni) {
                let name = self.cp.get_utf8(*name_i).unwrap_or("lambda").to_string();
                let desc = self.cp.get_utf8(*desc_i).unwrap_or("()V").to_string();
                return (name, desc);
            }
        }
        ("lambda".into(), "()V".into())
    }

    fn resolve_class(&self, idx: u16) -> String {
        if let Ok(ConstantPoolEntry::Class(ni)) = self.cp.get(idx) {
            let ni = *ni;
            self.cp.get_utf8(ni).unwrap_or("Object").to_string()
        } else { "Object".into() }
    }

    fn int_binop(op: &Opcode) -> BinaryOp {
        match op {
            Opcode::Iadd => BinaryOp::Add, Opcode::Isub => BinaryOp::Sub,
            Opcode::Imul => BinaryOp::Mul, Opcode::Idiv => BinaryOp::Div,
            Opcode::Irem => BinaryOp::Rem, Opcode::Iand => BinaryOp::And,
            Opcode::Ior  => BinaryOp::Or,  Opcode::Ixor => BinaryOp::Xor,
            Opcode::Ishl => BinaryOp::Shl, Opcode::Ishr => BinaryOp::Shr,
            Opcode::Iushr => BinaryOp::UShr, _ => BinaryOp::Add,
        }
    }
    fn long_binop(op: &Opcode) -> BinaryOp {
        match op {
            Opcode::Ladd => BinaryOp::Add, Opcode::Lsub => BinaryOp::Sub,
            Opcode::Lmul => BinaryOp::Mul, Opcode::Ldiv => BinaryOp::Div,
            Opcode::Lrem => BinaryOp::Rem, Opcode::Land => BinaryOp::And,
            Opcode::Lor  => BinaryOp::Or,  Opcode::Lxor => BinaryOp::Xor,
            Opcode::Lshl => BinaryOp::Shl, Opcode::Lshr => BinaryOp::Shr,
            Opcode::Lushr => BinaryOp::UShr, _ => BinaryOp::Add,
        }
    }
    fn float_binop(op: &Opcode) -> BinaryOp {
        match op {
            Opcode::Fadd => BinaryOp::Add, Opcode::Fsub => BinaryOp::Sub,
            Opcode::Fmul => BinaryOp::Mul, Opcode::Fdiv => BinaryOp::Div,
            Opcode::Frem => BinaryOp::Rem, _ => BinaryOp::Add,
        }
    }
    fn double_binop(op: &Opcode) -> BinaryOp {
        match op {
            Opcode::Dadd => BinaryOp::Add, Opcode::Dsub => BinaryOp::Sub,
            Opcode::Dmul => BinaryOp::Mul, Opcode::Ddiv => BinaryOp::Div,
            Opcode::Drem => BinaryOp::Rem, _ => BinaryOp::Add,
        }
    }

    fn if_unary_cmp(op: &Opcode) -> (CompareOp, i32) {
        match op {
            Opcode::Ifeq => (CompareOp::Eq, 0), Opcode::Ifne => (CompareOp::Ne, 0),
            Opcode::Iflt => (CompareOp::Lt, 0), Opcode::Ifge => (CompareOp::Ge, 0),
            Opcode::Ifgt => (CompareOp::Gt, 0), Opcode::Ifle => (CompareOp::Le, 0),
            _ => (CompareOp::Eq, 0),
        }
    }
    fn if_icmp_op(op: &Opcode) -> CompareOp {
        match op {
            Opcode::IfIcmpeq => CompareOp::Eq, Opcode::IfIcmpne => CompareOp::Ne,
            Opcode::IfIcmplt => CompareOp::Lt, Opcode::IfIcmpge => CompareOp::Ge,
            Opcode::IfIcmpgt => CompareOp::Gt, Opcode::IfIcmple => CompareOp::Le,
            _ => CompareOp::Eq,
        }
    }
}
