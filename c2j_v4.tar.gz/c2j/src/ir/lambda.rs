//! invokedynamic → Java lambda / method-reference 복원
//!
//! Java 8+ 에서 lambda/method-reference는 invokedynamic으로 컴파일됩니다.
//!
//! 패턴:
//!   invokedynamic #N "run" "(...)Ljava/lang/Runnable;"
//!   Bootstrap: LambdaMetafactory.metafactory(...)
//!
//! 복원:
//!   (captures) -> { body }         // lambda
//!   ClassName::methodName           // method reference
//!   instance::methodName            // instance method reference
//!   ClassName::new                  // constructor reference

use crate::constantpool::{ConstantPool, ConstantPoolEntry};
use crate::ir::IrExpr;
use crate::analysis::stack::JvmType;

/// invokedynamic Bootstrap Method 정보
#[derive(Debug, Clone)]
pub struct BootstrapInfo {
    pub kind: BootstrapKind,
    pub impl_class: String,
    pub impl_method: String,
    pub impl_desc: String,
    pub captures: Vec<JvmType>,    // 캡처 변수 타입들
    pub functional_interface: String,
}

#[derive(Debug, Clone, PartialEq)]
pub enum BootstrapKind {
    Lambda,
    StaticMethodRef,
    InstanceMethodRef,
    ConstructorRef,
    BoundMethodRef,    // object::method
}

/// LambdaMetafactory 분석
pub struct LambdaAnalyzer<'a> {
    cp: &'a ConstantPool,
    bootstrap_methods: &'a [BootstrapMethodEntry],
}

#[derive(Debug, Clone)]
pub struct BootstrapMethodEntry {
    pub method_ref: u16,
    pub arguments: Vec<u16>,
}

impl<'a> LambdaAnalyzer<'a> {
    pub fn new(cp: &'a ConstantPool, bootstrap_methods: &'a [BootstrapMethodEntry]) -> Self {
        LambdaAnalyzer { cp, bootstrap_methods }
    }

    /// invokedynamic CP 인덱스로 Lambda 정보 분석
    pub fn analyze_indy(&self, indy_idx: u16) -> Option<BootstrapInfo> {
        let (bsm_idx, nat_idx) = match self.cp.get(indy_idx) {
            Ok(ConstantPoolEntry::InvokeDynamic(b, n)) => (*b, *n),
            _ => return None,
        };

        let bsm = self.bootstrap_methods.get(bsm_idx as usize)?;

        // Bootstrap Method가 LambdaMetafactory인지 확인
        let bsm_class = self.resolve_method_handle_class(bsm.method_ref)?;
        if !bsm_class.contains("LambdaMetafactory") { return None; }

        // 메서드 이름 (functional interface 메서드)
        let func_name = self.cp_name_from_nat(nat_idx)?;

        // 인수들: [samMethodType, implMethod, instantiatedMethodType]
        if bsm.arguments.len() < 3 { return None; }

        let impl_method_ref = bsm.arguments[1];
        let (kind, impl_class, impl_method, impl_desc) =
            self.resolve_method_handle(impl_method_ref)?;

        // 함수형 인터페이스 타입 (nat의 descriptor에서)
        let fi = self.cp_desc_from_nat(nat_idx)
            .and_then(|d| extract_return_type(&d))
            .unwrap_or_else(|| "Object".to_string());

        Some(BootstrapInfo {
            kind,
            impl_class,
            impl_method,
            impl_desc,
            captures: Vec::new(),
            functional_interface: fi,
        })
    }

    /// BootstrapInfo → Java 소스 표현식
    pub fn to_java_expr(&self, info: &BootstrapInfo, captures: Vec<IrExpr>) -> String {
        use BootstrapKind::*;

        let simple_class = simple_name(&info.impl_class);
        let method = &info.impl_method;

        match info.kind {
            ConstructorRef => {
                format!("{}::new", simple_class)
            }
            StaticMethodRef => {
                format!("{}::{}", simple_class, method)
            }
            BoundMethodRef => {
                // 첫 캡처 변수가 객체
                let obj = captures.first()
                    .map(|e| expr_to_string(e))
                    .unwrap_or_else(|| "this".to_string());
                format!("{}::{}", obj, method)
            }
            InstanceMethodRef => {
                format!("{}::{}", simple_class, method)
            }
            Lambda => {
                // 람다 파라미터 이름 생성
                let params = build_lambda_params(&info.impl_desc);
                if params.is_empty() {
                    format!("() -> {{ /* {} */ }}", method)
                } else {
                    format!("({}) -> {{ /* {} */ }}", params.join(", "), method)
                }
            }
        }
    }

    fn resolve_method_handle_class(&self, mh_ref: u16) -> Option<String> {
        if let Ok(ConstantPoolEntry::MethodHandle(_, ref_idx)) = self.cp.get(mh_ref) {
            let ref_idx = *ref_idx;
            return self.cp_class_from_ref(ref_idx);
        }
        None
    }

    fn resolve_method_handle(&self, mh_ref: u16) -> Option<(BootstrapKind, String, String, String)> {
        if let Ok(ConstantPoolEntry::MethodHandle(kind_byte, ref_idx)) = self.cp.get(mh_ref) {
            let kind_byte = *kind_byte;
            let ref_idx = *ref_idx;

            let kind = match kind_byte {
                1 => BootstrapKind::StaticMethodRef,  // REF_getField
                2 => BootstrapKind::StaticMethodRef,  // REF_getStatic
                5 => BootstrapKind::InstanceMethodRef, // REF_invokeVirtual
                6 => BootstrapKind::StaticMethodRef,  // REF_invokeStatic
                7 => BootstrapKind::InstanceMethodRef, // REF_invokeSpecial
                8 => BootstrapKind::ConstructorRef,   // REF_newInvokeSpecial
                9 => BootstrapKind::InstanceMethodRef, // REF_invokeInterface
                _ => BootstrapKind::Lambda,
            };

            let class = self.cp_class_from_ref(ref_idx).unwrap_or_default();
            let (name, desc) = self.cp_name_desc_from_ref(ref_idx).unwrap_or_default();

            return Some((kind, class, name, desc));
        }
        None
    }

    fn cp_class_from_ref(&self, ref_idx: u16) -> Option<String> {
        match self.cp.get(ref_idx) {
            Ok(ConstantPoolEntry::Methodref(ci, _))
            | Ok(ConstantPoolEntry::InterfaceMethodref(ci, _))
            | Ok(ConstantPoolEntry::Fieldref(ci, _)) => {
                let ci = *ci;
                if let Ok(ConstantPoolEntry::Class(ni)) = self.cp.get(ci) {
                    let ni = *ni;
                    return self.cp.get_utf8(ni).ok().map(|s| s.to_string());
                }
            }
            _ => {}
        }
        None
    }

    fn cp_name_desc_from_ref(&self, ref_idx: u16) -> Option<(String, String)> {
        let nat_idx = match self.cp.get(ref_idx) {
            Ok(ConstantPoolEntry::Methodref(_, n))
            | Ok(ConstantPoolEntry::InterfaceMethodref(_, n))
            | Ok(ConstantPoolEntry::Fieldref(_, n)) => *n,
            _ => return None,
        };
        let (ni, di) = match self.cp.get(nat_idx) {
            Ok(ConstantPoolEntry::NameAndType(n, d)) => (*n, *d),
            _ => return None,
        };
        let name = self.cp.get_utf8(ni).ok()?.to_string();
        let desc = self.cp.get_utf8(di).ok()?.to_string();
        Some((name, desc))
    }

    fn cp_name_from_nat(&self, nat_idx: u16) -> Option<String> {
        if let Ok(ConstantPoolEntry::NameAndType(ni, _)) = self.cp.get(nat_idx) {
            let ni = *ni;
            return self.cp.get_utf8(ni).ok().map(|s| s.to_string());
        }
        None
    }

    fn cp_desc_from_nat(&self, nat_idx: u16) -> Option<String> {
        if let Ok(ConstantPoolEntry::NameAndType(_, di)) = self.cp.get(nat_idx) {
            let di = *di;
            return self.cp.get_utf8(di).ok().map(|s| s.to_string());
        }
        None
    }
}

// ─── 유틸리티 ──────────────────────────────────────────────────────────────

fn simple_name(internal: &str) -> &str {
    internal.rsplit('/').next().unwrap_or(internal)
}

fn extract_return_type(desc: &str) -> Option<String> {
    let pos = desc.find(')')?;
    let ret = &desc[pos + 1..];
    if ret.starts_with('L') {
        Some(simple_name(ret.trim_start_matches('L').trim_end_matches(';')).to_string())
    } else {
        Some(ret.to_string())
    }
}

fn build_lambda_params(desc: &str) -> Vec<String> {
    use crate::analysis::types::parse_type_sequence;
    let inner = desc.strip_prefix('(')
        .and_then(|s| s.find(')').map(|i| &s[..i]))
        .unwrap_or("");
    let types = parse_type_sequence(inner);
    types.iter().enumerate()
        .map(|(i, _)| format!("p{}", i))
        .collect()
}

fn expr_to_string(expr: &IrExpr) -> String {
    match expr {
        IrExpr::This => "this".into(),
        IrExpr::LocalVar(n, _) => n.clone(),
        _ => "obj".into(),
    }
}

/// IrExpr::DynamicCall을 lambda 표현식 문자열로 변환
pub fn dynamic_call_to_lambda(
    name: &str,
    desc: &str,
    args: &[IrExpr],
    cp: &ConstantPool,
    bootstrap_methods: &[BootstrapMethodEntry],
) -> String {
    // 인수가 없고 이름이 "run"/"apply"/"accept"/"get" 등이면
    // Runnable / Supplier / Consumer 패턴
    let params = build_lambda_params(desc);
    if args.is_empty() && params.is_empty() {
        return format!("() -> {{}}");
    }
    if args.is_empty() {
        let p = params.join(", ");
        return format!("({}) -> {{}}", p);
    }
    // 캡처 변수가 있는 경우 — 첫 번째 인수가 캡처면 method reference
    if args.len() == 1 {
        let obj = expr_to_string(&args[0]);
        return format!("{}::{}", obj, name);
    }
    let p = params.join(", ");
    format!("({}) -> {{/* lambda */}}", p)
}
