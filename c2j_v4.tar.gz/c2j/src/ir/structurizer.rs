//! goto/label → 구조화된 제어문 복원
//!
//! CFG의 BasicBlock 그래프에서 구조화된 Java 제어문을 복원합니다.
//!
//! 복원 대상:
//!   while 루프     : 후향 분기(back edge)로 감지
//!   do-while 루프  : 블록 끝의 조건 분기 + 후향 goto
//!   for 루프       : while + iinc 패턴
//!   if / if-else   : 조건 분기 + 수렴 블록
//!   switch         : tableswitch / lookupswitch
//!   try/catch      : ExceptionHandler 블록

use std::collections::{HashMap, HashSet, BTreeMap};
use crate::analysis::cfg::{ControlFlowGraph, BasicBlock, BlockKind, EdgeKind};
use crate::ir::{IrStmt, IrExpr, CompareOp};

/// 구조화 결과
#[derive(Debug, Clone)]
pub enum StructuredStmt {
    // 단순 문장
    Stmt(IrStmt),

    // 구조화된 제어문
    If {
        cond: IrExpr,
        then_body: Vec<StructuredStmt>,
        else_body: Option<Vec<StructuredStmt>>,
    },
    While {
        cond: IrExpr,
        body: Vec<StructuredStmt>,
        label: Option<String>,
    },
    DoWhile {
        body: Vec<StructuredStmt>,
        cond: IrExpr,
        label: Option<String>,
    },
    For {
        init: Option<Box<StructuredStmt>>,
        cond: IrExpr,
        update: Option<Box<StructuredStmt>>,
        body: Vec<StructuredStmt>,
        label: Option<String>,
    },
    Switch {
        expr: IrExpr,
        cases: Vec<SwitchCase>,
        default: Vec<StructuredStmt>,
    },
    Break(Option<String>),
    Continue(Option<String>),
    Label(String, Vec<StructuredStmt>),
}

#[derive(Debug, Clone)]
pub struct SwitchCase {
    pub value: i32,
    pub body: Vec<StructuredStmt>,
    pub has_break: bool,
}

pub struct Structurizer<'a> {
    cfg: &'a ControlFlowGraph,
    /// block_id → 해당 블록의 IrStmt 목록
    block_stmts: &'a HashMap<u32, Vec<IrStmt>>,
    /// 루프 헤더 블록 ID들
    loop_headers: HashSet<u32>,
    /// 방문한 블록 (재귀 방지)
    visited: HashSet<u32>,
    /// 현재 루프 헤더 스택 (break/continue 대상)
    loop_stack: Vec<u32>,
}

impl<'a> Structurizer<'a> {
    pub fn new(cfg: &'a ControlFlowGraph, block_stmts: &'a HashMap<u32, Vec<IrStmt>>) -> Self {
        let loop_headers = cfg.find_loop_headers();
        Structurizer {
            cfg,
            block_stmts,
            loop_headers,
            visited: HashSet::new(),
            loop_stack: Vec::new(),
        }
    }

    /// 전체 메서드 구조화
    pub fn structurize(&mut self) -> Vec<StructuredStmt> {
        self.visited.clear();
        let rpo = self.cfg.reverse_post_order();
        self.structurize_blocks(&rpo)
    }

    fn structurize_blocks(&mut self, block_ids: &[u32]) -> Vec<StructuredStmt> {
        let mut result: Vec<StructuredStmt> = Vec::new();
        let mut i = 0;

        while i < block_ids.len() {
            let bid = block_ids[i];
            if self.visited.contains(&bid) { i += 1; continue; }
            self.visited.insert(bid);

            let block = match self.cfg.get_block(bid) {
                Some(b) => b,
                None => { i += 1; continue; }
            };

            // 루프 헤더 감지
            if self.loop_headers.contains(&bid) {
                let (loop_stmt, consumed) = self.build_loop(bid, &block_ids[i..]);
                result.push(loop_stmt);
                i += consumed;
                continue;
            }

            // 조건 분기 감지 (if/else)
            if let Some((if_stmt, consumed)) = self.try_build_if(bid, &block_ids[i..]) {
                result.push(if_stmt);
                i += consumed;
                continue;
            }

            // switch 감지
            if let Some(switch_stmt) = self.try_build_switch(bid) {
                result.push(switch_stmt);
                i += 1;
                continue;
            }

            // 일반 블록 — 그대로 출력
            if let Some(stmts) = self.block_stmts.get(&bid) {
                for s in stmts {
                    match s {
                        // goto는 break/continue로 변환 시도
                        IrStmt::Goto(target) => {
                            result.push(self.resolve_goto(*target, bid));
                        }
                        // if 문의 분기도 여기서 정리
                        IrStmt::If(cond, then_pc, _) => {
                            result.push(StructuredStmt::Stmt(
                                IrStmt::If(cond.clone(), *then_pc, None)
                            ));
                        }
                        other => result.push(StructuredStmt::Stmt(other.clone())),
                    }
                }
            }

            i += 1;
        }

        result
    }

    /// while 루프 복원
    fn build_loop(&mut self, header_id: u32, remaining: &[u32]) -> (StructuredStmt, usize) {
        let header = match self.cfg.get_block(header_id) {
            Some(b) => b,
            None => return (StructuredStmt::Stmt(IrStmt::Nop), 1),
        };

        // 루프 조건 (헤더의 마지막 If 문)
        let cond = self.extract_loop_condition(header_id);

        // 루프 바디 블록 수집 (헤더를 제외하고 후향 엣지 이전까지)
        let body_ids = self.collect_loop_body(header_id);

        // 바디 구조화 (재귀)
        self.loop_stack.push(header_id);
        let mut body_vis = self.visited.clone();
        for &bid in &body_ids { body_vis.insert(bid); }
        let body = {
            let mut inner = Structurizer {
                cfg: self.cfg,
                block_stmts: self.block_stmts,
                loop_headers: self.loop_headers.clone(),
                visited: body_vis,
                loop_stack: self.loop_stack.clone(),
            };
            inner.structurize_blocks(&body_ids)
        };
        self.loop_stack.pop();

        // 방문 완료 표시
        for &bid in &body_ids { self.visited.insert(bid); }

        let stmt = if let Some(c) = cond {
            // do-while 감지: 조건이 바디 끝에 있는지 확인
            if self.is_do_while(header_id, &body_ids) {
                StructuredStmt::DoWhile { body, cond: c, label: None }
            } else {
                StructuredStmt::While { cond: c, body, label: None }
            }
        } else {
            // 조건 없는 무한 루프: while(true)
            StructuredStmt::While {
                cond: IrExpr::BoolLit(true),
                body,
                label: None,
            }
        };

        (stmt, 1)
    }

    /// 루프 바디에 속하는 블록 ID들 수집 (RPO 순서 유지)
    fn collect_loop_body(&self, header_id: u32) -> Vec<u32> {
        // 헤더의 successor 중 back edge가 아닌 것들을 DFS로 탐색
        let mut body = Vec::new();
        let mut seen = HashSet::new();
        seen.insert(header_id);

        if let Some(header) = self.cfg.get_block(header_id) {
            for edge in &header.successors {
                if edge.kind == EdgeKind::FallThrough || edge.kind == EdgeKind::Branch {
                    // back edge인지 확인 (target이 header보다 앞에 있으면 back edge)
                    if edge.target_id != header_id {
                        self.collect_body_dfs(edge.target_id, header_id, &mut seen, &mut body);
                    }
                }
            }
        }

        // RPO 순서로 정렬
        let rpo = self.cfg.reverse_post_order();
        body.sort_by_key(|id| rpo.iter().position(|r| r == id).unwrap_or(usize::MAX));
        body
    }

    fn collect_body_dfs(&self, bid: u32, header_id: u32, seen: &mut HashSet<u32>, out: &mut Vec<u32>) {
        if !seen.insert(bid) { return; }
        if self.visited.contains(&bid) { return; }
        out.push(bid);

        if let Some(block) = self.cfg.get_block(bid) {
            for edge in &block.successors {
                // back edge (헤더로 돌아가는)는 탐색하지 않음
                if edge.target_id != header_id && !seen.contains(&edge.target_id) {
                    self.collect_body_dfs(edge.target_id, header_id, seen, out);
                }
            }
        }
    }

    /// 루프 조건 추출 (헤더 블록의 마지막 If 문)
    fn extract_loop_condition(&self, header_id: u32) -> Option<IrExpr> {
        let stmts = self.block_stmts.get(&header_id)?;
        for stmt in stmts.iter().rev() {
            if let IrStmt::If(cond, _, _) = stmt {
                return Some(cond.clone());
            }
        }
        None
    }

    /// do-while 감지: 헤더의 predecessor 중 후향 엣지가 바디 끝 블록에서 오는지
    fn is_do_while(&self, header_id: u32, body_ids: &[u32]) -> bool {
        if let Some(header) = self.cfg.get_block(header_id) {
            for pred in &header.predecessors {
                if body_ids.contains(pred) {
                    // 바디 블록 중 하나가 헤더로 분기 → do-while
                    return true;
                }
            }
        }
        false
    }

    /// if/else 복원 시도
    fn try_build_if(&mut self, bid: u32, remaining: &[u32]) -> Option<(StructuredStmt, usize)> {
        let block = self.cfg.get_block(bid)?;
        let stmts = self.block_stmts.get(&bid)?;

        // 마지막 문장이 조건 분기인가?
        let if_stmt = stmts.iter().rev().find(|s| matches!(s, IrStmt::If(..)))?;
        let (cond, then_pc, _) = match if_stmt {
            IrStmt::If(c, t, e) => (c.clone(), *t, *e),
            _ => return None,
        };

        // 두 successor 찾기 (Branch → then, FallThrough → else/join)
        let branch_edge  = block.successors.iter().find(|e| e.kind == EdgeKind::Branch)?;
        let through_edge = block.successors.iter().find(|e| e.kind == EdgeKind::FallThrough);

        let then_id = branch_edge.target_id;
        let else_id = through_edge.map(|e| e.target_id);

        // 수렴 지점(join) 찾기
        let join_id = self.find_join_point(then_id, else_id);

        // then 바디 수집
        let then_body_ids = self.collect_linear_ids(then_id, join_id);
        let then_body = self.structurize_nested(&then_body_ids);
        for &id in &then_body_ids { self.visited.insert(id); }

        // else 바디 수집
        let else_body = if let Some(eid) = else_id {
            if Some(eid) != join_id {
                let else_ids = self.collect_linear_ids(eid, join_id);
                let body = self.structurize_nested(&else_ids);
                for &id in &else_ids { self.visited.insert(id); }
                if body.is_empty() { None } else { Some(body) }
            } else { None }
        } else { None };

        // 현재 블록의 If 이전 문장들도 포함
        let mut result_stmts: Vec<StructuredStmt> = stmts.iter()
            .filter(|s| !matches!(s, IrStmt::If(..)))
            .map(|s| StructuredStmt::Stmt(s.clone()))
            .collect();

        result_stmts.push(StructuredStmt::If {
            cond,
            then_body,
            else_body,
        });

        // join 블록 이후는 caller가 처리
        Some((wrap_in_block(result_stmts), 1))
    }

    /// switch 복원
    fn try_build_switch(&self, bid: u32) -> Option<StructuredStmt> {
        let stmts = self.block_stmts.get(&bid)?;
        let switch_stmt = stmts.iter().rev().find(|s| matches!(s, IrStmt::Switch(..)))?;

        let (key, cases, default_pc) = match switch_stmt {
            IrStmt::Switch(k, c, d) => (k.clone(), c.clone(), *d),
            _ => return None,
        };

        let block = self.cfg.get_block(bid)?;

        // 각 case 블록 수집
        let mut switch_cases: Vec<SwitchCase> = Vec::new();
        let mut default_ids: Vec<u32> = Vec::new();

        // case 블록들을 case 값 순으로 정렬
        let mut case_edges: Vec<(i32, u32)> = block.successors.iter()
            .filter_map(|e| {
                if let EdgeKind::Switch(v) = e.kind { Some((*v, e.target_id)) }
                else { None }
            })
            .collect();
        case_edges.sort_by_key(|(v, _)| *v);

        // default 블록
        if let Some(def_edge) = block.successors.iter().find(|e| e.kind == EdgeKind::SwitchDefault) {
            default_ids.push(def_edge.target_id);
        }

        for (val, target_id) in case_edges {
            let body = self.collect_linear_ids(target_id, None)
                .iter()
                .flat_map(|&id| {
                    self.block_stmts.get(&id).cloned().unwrap_or_default()
                        .into_iter()
                        .map(|s| StructuredStmt::Stmt(s))
                })
                .collect();
            switch_cases.push(SwitchCase { value: val, body, has_break: true });
        }

        let default_body = default_ids.iter()
            .flat_map(|&id| {
                self.block_stmts.get(&id).cloned().unwrap_or_default()
                    .into_iter()
                    .map(|s| StructuredStmt::Stmt(s))
            })
            .collect();

        Some(StructuredStmt::Switch {
            expr: key,
            cases: switch_cases,
            default: default_body,
        })
    }

    /// goto를 break/continue로 해석
    fn resolve_goto(&self, target_pc: u32, from_id: u32) -> StructuredStmt {
        // target_pc가 현재 루프 헤더 PC인 경우 → continue
        for &header_id in self.loop_stack.iter().rev() {
            if let Some(header) = self.cfg.get_block(header_id) {
                if header.start_pc == target_pc {
                    return StructuredStmt::Continue(None);
                }
            }
        }

        // target_pc가 루프 직후 블록인 경우 → break
        if !self.loop_stack.is_empty() {
            return StructuredStmt::Break(None);
        }

        // 그 외 → goto 주석
        StructuredStmt::Stmt(IrStmt::Goto(target_pc))
    }

    /// 두 블록의 수렴 지점(post-dominator) 찾기
    fn find_join_point(&self, then_id: u32, else_id: Option<u32>) -> Option<u32> {
        let rpo = self.cfg.reverse_post_order();

        // then 경로에서 도달 가능한 블록들
        let then_reachable = self.reachable_from(then_id);

        if let Some(eid) = else_id {
            // else 경로에서도 도달 가능한 첫 블록
            let else_reachable = self.reachable_from(eid);
            for &id in &rpo {
                if then_reachable.contains(&id) && else_reachable.contains(&id) {
                    return Some(id);
                }
            }
        }
        None
    }

    fn reachable_from(&self, start: u32) -> HashSet<u32> {
        let mut visited = HashSet::new();
        let mut queue = vec![start];
        while let Some(id) = queue.pop() {
            if !visited.insert(id) { continue; }
            if let Some(block) = self.cfg.get_block(id) {
                for edge in &block.successors {
                    queue.push(edge.target_id);
                }
            }
        }
        visited
    }

    /// start_id → join_id(미포함) 사이의 선형 블록 ID 목록
    fn collect_linear_ids(&self, start: u32, join_id: Option<u32>) -> Vec<u32> {
        let mut ids = Vec::new();
        let mut current = start;
        let mut seen = HashSet::new();

        loop {
            if Some(current) == join_id { break; }
            if !seen.insert(current) { break; }
            if self.visited.contains(&current) { break; }

            ids.push(current);

            let block = match self.cfg.get_block(current) {
                Some(b) => b,
                None => break,
            };

            let next = block.successors.iter()
                .find(|e| e.kind == EdgeKind::FallThrough)
                .map(|e| e.target_id);

            match next {
                Some(n) if Some(n) != join_id => current = n,
                _ => break,
            }
        }

        ids
    }

    fn structurize_nested(&mut self, ids: &[u32]) -> Vec<StructuredStmt> {
        let mut inner = Structurizer {
            cfg: self.cfg,
            block_stmts: self.block_stmts,
            loop_headers: self.loop_headers.clone(),
            visited: self.visited.clone(),
            loop_stack: self.loop_stack.clone(),
        };
        inner.structurize_blocks(ids)
    }
}

fn wrap_in_block(stmts: Vec<StructuredStmt>) -> StructuredStmt {
    if stmts.len() == 1 {
        stmts.into_iter().next().unwrap()
    } else {
        StructuredStmt::Label("_block".into(), stmts)
    }
}
