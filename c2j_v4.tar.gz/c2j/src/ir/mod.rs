//! IR (Intermediate Representation)
//!
//! Bytecode → Java AST 변환 중간 단계.
//! 스택 기반 bytecode를 레지스터/변수 기반 표현으로 바꿉니다.

pub mod conversion;
pub mod new_synthesis;
pub mod structurizer;
pub mod lambda;
pub mod pattern_switch;
pub mod textblock;
pub mod enum_restore;
pub mod string_switch;
pub mod annotation_restore;

use crate::analysis::stack::JvmType;

/// IR 표현식
#[derive(Debug, Clone)]
pub enum IrExpr {
    // 리터럴
    Null,
    IntLit(i32),
    LongLit(i64),
    FloatLit(f32),
    DoubleLit(f64),
    BoolLit(bool),
    StringLit(String),
    ClassLit(String),

    // 변수 참조
    LocalVar(String, JvmType),
    This,

    // 연산
    BinaryOp(Box<IrExpr>, BinaryOp, Box<IrExpr>, JvmType),
    UnaryOp(UnaryOp, Box<IrExpr>, JvmType),
    Cast(Box<IrExpr>, JvmType),

    // 필드
    StaticField(String, String, JvmType),
    InstanceField(Box<IrExpr>, String, String, JvmType),

    // 메서드 호출
    StaticCall(String, String, String, Vec<IrExpr>, JvmType),
    VirtualCall(Box<IrExpr>, String, String, String, Vec<IrExpr>, JvmType),
    SpecialCall(Box<IrExpr>, String, String, String, Vec<IrExpr>, JvmType),
    InterfaceCall(Box<IrExpr>, String, String, String, Vec<IrExpr>, JvmType),
    DynamicCall(String, String, Vec<IrExpr>, JvmType),

    // 객체
    NewObject(String, Vec<IrExpr>),
    NewArray(JvmType, Box<IrExpr>),
    NewMultiArray(JvmType, Vec<IrExpr>),
    ArrayAccess(Box<IrExpr>, Box<IrExpr>, JvmType),
    ArrayLength(Box<IrExpr>),

    // 타입 검사
    InstanceOf(Box<IrExpr>, String),
    Checkcast(Box<IrExpr>, String),

    // 비교
    CompareOp(Box<IrExpr>, CompareOp, Box<IrExpr>),

    // 기타
    Ternary(Box<IrExpr>, Box<IrExpr>, Box<IrExpr>, JvmType),
    TempVar(u32, JvmType),
}

impl IrExpr {
    pub fn get_type(&self) -> JvmType {
        match self {
            IrExpr::Null => JvmType::Null,
            IrExpr::IntLit(_) => JvmType::Int,
            IrExpr::BoolLit(_) => JvmType::Boolean,
            IrExpr::LongLit(_) => JvmType::Long,
            IrExpr::FloatLit(_) => JvmType::Float,
            IrExpr::DoubleLit(_) => JvmType::Double,
            IrExpr::StringLit(_) => JvmType::Reference(Some("java/lang/String".into())),
            IrExpr::ClassLit(_) => JvmType::Reference(Some("java/lang/Class".into())),
            IrExpr::LocalVar(_, ty) | IrExpr::TempVar(_, ty) => ty.clone(),
            IrExpr::This => JvmType::Reference(None),
            IrExpr::BinaryOp(_, _, _, ty)
            | IrExpr::UnaryOp(_, _, ty)
            | IrExpr::Cast(_, ty) => ty.clone(),
            IrExpr::StaticField(_, _, ty) | IrExpr::InstanceField(_, _, _, ty) => ty.clone(),
            IrExpr::StaticCall(_, _, _, _, ty)
            | IrExpr::VirtualCall(_, _, _, _, _, ty)
            | IrExpr::SpecialCall(_, _, _, _, _, ty)
            | IrExpr::InterfaceCall(_, _, _, _, _, ty)
            | IrExpr::DynamicCall(_, _, _, ty) => ty.clone(),
            IrExpr::NewObject(cls, _) => JvmType::Reference(Some(cls.clone())),
            IrExpr::NewArray(ty, _) | IrExpr::NewMultiArray(ty, _) => JvmType::Array(Box::new(ty.clone())),
            IrExpr::ArrayAccess(_, _, ty) => ty.clone(),
            IrExpr::ArrayLength(_) => JvmType::Int,
            IrExpr::InstanceOf(_, _) => JvmType::Boolean,
            IrExpr::Checkcast(_, cls) => JvmType::Reference(Some(cls.clone())),
            IrExpr::CompareOp(_, _, _) => JvmType::Boolean,
            IrExpr::Ternary(_, _, _, ty) => ty.clone(),
        }
    }
}

/// IR 문장
#[derive(Debug, Clone)]
pub enum IrStmt {
    Assign(String, JvmType, IrExpr),
    ExprStmt(IrExpr),
    Return(Option<IrExpr>),
    Throw(IrExpr),
    Goto(u32),
    If(IrExpr, u32, Option<u32>),
    Switch(IrExpr, Vec<(i32, u32)>, u32),
    Label(u32),
    TryCatch {
        try_stmts: Vec<IrStmt>,
        catches: Vec<(Option<String>, String, Vec<IrStmt>)>,
        finally: Option<Vec<IrStmt>>,
    },
    MonitorEnter(IrExpr),
    MonitorExit(IrExpr),
    ArrayStore(IrExpr, IrExpr, IrExpr),
    FieldPut(Option<IrExpr>, String, String, IrExpr, bool),
    Iinc(String, i16),
    Nop,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinaryOp {
    Add, Sub, Mul, Div, Rem,
    And, Or, Xor,
    Shl, Shr, UShr,
    LCmp, FCmpL, FCmpG, DCmpL, DCmpG,
}

impl BinaryOp {
    pub fn to_java_symbol(&self) -> &'static str {
        match self {
            BinaryOp::Add => "+",  BinaryOp::Sub => "-",
            BinaryOp::Mul => "*",  BinaryOp::Div => "/",
            BinaryOp::Rem => "%",  BinaryOp::And => "&",
            BinaryOp::Or  => "|",  BinaryOp::Xor => "^",
            BinaryOp::Shl => "<<", BinaryOp::Shr => ">>",
            BinaryOp::UShr => ">>>",
            _ => "?",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp { Neg, Not, BitwiseNot }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompareOp {
    Eq, Ne, Lt, Le, Gt, Ge,
    RefEq, RefNe,
    Null, NotNull,
}

impl CompareOp {
    pub fn to_java_symbol(&self) -> &'static str {
        match self {
            CompareOp::Eq | CompareOp::RefEq => "==",
            CompareOp::Ne | CompareOp::RefNe => "!=",
            CompareOp::Lt => "<", CompareOp::Le => "<=",
            CompareOp::Gt => ">", CompareOp::Ge => ">=",
            CompareOp::Null => "== null",
            CompareOp::NotNull => "!= null",
        }
    }
    pub fn negate(&self) -> Self {
        match self {
            CompareOp::Eq  => CompareOp::Ne,  CompareOp::Ne  => CompareOp::Eq,
            CompareOp::Lt  => CompareOp::Ge,  CompareOp::Ge  => CompareOp::Lt,
            CompareOp::Gt  => CompareOp::Le,  CompareOp::Le  => CompareOp::Gt,
            CompareOp::RefEq  => CompareOp::RefNe, CompareOp::RefNe => CompareOp::RefEq,
            CompareOp::Null   => CompareOp::NotNull, CompareOp::NotNull => CompareOp::Null,
        }
    }
}

/// IR 메서드 표현
#[derive(Debug, Clone)]
pub struct IrMethod {
    pub name: String,
    pub descriptor: String,
    pub return_type: JvmType,
    pub params: Vec<(String, JvmType)>,
    pub is_static: bool,
    pub stmts: Vec<IrStmt>,
    pub max_locals: u16,
}
