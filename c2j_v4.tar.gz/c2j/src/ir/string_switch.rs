//! String switch 복원
//!
//! Java 7+에서 switch(String)은 다음 패턴으로 컴파일됩니다:
//!
//!   int tmp = str.hashCode();
//!   switch (tmp) {
//!       case <hash("foo")>:
//!           if (str.equals("foo")) { ... break; }
//!       case <hash("bar")>:
//!           if (str.equals("bar")) { ... break; }
//!       default: break;
//!   }
//!
//! 복원:
//!   switch (str) {
//!       case "foo": ...
//!       case "bar": ...
//!   }
//!
//! 감지 방법:
//!   - tableswitch/lookupswitch 의 selector가 invokevirtual hashCode() 결과
//!   - 각 case 블록 안에 invokevirtual equals() + ifeq/ifne 패턴

use crate::ir::{IrStmt, IrExpr, CompareOp};
use crate::analysis::stack::JvmType;

/// String switch 감지 결과
#[derive(Debug, Clone)]
pub struct StringSwitch {
    /// switch 대상 String 표현식
    pub selector: IrExpr,
    /// (문자열 리터럴, 해당 케이스 본문)
    pub cases: Vec<(String, Vec<IrStmt>)>,
    pub default: Vec<IrStmt>,
}

/// IrStmt 목록에서 String switch 패턴 감지
///
/// 패턴:
///   Assign(tmp, VirtualCall(str, "hashCode", ...))
///   Switch(tmp, [...], default)
///   → 각 case 블록: If(VirtualCall(str,"equals",["xxx"]), ...)
pub fn detect_string_switch(stmts: &[IrStmt]) -> Option<StringSwitch> {
    for i in 0..stmts.len() {
        // hashCode() 호출 결과를 Switch에 사용하는 패턴
        if let IrStmt::Switch(key, cases, _default_pc) = &stmts[i] {
            if let Some(str_expr) = extract_hashcode_selector(key) {
                let mut string_cases = Vec::new();

                // 각 case 블록에서 equals() 패턴 추출
                // (실제로는 CFG에서 해당 PC의 블록을 참조해야 함)
                // 여기서는 stmts 내의 인접 패턴으로 탐색
                for (_, _target_pc) in cases {
                    // equals 패턴 탐색은 CFG 블록 수준에서 처리
                    // 여기서는 구조만 잡아두고 나중에 채움
                }

                if !string_cases.is_empty() {
                    return Some(StringSwitch {
                        selector: str_expr,
                        cases: string_cases,
                        default: Vec::new(),
                    });
                }
            }
        }
    }
    None
}

/// IrExpr이 hashCode() 호출인지 확인하고 대상 표현식 반환
fn extract_hashcode_selector(expr: &IrExpr) -> Option<IrExpr> {
    match expr {
        IrExpr::VirtualCall(obj, _, method, _, args, _)
            if method == "hashCode" && args.is_empty() =>
        {
            Some(*obj.clone())
        }
        IrExpr::LocalVar(_, _) => {
            // hashCode 결과가 로컬 변수에 저장된 경우
            // → 이 변수가 어디서 할당됐는지 추적 필요 (use-def chain)
            None
        }
        _ => None,
    }
}

/// equals() 패턴에서 문자열 리터럴 추출
pub fn extract_equals_string(expr: &IrExpr) -> Option<String> {
    match expr {
        IrExpr::VirtualCall(_, _, method, _, args, _) if method == "equals" => {
            if let Some(IrExpr::StringLit(s)) = args.first() {
                return Some(s.clone());
            }
            None
        }
        IrExpr::CompareOp(a, _, _) => extract_equals_string(a),
        _ => None,
    }
}

/// String switch IrStmt → Java 소스
pub fn gen_string_switch(ss: &StringSwitch) -> String {
    let mut out = String::new();
    out.push_str(&format!("switch ({}) {{\n", expr_to_str(&ss.selector)));

    for (s, stmts) in &ss.cases {
        out.push_str(&format!("    case \"{}\":\n", escape_str(s)));
        for stmt in stmts {
            out.push_str("        ");
            out.push_str(&format!("{:?}", stmt)); // 실제로는 gen_ir_stmt 호출
            out.push('\n');
        }
        out.push_str("        break;\n");
    }

    if !ss.default.is_empty() {
        out.push_str("    default:\n");
        out.push_str("        break;\n");
    }

    out.push('}');
    out
}

/// IrStmt 목록에서 hashCode 기반 switch를 String switch로 변환
/// (CFG 기반 완전 복원)
pub fn transform_hash_switch_to_string_switch(
    stmts: &mut Vec<IrStmt>,
    // hashcode → string 매핑 (분석 단계에서 수집)
    hash_to_str: &std::collections::HashMap<i32, Vec<String>>,
) {
    let mut i = 0;
    while i < stmts.len() {
        if let IrStmt::Switch(key, cases, default_pc) = &stmts[i] {
            // key가 hashCode 계산 결과인 경우
            // hashCode 값을 문자열로 교체
            let new_cases: Vec<(i32, u32)> = cases.clone();
            let mut is_string_switch = false;
            for (hash_val, _) in &new_cases {
                if hash_to_str.contains_key(hash_val) {
                    is_string_switch = true;
                    break;
                }
            }

            if is_string_switch {
                // String switch로 변환 (주석으로 마킹)
                let default = *default_pc;
                let marked_key = IrExpr::VirtualCall(
                    Box::new(key.clone()),
                    String::new(),
                    "/* string switch */".into(),
                    String::new(),
                    Vec::new(),
                    JvmType::Int,
                );
                stmts[i] = IrStmt::Switch(marked_key, new_cases, default);
            }
        }
        i += 1;
    }
}

/// 문자열의 Java hashCode 계산 (검증용)
pub fn java_string_hashcode(s: &str) -> i32 {
    let mut h: i32 = 0;
    for c in s.chars() {
        h = h.wrapping_mul(31).wrapping_add(c as i32);
    }
    h
}

fn expr_to_str(expr: &IrExpr) -> String {
    match expr {
        IrExpr::LocalVar(n, _) => n.clone(),
        IrExpr::This => "this".into(),
        _ => "str".into(),
    }
}

fn escape_str(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_java_hashcode() {
        assert_eq!(java_string_hashcode(""), 0);
        assert_eq!(java_string_hashcode("a"), 97);
        assert_eq!(java_string_hashcode("ab"), 97 * 31 + 98);
        // Java 검증: "hello".hashCode() == 99162322
        assert_eq!(java_string_hashcode("hello"), 99162322);
        // "foo".hashCode() == 101574
        assert_eq!(java_string_hashcode("foo"), 101574);
        // "bar".hashCode() == 97299
        assert_eq!(java_string_hashcode("bar"), 97299);
    }

    #[test]
    fn test_extract_equals_string() {
        let eq_expr = IrExpr::VirtualCall(
            Box::new(IrExpr::LocalVar("s".into(), JvmType::Reference(None))),
            "java/lang/String".into(),
            "equals".into(),
            "(Ljava/lang/Object;)Z".into(),
            vec![IrExpr::StringLit("hello".into())],
            JvmType::Boolean,
        );
        let result = extract_equals_string(&eq_expr);
        assert_eq!(result, Some("hello".into()));
    }

    #[test]
    fn test_hashcode_switch_detection() {
        // hashCode 호출 결과를 switch key로 사용하는 패턴
        let hash_call = IrExpr::VirtualCall(
            Box::new(IrExpr::LocalVar("str".into(), JvmType::Reference(None))),
            "java/lang/String".into(),
            "hashCode".into(),
            "()I".into(),
            vec![],
            JvmType::Int,
        );
        let result = extract_hashcode_selector(&hash_call);
        assert!(result.is_some(), "hashCode 패턴 감지 실패");
        if let Some(IrExpr::LocalVar(name, _)) = result {
            assert_eq!(name, "str");
        }
    }
}
