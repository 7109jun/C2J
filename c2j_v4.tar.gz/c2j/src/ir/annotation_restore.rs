//! Annotation 완전 복원
//!
//! RuntimeVisibleAnnotations / RuntimeInvisibleAnnotations attribute에서
//! Java annotation을 복원합니다.
//!
//! 지원:
//!   @Override, @Deprecated, @SuppressWarnings("unchecked")
//!   @FunctionalInterface, @SafeVarargs
//!   커스텀 annotation (모든 element value 타입)
//!   배열 annotation: @SomeAnnotation(values = {1, 2, 3})
//!   중첩 annotation: @Outer(@Inner(x=1))

use byteorder::{BigEndian, ByteOrder};
use crate::constantpool::ConstantPoolEntry;

/// 파싱된 Annotation
#[derive(Debug, Clone)]
pub struct ParsedAnnotation {
    pub type_name: String,                         // "java/lang/Override"
    pub elements: Vec<(String, AnnotationValue)>,  // 이름-값 쌍
    pub is_visible: bool,                          // runtime visible 여부
}

/// Annotation 값 타입
#[derive(Debug, Clone)]
pub enum AnnotationValue {
    Byte(i8),
    Char(char),
    Double(f64),
    Float(f32),
    Int(i32),
    Long(i64),
    Short(i16),
    Boolean(bool),
    String(String),
    Enum(String, String),              // (type_name, const_name)
    Class(String),                     // "Ljava/lang/String;"
    Annotation(Box<ParsedAnnotation>),
    Array(Vec<AnnotationValue>),
}

/// ClassFile attributes에서 annotation 추출
pub fn extract_annotations(
    attributes: &[crate::classfile::structures::AttributeInfo],
    cp: &Vec<Option<ConstantPoolEntry>>,
) -> Vec<ParsedAnnotation> {
    let mut result = Vec::new();

    for attr in attributes {
        let attr_name = get_utf8(cp, attr.name_index).unwrap_or("");
        let visible = match attr_name {
            "RuntimeVisibleAnnotations"   => true,
            "RuntimeInvisibleAnnotations" => false,
            _ => continue,
        };

        if attr.data.len() < 2 { continue; }
        let count = BigEndian::read_u16(&attr.data[0..2]) as usize;
        let mut pos = 2usize;

        for _ in 0..count {
            if let Some((ann, next_pos)) = parse_annotation(&attr.data, pos, cp, visible) {
                result.push(ann);
                pos = next_pos;
            } else { break; }
        }
    }

    result
}

/// 단일 annotation 파싱
fn parse_annotation(
    data: &[u8], mut pos: usize,
    cp: &Vec<Option<ConstantPoolEntry>>,
    visible: bool,
) -> Option<(ParsedAnnotation, usize)> {
    if pos + 4 > data.len() { return None; }

    let type_idx = BigEndian::read_u16(&data[pos..pos+2]);
    let num_pairs = BigEndian::read_u16(&data[pos+2..pos+4]) as usize;
    pos += 4;

    let type_name = get_utf8(cp, type_idx)
        .unwrap_or("?")
        .trim_start_matches('L')
        .trim_end_matches(';')
        .to_string();

    let mut elements = Vec::new();
    for _ in 0..num_pairs {
        if pos + 2 > data.len() { break; }
        let name_idx = BigEndian::read_u16(&data[pos..pos+2]);
        let name = get_utf8(cp, name_idx).unwrap_or("?").to_string();
        pos += 2;

        if let Some((val, next_pos)) = parse_element_value(data, pos, cp) {
            elements.push((name, val));
            pos = next_pos;
        } else { break; }
    }

    Some((ParsedAnnotation { type_name, elements, is_visible: visible }, pos))
}

/// element_value 파싱
fn parse_element_value(
    data: &[u8], mut pos: usize,
    cp: &Vec<Option<ConstantPoolEntry>>,
) -> Option<(AnnotationValue, usize)> {
    if pos >= data.len() { return None; }

    let tag = data[pos] as char;
    pos += 1;

    let (val, new_pos) = match tag {
        'B' | 'C' | 'D' | 'F' | 'I' | 'J' | 'S' | 'Z' | 's' => {
            if pos + 2 > data.len() { return None; }
            let idx = BigEndian::read_u16(&data[pos..pos+2]);
            pos += 2;
            let v = match tag {
                'B' => cp_int(cp, idx).map(|n| AnnotationValue::Byte(n as i8)),
                'C' => cp_int(cp, idx).and_then(|n| char::from_u32(n as u32))
                                       .map(AnnotationValue::Char),
                'D' => cp_double(cp, idx).map(AnnotationValue::Double),
                'F' => cp_float(cp, idx).map(AnnotationValue::Float),
                'I' => cp_int(cp, idx).map(AnnotationValue::Int),
                'J' => cp_long(cp, idx).map(AnnotationValue::Long),
                'S' => cp_int(cp, idx).map(|n| AnnotationValue::Short(n as i16)),
                'Z' => cp_int(cp, idx).map(|n| AnnotationValue::Boolean(n != 0)),
                's' => get_utf8(cp, idx).map(|s| AnnotationValue::String(s.to_string())),
                _   => None,
            }?;
            (v, pos)
        }
        'e' => {
            // enum: type_name_index(2) + const_name_index(2)
            if pos + 4 > data.len() { return None; }
            let type_idx  = BigEndian::read_u16(&data[pos..pos+2]);
            let const_idx = BigEndian::read_u16(&data[pos+2..pos+4]);
            let type_name  = get_utf8(cp, type_idx).unwrap_or("?").to_string();
            let const_name = get_utf8(cp, const_idx).unwrap_or("?").to_string();
            (AnnotationValue::Enum(type_name, const_name), pos + 4)
        }
        'c' => {
            // class: class_info_index(2)
            if pos + 2 > data.len() { return None; }
            let idx = BigEndian::read_u16(&data[pos..pos+2]);
            let class_name = get_utf8(cp, idx).unwrap_or("?").to_string();
            (AnnotationValue::Class(class_name), pos + 2)
        }
        '@' => {
            // nested annotation
            if let Some((ann, next_pos)) = parse_annotation(data, pos, cp, true) {
                (AnnotationValue::Annotation(Box::new(ann)), next_pos)
            } else { return None; }
        }
        '[' => {
            // array
            if pos + 2 > data.len() { return None; }
            let count = BigEndian::read_u16(&data[pos..pos+2]) as usize;
            pos += 2;
            let mut arr = Vec::new();
            for _ in 0..count {
                if let Some((v, np)) = parse_element_value(data, pos, cp) {
                    arr.push(v);
                    pos = np;
                } else { break; }
            }
            (AnnotationValue::Array(arr), pos)
        }
        _ => return None,
    };

    Some((val, new_pos))
}

/// Annotation → Java 소스 문자열
pub fn annotation_to_java(ann: &ParsedAnnotation) -> String {
    let simple = ann.type_name.rsplit('/').next().unwrap_or(&ann.type_name);

    if ann.elements.is_empty() {
        return format!("@{}", simple);
    }

    // 단일 "value" 요소는 이름 생략
    if ann.elements.len() == 1 && ann.elements[0].0 == "value" {
        let val = element_value_to_java(&ann.elements[0].1);
        return format!("@{}({})", simple, val);
    }

    let pairs: Vec<String> = ann.elements.iter()
        .map(|(k, v)| format!("{} = {}", k, element_value_to_java(v)))
        .collect();
    format!("@{}({})", simple, pairs.join(", "))
}

fn element_value_to_java(val: &AnnotationValue) -> String {
    match val {
        AnnotationValue::Byte(n)    => format!("(byte){}", n),
        AnnotationValue::Char(c)    => format!("'{}'", c),
        AnnotationValue::Double(d)  => format!("{}d", d),
        AnnotationValue::Float(f)   => format!("{}f", f),
        AnnotationValue::Int(n)     => n.to_string(),
        AnnotationValue::Long(n)    => format!("{}L", n),
        AnnotationValue::Short(n)   => format!("(short){}", n),
        AnnotationValue::Boolean(b) => if *b { "true" } else { "false" }.into(),
        AnnotationValue::String(s)  => format!("\"{}\"",
            s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")),
        AnnotationValue::Enum(t, c) => {
            let simple = t.trim_start_matches('L').trim_end_matches(';')
                .rsplit('/').next().unwrap_or(c);
            format!("{}.{}", simple, c)
        }
        AnnotationValue::Class(c)   => {
            let simple = c.trim_start_matches('L').trim_end_matches(';')
                .rsplit('/').next().unwrap_or(c);
            format!("{}.class", simple)
        }
        AnnotationValue::Annotation(a) => annotation_to_java(a),
        AnnotationValue::Array(arr) => {
            let items: Vec<String> = arr.iter().map(element_value_to_java).collect();
            if items.len() == 1 { items[0].clone() }
            else { format!("{{{}}}", items.join(", ")) }
        }
    }
}

/// 메서드 파라미터 annotation 추출
pub fn extract_param_annotations(
    attributes: &[crate::classfile::structures::AttributeInfo],
    cp: &Vec<Option<ConstantPoolEntry>>,
    param_count: usize,
) -> Vec<Vec<ParsedAnnotation>> {
    let mut result: Vec<Vec<ParsedAnnotation>> = vec![Vec::new(); param_count];

    for attr in attributes {
        let attr_name = get_utf8(cp, attr.name_index).unwrap_or("");
        let visible = match attr_name {
            "RuntimeVisibleParameterAnnotations"   => true,
            "RuntimeInvisibleParameterAnnotations" => false,
            _ => continue,
        };

        if attr.data.is_empty() { continue; }
        let num_params = attr.data[0] as usize;
        let mut pos = 1usize;

        for p in 0..num_params.min(param_count) {
            if pos + 2 > attr.data.len() { break; }
            let count = BigEndian::read_u16(&attr.data[pos..pos+2]) as usize;
            pos += 2;
            for _ in 0..count {
                if let Some((ann, np)) = parse_annotation(&attr.data, pos, cp, visible) {
                    result[p].push(ann);
                    pos = np;
                } else { break; }
            }
        }
    }

    result
}

// ─── CP 헬퍼 ──────────────────────────────────────────────────────────────
fn get_utf8<'a>(cp: &'a Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<&'a str> {
    cp.get(idx as usize)?.as_ref().and_then(|e| {
        if let ConstantPoolEntry::Utf8(s) = e { Some(s.as_str()) } else { None }
    })
}
fn cp_int(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<i32> {
    if let Some(Some(ConstantPoolEntry::Integer(n))) = cp.get(idx as usize) { Some(*n) } else { None }
}
fn cp_long(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<i64> {
    if let Some(Some(ConstantPoolEntry::Long(n))) = cp.get(idx as usize) { Some(*n) } else { None }
}
fn cp_float(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<f32> {
    if let Some(Some(ConstantPoolEntry::Float(f))) = cp.get(idx as usize) { Some(*f) } else { None }
}
fn cp_double(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<f64> {
    if let Some(Some(ConstantPoolEntry::Double(d))) = cp.get(idx as usize) { Some(*d) } else { None }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_annotation_no_elements() {
        let ann = ParsedAnnotation {
            type_name: "java/lang/Override".into(),
            elements: vec![],
            is_visible: true,
        };
        assert_eq!(annotation_to_java(&ann), "@Override");
    }

    #[test]
    fn test_annotation_single_value() {
        let ann = ParsedAnnotation {
            type_name: "java/lang/SuppressWarnings".into(),
            elements: vec![("value".into(), AnnotationValue::String("unchecked".into()))],
            is_visible: true,
        };
        assert_eq!(annotation_to_java(&ann), "@SuppressWarnings(\"unchecked\")");
    }

    #[test]
    fn test_annotation_array_value() {
        let ann = ParsedAnnotation {
            type_name: "java/lang/SuppressWarnings".into(),
            elements: vec![("value".into(), AnnotationValue::Array(vec![
                AnnotationValue::String("unchecked".into()),
                AnnotationValue::String("rawtypes".into()),
            ]))],
            is_visible: true,
        };
        let result = annotation_to_java(&ann);
        assert!(result.contains("{"), "배열 표기 누락: {}", result);
        assert!(result.contains("unchecked"), "값 누락");
    }

    #[test]
    fn test_annotation_multiple_elements() {
        let ann = ParsedAnnotation {
            type_name: "com/example/MyAnnotation".into(),
            elements: vec![
                ("name".into(),  AnnotationValue::String("test".into())),
                ("value".into(), AnnotationValue::Int(42)),
            ],
            is_visible: true,
        };
        let result = annotation_to_java(&ann);
        assert!(result.starts_with("@MyAnnotation("), "선언 오류: {}", result);
        assert!(result.contains("name = \"test\""), "name 누락");
        assert!(result.contains("value = 42"), "value 누락");
    }

    #[test]
    fn test_java_hashcode_consistency() {
        // String switch 복원의 hashcode 계산 검증
        use crate::ir::string_switch::java_string_hashcode;
        assert_eq!(java_string_hashcode("GET"),  70454);
        assert_eq!(java_string_hashcode("POST"), 2461856);
    }
}
