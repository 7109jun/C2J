use std::fmt;
use thiserror::Error;

pub type Result<T> = std::result::Result<T, C2JError>;

#[derive(Error, Debug)]
pub enum C2JError {
    #[error("Invalid class file magic: expected 0xCAFEBABE, got 0x{0:08X}")]
    InvalidMagic(u32),

    #[error("Unsupported class file version: major={0}, minor={1}")]
    UnsupportedVersion(u16, u16),

    #[error("Invalid constant pool index: {0}")]
    InvalidConstantPoolIndex(u16),

    #[error("Constant pool entry at index {0} has unexpected type")]
    InvalidConstantPoolType(u16),

    #[error("Invalid bytecode at offset {0}: {1}")]
    InvalidBytecode(u16, String),

    #[error("Unsupported bytecode instruction: opcode 0x{0:02X}")]
    UnsupportedInstruction(u8),

    #[error("Type inference failed: {0}")]
    TypeInferenceFailed(String),

    #[error("Code generation failed: {0}")]
    CodeGenerationFailed(String),

    #[error("Java compilation failed: {0}")]
    CompilationFailed(String),

    #[error("Verification failed: {0}")]
    VerificationFailed(String),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Plugin error: {0}")]
    PluginError(String),

    #[error("Invalid argument: {0}")]
    InvalidArgument(String),

    #[error("Internal error: {0}")]
    InternalError(String),
}

impl C2JError {
    pub fn is_recoverable(&self) -> bool {
        !matches!(
            self,
            C2JError::InvalidMagic(_) | C2JError::Io(_) | C2JError::InvalidConstantPoolIndex(_)
        )
    }
}
