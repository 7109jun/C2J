use log::{Level, Metadata, Record};

pub struct SimpleLogger;

impl log::Log for SimpleLogger {
    fn enabled(&self, metadata: &Metadata) -> bool {
        metadata.level() <= Level::Info
    }

    fn log(&self, record: &Record) {
        if self.enabled(record.metadata()) {
            let level_color = match record.level() {
                Level::Error => "\x1b[31m",   // Red
                Level::Warn => "\x1b[33m",    // Yellow
                Level::Info => "\x1b[32m",    // Green
                Level::Debug => "\x1b[36m",   // Cyan
                Level::Trace => "\x1b[35m",   // Magenta
            };
            let reset = "\x1b[0m";

            eprintln!(
                "{}[{}]{} {}",
                level_color,
                record.level(),
                reset,
                record.args()
            );
        }
    }

    fn flush(&self) {}
}

pub fn init() {
    let _ = log::set_boxed_logger(Box::new(SimpleLogger))
        .map(|()| log::set_max_level(log::LevelFilter::Info));
}
