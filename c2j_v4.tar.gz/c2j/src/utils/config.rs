/// C2J 설정
#[derive(Debug, Clone)]
pub struct Config {
    /// 디버그 모드
    pub debug: bool,
    
    /// 상세 출력
    pub verbose: bool,
    
    /// 컴파일 검증 수행
    pub verify_compile: bool,
    
    /// 실행 검증 수행
    pub verify_runtime: bool,
    
    /// 최대 Java 버전 (11, 17, 21 등)
    pub max_java_version: u16,
    
    /// 플러그인 디렉토리
    pub plugin_dir: Option<String>,
}

impl Default for Config {
    fn default() -> Self {
        Config {
            debug: false,
            verbose: false,
            verify_compile: false,
            verify_runtime: false,
            max_java_version: 17,
            plugin_dir: None,
        }
    }
}

impl Config {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_debug(mut self, debug: bool) -> Self {
        self.debug = debug;
        self
    }

    pub fn with_verification(mut self, verify: bool) -> Self {
        self.verify_compile = verify;
        self.verify_runtime = verify;
        self
    }
}
