//! 상세 진단 + 에러 복구
//!
//! 파싱/변환 실패 시 가능한 많은 정보를 제공하고
//! 부분 결과라도 출력할 수 있도록 에러를 분류합니다.

use std::fmt;
use crate::utils::C2JError;

/// 진단 심각도
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub enum Severity {
    Info,
    Warning,
    Error,
    Fatal,
}

impl fmt::Display for Severity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Severity::Info    => write!(f, "\x1b[32mINFO\x1b[0m"),
            Severity::Warning => write!(f, "\x1b[33mWARN\x1b[0m"),
            Severity::Error   => write!(f, "\x1b[31mERROR\x1b[0m"),
            Severity::Fatal   => write!(f, "\x1b[35mFATAL\x1b[0m"),
        }
    }
}

/// 단일 진단 메시지
#[derive(Debug, Clone)]
pub struct Diagnostic {
    pub severity: Severity,
    pub code:     &'static str,     // "E001", "W101" 등
    pub message:  String,
    pub location: Option<Location>,
    pub hint:     Option<String>,
}

/// 소스 위치 (bytecode PC 또는 .class 파일 내 오프셋)
#[derive(Debug, Clone)]
pub struct Location {
    pub method: Option<String>,
    pub pc:     Option<u32>,
    pub offset: Option<usize>,
}

impl fmt::Display for Diagnostic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "[{}] {}: {}", self.severity, self.code, self.message)?;
        if let Some(loc) = &self.location {
            if let Some(m) = &loc.method { write!(f, " (in {})", m)?; }
            if let Some(pc) = loc.pc    { write!(f, " at pc={}", pc)?; }
        }
        if let Some(hint) = &self.hint {
            write!(f, "\n  힌트: {}", hint)?;
        }
        Ok(())
    }
}

/// 진단 수집기
#[derive(Debug, Default)]
pub struct DiagnosticCollector {
    pub diagnostics: Vec<Diagnostic>,
    pub has_fatal:   bool,
}

impl DiagnosticCollector {
    pub fn new() -> Self { Self::default() }

    pub fn add(&mut self, d: Diagnostic) {
        if d.severity == Severity::Fatal { self.has_fatal = true; }
        self.diagnostics.push(d);
    }

    pub fn info(&mut self, code: &'static str, msg: impl Into<String>) {
        self.add(Diagnostic { severity: Severity::Info, code, message: msg.into(), location: None, hint: None });
    }

    pub fn warn(&mut self, code: &'static str, msg: impl Into<String>) {
        self.add(Diagnostic { severity: Severity::Warning, code, message: msg.into(), location: None, hint: None });
    }

    pub fn error(&mut self, code: &'static str, msg: impl Into<String>) {
        self.add(Diagnostic { severity: Severity::Error, code, message: msg.into(), location: None, hint: None });
    }

    pub fn error_at(&mut self, code: &'static str, msg: impl Into<String>, method: &str, pc: u32) {
        self.add(Diagnostic {
            severity: Severity::Error,
            code,
            message: msg.into(),
            location: Some(Location {
                method: Some(method.to_string()),
                pc: Some(pc),
                offset: None,
            }),
            hint: None,
        });
    }

    pub fn fatal(&mut self, code: &'static str, msg: impl Into<String>) {
        self.has_fatal = true;
        self.add(Diagnostic { severity: Severity::Fatal, code, message: msg.into(), location: None, hint: None });
    }

    pub fn has_errors(&self) -> bool {
        self.diagnostics.iter().any(|d| d.severity >= Severity::Error)
    }

    pub fn count_by_severity(&self, s: Severity) -> usize {
        self.diagnostics.iter().filter(|d| d.severity == s).count()
    }

    pub fn print_all(&self) {
        for d in &self.diagnostics {
            eprintln!("{}", d);
        }
        if !self.diagnostics.is_empty() {
            eprintln!("─── 진단: {} 정보, {} 경고, {} 오류 ───",
                self.count_by_severity(Severity::Info),
                self.count_by_severity(Severity::Warning),
                self.count_by_severity(Severity::Error),
            );
        }
    }
}

/// C2JError → 진단 메시지 + 복구 힌트
pub fn error_to_diagnostic(e: &C2JError) -> Diagnostic {
    let (code, hint) = match e {
        C2JError::InvalidMagic(_) => ("E001",
            Some("올바른 .class 파일인지 확인하세요. 파일이 손상됐거나 다른 형식일 수 있습니다.")),
        C2JError::UnsupportedVersion(major, _) => ("E002",
            Some("Java 8~22 (major 52~66) 만 지원합니다. --java-version 옵션을 확인하세요.")),
        C2JError::InvalidConstantPoolIndex(_) => ("E003",
            Some("Constant Pool이 손상됐을 수 있습니다. 원본 소스에서 재컴파일 후 시도하세요.")),
        C2JError::InvalidBytecode(_, _) => ("E010",
            Some("바이트코드가 유효하지 않습니다. 난독화된 코드일 수 있습니다.")),
        C2JError::UnsupportedInstruction(_) => ("W011",
            Some("미지원 opcode입니다. 플러그인으로 처리하거나 최신 버전을 사용하세요.")),
        C2JError::TypeInferenceFailed(_) => ("W020",
            Some("타입 추론 실패 — 생성 코드에 Object 타입이 사용될 수 있습니다.")),
        C2JError::CodeGenerationFailed(_) => ("E030",
            Some("소스 생성 실패 — --verbose로 상세 정보를 확인하세요.")),
        C2JError::CompilationFailed(_) => ("E040",
            Some("생성된 .java가 컴파일되지 않습니다. 이슈를 보고해 주세요.")),
        C2JError::PluginError(_) => ("W050",
            Some("플러그인 로드 실패 — --plugin-dir 경로와 .so/.dll 파일을 확인하세요.")),
        C2JError::InvalidArgument(_) => ("E060", None),
        _ => ("E999", None),
    };

    Diagnostic {
        severity: match e {
            C2JError::InvalidMagic(_)
            | C2JError::UnsupportedVersion(_, _)
            | C2JError::InvalidConstantPoolIndex(_) => Severity::Fatal,
            C2JError::UnsupportedInstruction(_)
            | C2JError::TypeInferenceFailed(_)
            | C2JError::PluginError(_) => Severity::Warning,
            _ => Severity::Error,
        },
        code,
        message: e.to_string(),
        location: None,
        hint: hint.map(|s| s.to_string()),
    }
}

/// 부분 디컴파일 결과 (일부 메서드 실패 시에도 파일 생성)
#[derive(Debug)]
pub struct PartialResult {
    pub source: String,
    pub diagnostics: DiagnosticCollector,
    pub failed_methods: Vec<String>,
}

impl PartialResult {
    pub fn is_complete(&self) -> bool { self.failed_methods.is_empty() }

    pub fn success_rate(&self) -> f64 {
        // 실패한 메서드 비율 (0.0 ~ 1.0)
        // 메서드 수는 source에서 유추하기 어려우므로 실패 수로만 표현
        if self.failed_methods.is_empty() { 1.0 } else { 0.5 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_diagnostic_display() {
        let d = Diagnostic {
            severity: Severity::Warning,
            code: "W011",
            message: "미지원 opcode: 0xFF".into(),
            location: Some(Location {
                method: Some("main".into()),
                pc: Some(42),
                offset: None,
            }),
            hint: Some("플러그인 사용".into()),
        };
        let s = d.to_string();
        assert!(s.contains("W011"), "코드 누락: {}", s);
        assert!(s.contains("main"), "메서드 누락: {}", s);
        assert!(s.contains("pc=42"), "PC 누락: {}", s);
    }

    #[test]
    fn test_collector_has_errors() {
        let mut coll = DiagnosticCollector::new();
        coll.warn("W001", "경고");
        assert!(!coll.has_errors());
        coll.error("E001", "오류");
        assert!(coll.has_errors());
    }

    #[test]
    fn test_error_to_diagnostic_invalid_magic() {
        let e = C2JError::InvalidMagic(0xDEADBEEF);
        let d = error_to_diagnostic(&e);
        assert_eq!(d.code, "E001");
        assert_eq!(d.severity, Severity::Fatal);
        assert!(d.hint.is_some());
    }
}
