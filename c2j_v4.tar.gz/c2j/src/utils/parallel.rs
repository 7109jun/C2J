//! 병렬 처리 유틸리티
//!
//! 디렉토리/JAR의 대량 .class 파일을 멀티스레드로 처리합니다.
//! 표준 라이브러리만 사용 (rayon 미사용).

use std::sync::{Arc, Mutex};
use std::thread;
use std::path::PathBuf;
use crate::utils::{Result, C2JError};

/// 작업 결과
#[derive(Debug)]
pub struct WorkResult<T> {
    pub key: String,
    pub result: std::result::Result<T, String>,
    pub elapsed_ms: u64,
}

/// 스레드 풀 기반 병렬 처리기
pub struct ParallelProcessor {
    num_threads: usize,
}

impl ParallelProcessor {
    pub fn new(num_threads: usize) -> Self {
        let n = num_threads.max(1).min(16);
        ParallelProcessor { num_threads: n }
    }

    /// CPU 코어 수 기반 자동 설정
    pub fn auto() -> Self {
        // available_parallelism은 Rust 1.55+
        let n = thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(4)
            .min(8);
        Self::new(n)
    }

    /// items를 n개 스레드로 병렬 처리
    pub fn process<T, F>(
        &self,
        items: Vec<(String, Vec<u8>)>,  // (key, data)
        work_fn: F,
    ) -> Vec<WorkResult<T>>
    where
        T: Send + 'static,
        F: Fn(&str, &[u8]) -> std::result::Result<T, String> + Send + Sync + 'static,
    {
        let results: Arc<Mutex<Vec<WorkResult<T>>>> = Arc::new(Mutex::new(Vec::new()));
        let work_fn = Arc::new(work_fn);
        let items = Arc::new(Mutex::new(items.into_iter().enumerate().collect::<Vec<_>>()));

        let mut handles = Vec::new();

        for _ in 0..self.num_threads {
            let items    = Arc::clone(&items);
            let results  = Arc::clone(&results);
            let work_fn  = Arc::clone(&work_fn);

            let handle = thread::spawn(move || {
                loop {
                    let item = {
                        let mut locked = items.lock().unwrap();
                        // 큐에서 다음 작업 가져오기
                        if locked.is_empty() { break; }
                        locked.remove(0)
                    };
                    let (_, (key, data)) = item;

                    let start = std::time::Instant::now();
                    let result = work_fn(&key, &data);
                    let elapsed_ms = start.elapsed().as_millis() as u64;

                    results.lock().unwrap().push(WorkResult {
                        key,
                        result,
                        elapsed_ms,
                    });
                }
            });
            handles.push(handle);
        }

        for h in handles { let _ = h.join(); }

        Arc::try_unwrap(results).unwrap().into_inner().unwrap()
    }
}

/// 처리 통계
#[derive(Debug, Default)]
pub struct ProcessStats {
    pub total:      usize,
    pub succeeded:  usize,
    pub failed:     usize,
    pub total_ms:   u64,
    pub max_ms:     u64,
    pub errors:     Vec<String>,
}

impl ProcessStats {
    pub fn from_results<T>(results: &[WorkResult<T>]) -> Self {
        let mut stats = ProcessStats::default();
        stats.total = results.len();
        for r in results {
            stats.total_ms += r.elapsed_ms;
            stats.max_ms = stats.max_ms.max(r.elapsed_ms);
            match &r.result {
                Ok(_)  => stats.succeeded += 1,
                Err(e) => {
                    stats.failed += 1;
                    stats.errors.push(format!("{}: {}", r.key, e));
                }
            }
        }
        stats
    }

    pub fn avg_ms(&self) -> u64 {
        if self.total == 0 { 0 } else { self.total_ms / self.total as u64 }
    }

    pub fn print_summary(&self) {
        eprintln!("처리 완료: {}/{} 성공, 실패 {}개",
            self.succeeded, self.total, self.failed);
        eprintln!("소요 시간: 총 {}ms, 평균 {}ms, 최대 {}ms",
            self.total_ms, self.avg_ms(), self.max_ms);
        if !self.errors.is_empty() {
            eprintln!("실패 목록:");
            for e in self.errors.iter().take(10) {
                eprintln!("  • {}", e);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parallel_processor_basic() {
        let proc = ParallelProcessor::new(2);
        let items: Vec<(String, Vec<u8>)> = (0..10)
            .map(|i| (format!("item_{}", i), vec![i as u8]))
            .collect();

        let results = proc.process(items, |key, data| {
            Ok::<usize, String>(data[0] as usize * 2)
        });

        assert_eq!(results.len(), 10);
        let succeeded = results.iter().filter(|r| r.result.is_ok()).count();
        assert_eq!(succeeded, 10);
    }

    #[test]
    fn test_process_stats() {
        let results: Vec<WorkResult<i32>> = vec![
            WorkResult { key: "a".into(), result: Ok(1), elapsed_ms: 10 },
            WorkResult { key: "b".into(), result: Ok(2), elapsed_ms: 20 },
            WorkResult { key: "c".into(), result: Err("error".into()), elapsed_ms: 5 },
        ];
        let stats = ProcessStats::from_results(&results);
        assert_eq!(stats.total, 3);
        assert_eq!(stats.succeeded, 2);
        assert_eq!(stats.failed, 1);
        assert_eq!(stats.max_ms, 20);
    }
}
