//! ClassFile 검증
//! 
//! 파싱된 ClassFile이 유효한지 검증합니다.

use crate::classfile::ClassFile;
use crate::utils::{Result, C2JError};

pub struct ClassFileValidator;

impl ClassFileValidator {
    pub fn validate(class_file: &ClassFile) -> Result<()> {
        // 1. Magic 검증
        if class_file.magic != 0xCAFEBABE {
            return Err(C2JError::InvalidMagic(class_file.magic));
        }

        // 2. Version 검증
        // Java 8(52) ~ Java 22(66) 지원
        if class_file.major_version < 52 || class_file.major_version > 66 {
            return Err(C2JError::UnsupportedVersion(
                class_file.major_version,
                class_file.minor_version,
            ));
        }

        // 3. Constant Pool 검증
        Self::validate_constant_pool(class_file)?;

        // 4. 클래스 참조 검증
        Self::validate_class_references(class_file)?;

        Ok(())
    }

    fn validate_constant_pool(class_file: &ClassFile) -> Result<()> {
        // Constant pool이 비어있으면 안 됨
        if class_file.constant_pool.is_empty() {
            return Err(C2JError::InvalidConstantPoolIndex(0));
        }

        // this_class, super_class는 유효한 범위 내
        let cp_size = class_file.constant_pool.len() as u16;

        if class_file.this_class >= cp_size || class_file.this_class == 0 {
            return Err(C2JError::InvalidConstantPoolIndex(class_file.this_class));
        }

        if class_file.super_class != 0 && class_file.super_class >= cp_size {
            return Err(C2JError::InvalidConstantPoolIndex(class_file.super_class));
        }

        Ok(())
    }

    fn validate_class_references(class_file: &ClassFile) -> Result<()> {
        // 모든 interface 참조 검증
        let cp_size = class_file.constant_pool.len() as u16;
        for iface in &class_file.interfaces {
            if *iface == 0 || *iface >= cp_size {
                return Err(C2JError::InvalidConstantPoolIndex(*iface));
            }
        }

        Ok(())
    }
}
