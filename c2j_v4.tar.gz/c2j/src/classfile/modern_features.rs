//! Java 14~21 최신 기능 파싱
//!
//! - Record (Java 16+): RecordComponent attribute 파싱
//! - Sealed (Java 17+): PermittedSubclasses attribute 파싱
//! - Pattern switch (Java 21): 코드 생성 시 활용
//! - Text block (Java 15+): ldc에서 감지

use crate::classfile::structures::{ClassFile, AttributeInfo};
use crate::constantpool::{ConstantPool, ConstantPoolEntry};
use byteorder::{BigEndian, ByteOrder};

/// Record 구성요소
#[derive(Debug, Clone)]
pub struct RecordComponentInfo {
    pub name: String,
    pub descriptor: String,
    pub signature: Option<String>,        // Generic 시그니처
    pub annotations: Vec<String>,
}

/// Sealed class 허가 서브클래스 목록
#[derive(Debug, Clone)]
pub struct SealedInfo {
    pub permitted: Vec<String>,           // 허가된 서브클래스 이름 목록
}

/// NestHost/NestMembers 정보
#[derive(Debug, Clone)]
pub struct NestInfo {
    pub host: Option<String>,
    pub members: Vec<String>,
}

/// ClassFile에서 Record 컴포넌트 추출
pub fn extract_record_components(
    class_file: &ClassFile,
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> Vec<RecordComponentInfo> {
    let mut components = Vec::new();

    for attr in &class_file.attributes {
        let attr_name = get_utf8(cp_raw, attr.name_index).unwrap_or("");
        if attr_name != "Record" { continue; }

        // Record { u2 components_count; record_component_info[components_count] }
        let data = &attr.data;
        if data.len() < 2 { break; }
        let count = BigEndian::read_u16(&data[0..2]) as usize;
        let mut pos = 2usize;

        for _ in 0..count {
            if pos + 6 > data.len() { break; }
            let name_idx = BigEndian::read_u16(&data[pos..pos+2]);
            let desc_idx = BigEndian::read_u16(&data[pos+2..pos+4]);
            let attr_count = BigEndian::read_u16(&data[pos+4..pos+6]) as usize;
            pos += 6;

            let name = get_utf8(cp_raw, name_idx).unwrap_or("?").to_string();
            let desc = get_utf8(cp_raw, desc_idx).unwrap_or("?").to_string();
            let mut signature = None;

            // 컴포넌트 자체의 attribute들
            for _ in 0..attr_count {
                if pos + 6 > data.len() { break; }
                let a_name_idx = BigEndian::read_u16(&data[pos..pos+2]);
                let a_len = BigEndian::read_u32(&data[pos+2..pos+6]) as usize;
                pos += 6;
                let a_name = get_utf8(cp_raw, a_name_idx).unwrap_or("");
                if a_name == "Signature" && pos + 2 <= data.len() {
                    let sig_idx = BigEndian::read_u16(&data[pos..pos+2]);
                    signature = get_utf8(cp_raw, sig_idx).map(|s| s.to_string());
                }
                pos += a_len;
            }

            components.push(RecordComponentInfo {
                name,
                descriptor: desc,
                signature,
                annotations: Vec::new(),
            });
        }
        break;
    }

    components
}

/// Sealed class 허가 목록 추출
pub fn extract_sealed_info(
    class_file: &ClassFile,
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> Option<SealedInfo> {
    for attr in &class_file.attributes {
        let attr_name = get_utf8(cp_raw, attr.name_index).unwrap_or("");
        if attr_name != "PermittedSubclasses" { continue; }

        let data = &attr.data;
        if data.len() < 2 { return None; }
        let count = BigEndian::read_u16(&data[0..2]) as usize;

        let mut permitted = Vec::new();
        for i in 0..count {
            let pos = 2 + i * 2;
            if pos + 2 > data.len() { break; }
            let class_idx = BigEndian::read_u16(&data[pos..pos+2]);
            // Class → Utf8
            if let Some(Some(ConstantPoolEntry::Class(ni))) = cp_raw.get(class_idx as usize) {
                if let Some(name) = get_utf8(cp_raw, *ni) {
                    permitted.push(name.replace('/', "."));
                }
            }
        }

        return Some(SealedInfo { permitted });
    }
    None
}

/// NestHost/NestMembers 추출
pub fn extract_nest_info(
    class_file: &ClassFile,
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> NestInfo {
    let mut host = None;
    let mut members = Vec::new();

    for attr in &class_file.attributes {
        let attr_name = get_utf8(cp_raw, attr.name_index).unwrap_or("");
        match attr_name {
            "NestHost" if attr.data.len() >= 2 => {
                let class_idx = BigEndian::read_u16(&attr.data[0..2]);
                if let Some(Some(ConstantPoolEntry::Class(ni))) = cp_raw.get(class_idx as usize) {
                    host = get_utf8(cp_raw, *ni).map(|s| s.replace('/', "."));
                }
            }
            "NestMembers" if attr.data.len() >= 2 => {
                let count = BigEndian::read_u16(&attr.data[0..2]) as usize;
                for i in 0..count {
                    let pos = 2 + i * 2;
                    if pos + 2 > attr.data.len() { break; }
                    let class_idx = BigEndian::read_u16(&attr.data[pos..pos+2]);
                    if let Some(Some(ConstantPoolEntry::Class(ni))) = cp_raw.get(class_idx as usize) {
                        if let Some(name) = get_utf8(cp_raw, *ni) {
                            members.push(name.replace('/', "."));
                        }
                    }
                }
            }
            _ => {}
        }
    }

    NestInfo { host, members }
}

/// BootstrapMethods attribute 파싱
pub fn extract_bootstrap_methods(
    class_file: &ClassFile,
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> Vec<crate::ir::lambda::BootstrapMethodEntry> {
    for attr in &class_file.attributes {
        let attr_name = get_utf8(cp_raw, attr.name_index).unwrap_or("");
        if attr_name != "BootstrapMethods" { continue; }

        let data = &attr.data;
        if data.len() < 2 { break; }
        let count = BigEndian::read_u16(&data[0..2]) as usize;
        let mut pos = 2usize;
        let mut bsms = Vec::new();

        for _ in 0..count {
            if pos + 4 > data.len() { break; }
            let method_ref = BigEndian::read_u16(&data[pos..pos+2]);
            let arg_count  = BigEndian::read_u16(&data[pos+2..pos+4]) as usize;
            pos += 4;

            let mut arguments = Vec::new();
            for _ in 0..arg_count {
                if pos + 2 > data.len() { break; }
                arguments.push(BigEndian::read_u16(&data[pos..pos+2]));
                pos += 2;
            }
            bsms.push(crate::ir::lambda::BootstrapMethodEntry { method_ref, arguments });
        }

        return bsms;
    }
    Vec::new()
}

/// InnerClasses attribute 파싱
#[derive(Debug, Clone)]
pub struct InnerClassEntry {
    pub inner_name: Option<String>,       // None → 익명 클래스
    pub outer_name: Option<String>,
    pub access_flags: u16,
}

pub fn extract_inner_classes(
    class_file: &ClassFile,
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> Vec<InnerClassEntry> {
    let mut entries = Vec::new();

    for attr in &class_file.attributes {
        let attr_name = get_utf8(cp_raw, attr.name_index).unwrap_or("");
        if attr_name != "InnerClasses" { continue; }

        let data = &attr.data;
        if data.len() < 2 { break; }
        let count = BigEndian::read_u16(&data[0..2]) as usize;

        for i in 0..count {
            let pos = 2 + i * 8;
            if pos + 8 > data.len() { break; }

            let inner_class_idx = BigEndian::read_u16(&data[pos..pos+2]);
            let outer_class_idx = BigEndian::read_u16(&data[pos+2..pos+4]);
            let inner_name_idx  = BigEndian::read_u16(&data[pos+4..pos+6]);
            let access_flags    = BigEndian::read_u16(&data[pos+6..pos+8]);

            let inner_name = if inner_name_idx != 0 {
                get_utf8(cp_raw, inner_name_idx).map(|s| s.to_string())
            } else { None };

            let outer_name = if outer_class_idx != 0 {
                if let Some(Some(ConstantPoolEntry::Class(ni))) = cp_raw.get(outer_class_idx as usize) {
                    get_utf8(cp_raw, *ni).map(|s| s.replace('/', "."))
                } else { None }
            } else { None };

            entries.push(InnerClassEntry { inner_name, outer_name, access_flags });
        }
        break;
    }

    entries
}

/// 제네릭 Signature attribute 추출
pub fn extract_signature(
    attributes: &[AttributeInfo],
    cp_raw: &Vec<Option<ConstantPoolEntry>>,
) -> Option<String> {
    for attr in attributes {
        if get_utf8(cp_raw, attr.name_index).unwrap_or("") == "Signature" && attr.data.len() >= 2 {
            let idx = BigEndian::read_u16(&attr.data[0..2]);
            return get_utf8(cp_raw, idx).map(|s| s.to_string());
        }
    }
    None
}

/// 헬퍼: raw CP에서 Utf8 문자열 가져오기
fn get_utf8(cp: &Vec<Option<ConstantPoolEntry>>, idx: u16) -> Option<&str> {
    cp.get(idx as usize)?.as_ref().and_then(|e| {
        if let ConstantPoolEntry::Utf8(s) = e { Some(s.as_str()) } else { None }
    })
}
