//! ClassFile 파서
//! 
//! JVM Class File Format을 이진 형식으로 파싱합니다.
//! Specification: https://docs.oracle.com/javase/specs/jvms/se17/html/jvms-4.html

use std::io::{Read, Cursor};
use byteorder::{BigEndian, ReadBytesExt};

use crate::utils::{Result, C2JError};
use crate::classfile::structures::*;
use crate::constantpool::{ConstantPool, ConstantPoolEntry};

pub struct ClassFileParser;

impl ClassFileParser {
    /// 바이트 배열에서 ClassFile을 파싱
    pub fn parse(bytes: &[u8]) -> Result<ClassFile> {
        let mut cursor = Cursor::new(bytes);
        Self::parse_impl(&mut cursor)
    }

    fn parse_impl(cursor: &mut Cursor<&[u8]>) -> Result<ClassFile> {
        // 1. Magic 번호 확인
        let magic = cursor.read_u32::<BigEndian>()?;
        if magic != 0xCAFEBABE {
            return Err(C2JError::InvalidMagic(magic));
        }

        // 2. Version 정보
        let minor_version = cursor.read_u16::<BigEndian>()?;
        let major_version = cursor.read_u16::<BigEndian>()?;

        // Java 버전 매핑:
        //   Java 11 = major 55, Java 17 = major 61
        //   Java 21 = major 65, Java 22 = major 66
        // minor_version == 65535 → preview feature (Java 12+)
        // 지원 범위: Java 8(52) ~ Java 22(66)
        if major_version < 52 || major_version > 66 {
            return Err(C2JError::UnsupportedVersion(major_version, minor_version));
        }

        // 3. Constant Pool 파싱
        let constant_pool = Self::parse_constant_pool(cursor)?;

        // 4. Access Flags (클래스)
        let access_flags = AccessFlags(cursor.read_u16::<BigEndian>()?);

        // 5. This Class, Super Class
        let this_class = cursor.read_u16::<BigEndian>()?;
        let super_class = cursor.read_u16::<BigEndian>()?;

        // 6. Interfaces
        let interfaces_count = cursor.read_u16::<BigEndian>()?;
        let mut interfaces = Vec::new();
        for _ in 0..interfaces_count {
            interfaces.push(cursor.read_u16::<BigEndian>()?);
        }

        // 7. Fields
        let fields_count = cursor.read_u16::<BigEndian>()?;
        let mut fields = Vec::new();
        for _ in 0..fields_count {
            fields.push(Self::parse_field(cursor)?);
        }

        // 8. Methods
        let methods_count = cursor.read_u16::<BigEndian>()?;
        let mut methods = Vec::new();
        for _ in 0..methods_count {
            methods.push(Self::parse_method(cursor)?);
        }

        // 9. Attributes (클래스)
        let attributes_count = cursor.read_u16::<BigEndian>()?;
        let mut attributes = Vec::new();
        for _ in 0..attributes_count {
            attributes.push(Self::parse_attribute(cursor)?);
        }

        Ok(ClassFile {
            magic,
            minor_version,
            major_version,
            constant_pool: constant_pool.entries,
            access_flags,
            this_class,
            super_class,
            interfaces,
            fields,
            methods,
            attributes,
        })
    }

    /// Constant Pool 파싱
    fn parse_constant_pool(cursor: &mut Cursor<&[u8]>) -> Result<ConstantPool> {
        let count = cursor.read_u16::<BigEndian>()?;
        let mut cp = ConstantPool::new();

        let mut i = 1u16;
        while i < count {
            let tag = cursor.read_u8()?;
            let entry = match tag {
                1 => {
                    // CONSTANT_Utf8
                    let length = cursor.read_u16::<BigEndian>()? as usize;
                    let mut bytes = vec![0u8; length];
                    cursor.read_exact(&mut bytes)?;
                    let s = String::from_utf8(bytes)
                        .map_err(|_| C2JError::InvalidBytecode(i, "Invalid UTF-8 in Utf8 constant".to_string()))?;
                    ConstantPoolEntry::Utf8(s)
                }
                3 => {
                    // CONSTANT_Integer
                    let value = cursor.read_i32::<BigEndian>()?;
                    ConstantPoolEntry::Integer(value)
                }
                4 => {
                    // CONSTANT_Float
                    let value = cursor.read_f32::<BigEndian>()?;
                    ConstantPoolEntry::Float(value)
                }
                5 => {
                    // CONSTANT_Long (takes 2 slots)
                    let value = cursor.read_i64::<BigEndian>()?;
                    cp.entries.push(Some(ConstantPoolEntry::Long(value)));
                    i += 1;
                    ConstantPoolEntry::Long(value)
                }
                6 => {
                    // CONSTANT_Double (takes 2 slots)
                    let value = cursor.read_f64::<BigEndian>()?;
                    cp.entries.push(Some(ConstantPoolEntry::Double(value)));
                    i += 1;
                    ConstantPoolEntry::Double(value)
                }
                7 => {
                    // CONSTANT_Class
                    let name_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Class(name_index)
                }
                8 => {
                    // CONSTANT_String
                    let string_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::String(string_index)
                }
                9 => {
                    // CONSTANT_Fieldref
                    let class_index = cursor.read_u16::<BigEndian>()?;
                    let nat_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Fieldref(class_index, nat_index)
                }
                10 => {
                    // CONSTANT_Methodref
                    let class_index = cursor.read_u16::<BigEndian>()?;
                    let nat_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Methodref(class_index, nat_index)
                }
                11 => {
                    // CONSTANT_InterfaceMethodref
                    let class_index = cursor.read_u16::<BigEndian>()?;
                    let nat_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::InterfaceMethodref(class_index, nat_index)
                }
                12 => {
                    // CONSTANT_NameAndType
                    let name_index = cursor.read_u16::<BigEndian>()?;
                    let descriptor_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::NameAndType(name_index, descriptor_index)
                }
                15 => {
                    // CONSTANT_MethodHandle
                    let ref_kind = cursor.read_u8()?;
                    let ref_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::MethodHandle(ref_kind, ref_index)
                }
                16 => {
                    // CONSTANT_MethodType
                    let desc_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::MethodType(desc_index)
                }
                17 => {
                    // CONSTANT_Dynamic
                    let bootstrap_index = cursor.read_u16::<BigEndian>()?;
                    let nat_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Dynamic(bootstrap_index, nat_index)
                }
                18 => {
                    // CONSTANT_InvokeDynamic
                    let bootstrap_index = cursor.read_u16::<BigEndian>()?;
                    let nat_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::InvokeDynamic(bootstrap_index, nat_index)
                }
                19 => {
                    // CONSTANT_Module
                    let name_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Module(name_index)
                }
                20 => {
                    // CONSTANT_Package
                    let name_index = cursor.read_u16::<BigEndian>()?;
                    ConstantPoolEntry::Package(name_index)
                }
                _ => {
                    return Err(C2JError::UnsupportedInstruction(tag));
                }
            };

            cp.entries.push(Some(entry));
            i += 1;
        }

        Ok(cp)
    }

    /// Field 파싱
    fn parse_field(cursor: &mut Cursor<&[u8]>) -> Result<FieldInfo> {
        let access_flags = AccessFlags(cursor.read_u16::<BigEndian>()?);
        let name_index = cursor.read_u16::<BigEndian>()?;
        let descriptor_index = cursor.read_u16::<BigEndian>()?;
        let attributes = Self::parse_attributes(cursor)?;

        Ok(FieldInfo {
            access_flags,
            name_index,
            descriptor_index,
            attributes,
        })
    }

    /// Method 파싱
    fn parse_method(cursor: &mut Cursor<&[u8]>) -> Result<MethodInfo> {
        let access_flags = AccessFlags(cursor.read_u16::<BigEndian>()?);
        let name_index = cursor.read_u16::<BigEndian>()?;
        let descriptor_index = cursor.read_u16::<BigEndian>()?;
        let attributes = Self::parse_attributes(cursor)?;

        // Code 속성 찾기
        let code = Self::extract_code_attribute(&attributes)?;

        Ok(MethodInfo {
            access_flags,
            name_index,
            descriptor_index,
            attributes,
            code,
        })
    }

    /// Attribute들 파싱
    fn parse_attributes(cursor: &mut Cursor<&[u8]>) -> Result<Vec<AttributeInfo>> {
        let count = cursor.read_u16::<BigEndian>()?;
        let mut attributes = Vec::new();

        for _ in 0..count {
            attributes.push(Self::parse_attribute(cursor)?);
        }

        Ok(attributes)
    }

    /// 단일 Attribute 파싱
    fn parse_attribute(cursor: &mut Cursor<&[u8]>) -> Result<AttributeInfo> {
        let name_index = cursor.read_u16::<BigEndian>()?;
        let length = cursor.read_u32::<BigEndian>()? as usize;
        let mut data = vec![0u8; length];
        cursor.read_exact(&mut data)?;

        Ok(AttributeInfo { name_index, data })
    }

    /// Code 속성 추출 및 파싱
    fn extract_code_attribute(attributes: &[AttributeInfo]) -> Result<Option<CodeAttribute>> {
        for attr in attributes {
            // name_index를 통해 속성명을 알 수 없으므로, 데이터 구조로 판단
            // 실제로는 CP의 name_index를 통해 "Code"인지 확인해야 함
            // 여기서는 일단 더 이상 파싱하지 않음
        }
        Ok(None)  // 나중에 구현
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_magic() {
        // 간단한 .class 바이트 (magic만)
        let bytes = vec![0xCA, 0xFE, 0xBA, 0xBE];
        let result = ClassFileParser::parse(&bytes);
        // 불완전하므로 Err 예상
    }
}
