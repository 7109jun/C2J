pub mod structures;
pub mod parser;
pub mod validator;
pub mod modern_features;
pub mod jar_reader;

pub use structures::{
    ClassFile, AccessFlags, FieldInfo, MethodInfo, AttributeInfo,
    CodeAttribute, ExceptionHandler, Visibility, java_version_name,
};
pub use parser::ClassFileParser;
pub use validator::ClassFileValidator;
pub use modern_features::{
    extract_record_components, extract_sealed_info,
    extract_bootstrap_methods, extract_inner_classes,
    extract_signature, RecordComponentInfo, SealedInfo,
};
pub use jar_reader::{read_jar, JarContents};
