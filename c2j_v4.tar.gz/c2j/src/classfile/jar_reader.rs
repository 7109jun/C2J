//! JAR 파일 읽기
//!
//! JAR = ZIP 포맷. 직접 ZIP 파싱으로 외부 의존성 없이 구현합니다.
//! .class 파일만 추출하고, META-INF는 건너뜁니다.

use std::io::{Read, Seek, SeekFrom, Cursor};
use std::collections::HashMap;
use byteorder::{LittleEndian, ReadBytesExt};
use crate::utils::{Result, C2JError};

/// JAR에서 추출한 .class 파일 목록
pub struct JarContents {
    /// 내부 경로 → .class 바이트
    pub classes: HashMap<String, Vec<u8>>,
    /// manifest 내용
    pub manifest: Option<String>,
}

impl JarContents {
    /// 메인 클래스 이름 추출 (MANIFEST.MF의 Main-Class)
    pub fn main_class(&self) -> Option<String> {
        let manifest = self.manifest.as_ref()?;
        for line in manifest.lines() {
            if let Some(rest) = line.strip_prefix("Main-Class:") {
                return Some(rest.trim().replace('.', "/"));
            }
        }
        None
    }

    /// 클래스 이름 목록 (패키지 경로 포함, .class 제외)
    pub fn class_names(&self) -> Vec<&str> {
        self.classes.keys()
            .map(|k| k.trim_end_matches(".class"))
            .collect()
    }
}

/// JAR 파일 파싱 (ZIP Central Directory 방식)
pub fn read_jar(data: &[u8]) -> Result<JarContents> {
    let mut cursor = Cursor::new(data);
    let mut classes = HashMap::new();
    let mut manifest = None;

    // ZIP End of Central Directory 시그니처 탐색
    let eocd_offset = find_eocd(data)
        .ok_or_else(|| C2JError::InvalidArgument("JAR: End of Central Directory not found".into()))?;

    cursor.seek(SeekFrom::Start(eocd_offset as u64))?;

    // EOCD: signature(4) + disk_num(2) + start_disk(2) + disk_entries(2)
    //       + total_entries(2) + cd_size(4) + cd_offset(4) + comment_len(2)
    let sig = cursor.read_u32::<LittleEndian>()?;
    if sig != 0x06054b50 {
        return Err(C2JError::InvalidArgument("JAR: Invalid EOCD signature".into()));
    }

    cursor.seek(SeekFrom::Current(6))?; // skip disk fields
    let total_entries = cursor.read_u16::<LittleEndian>()? as usize;
    let _cd_size = cursor.read_u32::<LittleEndian>()?;
    let cd_offset = cursor.read_u32::<LittleEndian>()? as usize;

    // Central Directory 순회
    cursor.seek(SeekFrom::Start(cd_offset as u64))?;

    for _ in 0..total_entries {
        let sig = cursor.read_u32::<LittleEndian>()?;
        if sig != 0x02014b50 {
            break; // Central Directory 끝
        }

        // Central Directory Entry
        cursor.seek(SeekFrom::Current(6))?;   // version fields, flags
        let _compression = cursor.read_u16::<LittleEndian>()?;
        cursor.seek(SeekFrom::Current(8))?;   // mod time/date, crc32
        let compressed_size   = cursor.read_u32::<LittleEndian>()? as usize;
        let _uncompressed_size = cursor.read_u32::<LittleEndian>()?;
        let name_len    = cursor.read_u16::<LittleEndian>()? as usize;
        let extra_len   = cursor.read_u16::<LittleEndian>()? as usize;
        let comment_len = cursor.read_u16::<LittleEndian>()? as usize;
        cursor.seek(SeekFrom::Current(8))?;   // disk/attrs
        let local_header_offset = cursor.read_u32::<LittleEndian>()? as usize;

        let mut name_bytes = vec![0u8; name_len];
        cursor.read_exact(&mut name_bytes)?;
        let name = String::from_utf8_lossy(&name_bytes).to_string();
        cursor.seek(SeekFrom::Current((extra_len + comment_len) as i64))?;

        // .class 파일 또는 MANIFEST만 처리
        let is_class    = name.ends_with(".class") && !name.starts_with("META-INF/");
        let is_manifest = name == "META-INF/MANIFEST.MF";
        if !is_class && !is_manifest { continue; }

        // Local File Header에서 실제 데이터 읽기
        let saved_pos = cursor.position();
        cursor.seek(SeekFrom::Start(local_header_offset as u64))?;

        let local_sig = cursor.read_u32::<LittleEndian>()?;
        if local_sig != 0x04034b50 {
            cursor.seek(SeekFrom::Start(saved_pos))?;
            continue;
        }

        cursor.seek(SeekFrom::Current(2))?; // version
        let flags       = cursor.read_u16::<LittleEndian>()?;
        let compression = cursor.read_u16::<LittleEndian>()?;
        cursor.seek(SeekFrom::Current(8))?; // mod, crc
        let comp_size   = cursor.read_u32::<LittleEndian>()? as usize;
        let uncomp_size = cursor.read_u32::<LittleEndian>()? as usize;
        let lname_len   = cursor.read_u16::<LittleEndian>()? as usize;
        let lextra_len  = cursor.read_u16::<LittleEndian>()? as usize;
        cursor.seek(SeekFrom::Current((lname_len + lextra_len) as i64))?;

        let mut compressed = vec![0u8; comp_size];
        cursor.read_exact(&mut compressed)?;

        // 압축 해제
        let raw = match compression {
            0 => compressed, // STORE (비압축)
            8 => {
                // DEFLATE
                inflate_raw(&compressed, uncomp_size)
                    .unwrap_or_else(|_| vec![])
            }
            _ => {
                cursor.seek(SeekFrom::Start(saved_pos))?;
                continue; // 미지원 압축
            }
        };

        if raw.is_empty() {
            cursor.seek(SeekFrom::Start(saved_pos))?;
            continue;
        }

        if is_class {
            classes.insert(name, raw);
        } else if is_manifest {
            manifest = String::from_utf8(raw).ok();
        }

        cursor.seek(SeekFrom::Start(saved_pos))?;
    }

    Ok(JarContents { classes, manifest })
}

/// EOCD(End of Central Directory) 시그니처 위치 탐색
fn find_eocd(data: &[u8]) -> Option<usize> {
    let sig = [0x50u8, 0x4B, 0x05, 0x06];
    let min_eocd_size = 22;
    if data.len() < min_eocd_size { return None; }

    // 뒤에서부터 탐색 (ZIP comment가 있을 수 있으므로)
    let search_start = data.len().saturating_sub(65535 + 22);
    for i in (search_start..=data.len() - 4).rev() {
        if data[i..i+4] == sig {
            return Some(i);
        }
    }
    None
}

/// DEFLATE 압축 해제 (순수 Rust 구현 — miniz 없이)
/// 표준 deflate RFC 1951 구현
fn inflate_raw(compressed: &[u8], expected_size: usize) -> Result<Vec<u8>> {
    // 간단한 inflate 구현 (stored blocks + fixed/dynamic huffman)
    let mut out = Vec::with_capacity(expected_size);
    let mut bits = BitReader::new(compressed);

    loop {
        let bfinal = bits.read_bit()?;
        let btype = bits.read_bits(2)?;

        match btype {
            0b00 => {
                // STORED block
                bits.align_byte();
                let len  = bits.read_u16_le()?;
                let nlen = bits.read_u16_le()?;
                if len ^ nlen != 0xFFFF {
                    return Err(C2JError::InvalidBytecode(0, "deflate: invalid stored block".into()));
                }
                for _ in 0..len {
                    out.push(bits.read_byte()?);
                }
            }
            0b01 => {
                // Fixed Huffman
                inflate_huffman_fixed(&mut bits, &mut out)?;
            }
            0b10 => {
                // Dynamic Huffman
                inflate_huffman_dynamic(&mut bits, &mut out)?;
            }
            _ => return Err(C2JError::InvalidBytecode(0, "deflate: reserved btype".into())),
        }

        if bfinal == 1 { break; }
    }

    Ok(out)
}

struct BitReader<'a> {
    data: &'a [u8],
    byte_pos: usize,
    bit_pos: u8,   // 현재 바이트 내 비트 위치 (0=LSB)
}

impl<'a> BitReader<'a> {
    fn new(data: &'a [u8]) -> Self {
        BitReader { data, byte_pos: 0, bit_pos: 0 }
    }

    fn read_bit(&mut self) -> Result<u8> {
        if self.byte_pos >= self.data.len() {
            return Err(C2JError::InvalidBytecode(0, "deflate: unexpected EOF".into()));
        }
        let bit = (self.data[self.byte_pos] >> self.bit_pos) & 1;
        self.bit_pos += 1;
        if self.bit_pos == 8 {
            self.bit_pos = 0;
            self.byte_pos += 1;
        }
        Ok(bit)
    }

    fn read_bits(&mut self, n: u8) -> Result<u32> {
        let mut val = 0u32;
        for i in 0..n {
            val |= (self.read_bit()? as u32) << i;
        }
        Ok(val)
    }

    fn read_bits_rev(&mut self, n: u8) -> Result<u32> {
        // MSB-first (Huffman 코드용)
        let mut val = 0u32;
        for _ in 0..n {
            val = (val << 1) | (self.read_bit()? as u32);
        }
        Ok(val)
    }

    fn align_byte(&mut self) {
        if self.bit_pos != 0 {
            self.bit_pos = 0;
            self.byte_pos += 1;
        }
    }

    fn read_byte(&mut self) -> Result<u8> {
        Ok(self.read_bits(8)? as u8)
    }

    fn read_u16_le(&mut self) -> Result<u16> {
        let lo = self.read_byte()? as u16;
        let hi = self.read_byte()? as u16;
        Ok(lo | (hi << 8))
    }
}

// Fixed Huffman 코드 테이블 (RFC 1951)
fn fixed_litlen_decode(bits: &mut BitReader) -> Result<u32> {
    let code7 = bits.read_bits_rev(7)?;
    match code7 {
        0b0000000..=0b0010111 => Ok(256 + code7),          // 256-279: 7bit
        _ => {
            let code = (code7 << 1) | bits.read_bit()? as u32;
            match code {
                0b00110000..=0b10111111 => Ok(code - 0b00110000),   // 0-143: 8bit
                0b11000000..=0b11000111 => Ok(280 + code - 0b11000000), // 280-287
                0b11001000..=0b11111111 => Ok(144 + code - 0b11001000), // 144-255
                _ => Err(C2JError::InvalidBytecode(0, "deflate: bad fixed huffman".into())),
            }
        }
    }
}

fn inflate_huffman_fixed(bits: &mut BitReader, out: &mut Vec<u8>) -> Result<()> {
    loop {
        let sym = fixed_litlen_decode(bits)?;
        match sym {
            0..=255 => out.push(sym as u8),
            256 => break, // end of block
            257..=285 => {
                let (len, dist) = decode_len_dist(bits, sym, true)?;
                copy_back(out, dist, len)?;
            }
            _ => return Err(C2JError::InvalidBytecode(0, "deflate: invalid symbol".into())),
        }
    }
    Ok(())
}

fn inflate_huffman_dynamic(bits: &mut BitReader, out: &mut Vec<u8>) -> Result<()> {
    let hlit  = bits.read_bits(5)? as usize + 257;
    let hdist = bits.read_bits(5)? as usize + 1;
    let hclen = bits.read_bits(4)? as usize + 4;

    // Code length alphabet 순서
    const CLEN_ORDER: [usize; 19] = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
    let mut clen_lengths = [0u8; 19];
    for i in 0..hclen {
        clen_lengths[CLEN_ORDER[i]] = bits.read_bits(3)? as u8;
    }

    let clen_table = HuffmanTable::from_lengths(&clen_lengths)?;
    let mut lengths = vec![0u8; hlit + hdist];
    let mut i = 0;
    while i < lengths.len() {
        let sym = clen_table.decode(bits)?;
        match sym {
            0..=15 => { lengths[i] = sym as u8; i += 1; }
            16 => {
                let rep = bits.read_bits(2)? as usize + 3;
                let last = if i > 0 { lengths[i-1] } else { 0 };
                for _ in 0..rep { if i < lengths.len() { lengths[i] = last; i += 1; } }
            }
            17 => {
                let rep = bits.read_bits(3)? as usize + 3;
                for _ in 0..rep { if i < lengths.len() { lengths[i] = 0; i += 1; } }
            }
            18 => {
                let rep = bits.read_bits(7)? as usize + 11;
                for _ in 0..rep { if i < lengths.len() { lengths[i] = 0; i += 1; } }
            }
            _ => return Err(C2JError::InvalidBytecode(0, "deflate: bad clen sym".into())),
        }
    }

    let litlen_table = HuffmanTable::from_lengths(&lengths[..hlit])?;
    let dist_table   = HuffmanTable::from_lengths(&lengths[hlit..])?;

    loop {
        let sym = litlen_table.decode(bits)?;
        match sym {
            0..=255 => out.push(sym as u8),
            256 => break,
            257..=285 => {
                let (len, dist) = decode_len_dist_dyn(bits, sym, &dist_table)?;
                copy_back(out, dist, len)?;
            }
            _ => return Err(C2JError::InvalidBytecode(0, "deflate: invalid litlen sym".into())),
        }
    }
    Ok(())
}

struct HuffmanTable {
    codes: Vec<(u32, u8, u32)>, // (code, bits, symbol)
}

impl HuffmanTable {
    fn from_lengths(lengths: &[u8]) -> Result<Self> {
        let max_bits = *lengths.iter().max().unwrap_or(&0) as usize;
        if max_bits == 0 { return Ok(HuffmanTable { codes: vec![] }); }

        let mut bl_count = vec![0usize; max_bits + 1];
        for &l in lengths { if l > 0 { bl_count[l as usize] += 1; } }

        let mut next_code = vec![0u32; max_bits + 2];
        let mut code = 0u32;
        for bits in 1..=max_bits {
            code = (code + bl_count[bits - 1] as u32) << 1;
            next_code[bits] = code;
        }

        let mut codes = Vec::new();
        for (sym, &len) in lengths.iter().enumerate() {
            if len > 0 {
                let c = next_code[len as usize];
                codes.push((c, len, sym as u32));
                next_code[len as usize] += 1;
            }
        }
        Ok(HuffmanTable { codes })
    }

    fn decode(&self, bits: &mut BitReader) -> Result<u32> {
        let mut code = 0u32;
        let mut nbits = 0u8;
        for _ in 0..16 {
            code = (code << 1) | bits.read_bit()? as u32;
            nbits += 1;
            for &(c, b, sym) in &self.codes {
                if b == nbits && c == code { return Ok(sym); }
            }
        }
        Err(C2JError::InvalidBytecode(0, "deflate: huffman decode failed".into()))
    }
}

// Length/Distance 코드 처리 (Fixed)
fn decode_len_dist(bits: &mut BitReader, sym: u32, fixed: bool) -> Result<(usize, usize)> {
    let len = decode_length(bits, sym)?;
    let dist_code = if fixed {
        bits.read_bits_rev(5)? as u32
    } else { 0 };
    let dist = decode_distance_fixed(bits, dist_code)?;
    Ok((len, dist))
}

fn decode_len_dist_dyn(bits: &mut BitReader, sym: u32, dist_table: &HuffmanTable) -> Result<(usize, usize)> {
    let len = decode_length(bits, sym)?;
    let dist_code = dist_table.decode(bits)?;
    let dist = decode_distance_fixed(bits, dist_code)?;
    Ok((len, dist))
}

fn decode_length(bits: &mut BitReader, sym: u32) -> Result<usize> {
    const LEN_BASE: [usize; 29] = [
        3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,
        35,43,51,59,67,83,99,115,131,163,195,227,258
    ];
    const LEN_EXTRA: [u8; 29] = [
        0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,
        3,3,3,3,4,4,4,4,5,5,5,5,0
    ];
    let idx = (sym - 257) as usize;
    if idx >= 29 { return Err(C2JError::InvalidBytecode(0, "deflate: bad len sym".into())); }
    let extra = bits.read_bits(LEN_EXTRA[idx])? as usize;
    Ok(LEN_BASE[idx] + extra)
}

fn decode_distance_fixed(bits: &mut BitReader, code: u32) -> Result<usize> {
    const DIST_BASE: [usize; 30] = [
        1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,
        257,385,513,769,1025,1537,2049,3073,4097,6145,
        8193,12289,16385,24577
    ];
    const DIST_EXTRA: [u8; 30] = [
        0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,
        7,7,8,8,9,9,10,10,11,11,12,12,13,13
    ];
    let idx = code as usize;
    if idx >= 30 { return Err(C2JError::InvalidBytecode(0, "deflate: bad dist code".into())); }
    let extra = bits.read_bits(DIST_EXTRA[idx])? as usize;
    Ok(DIST_BASE[idx] + extra)
}

fn copy_back(out: &mut Vec<u8>, dist: usize, len: usize) -> Result<()> {
    if dist > out.len() {
        return Err(C2JError::InvalidBytecode(0, "deflate: back-reference out of range".into()));
    }
    let start = out.len() - dist;
    for i in 0..len {
        let b = out[start + (i % dist)];
        out.push(b);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_find_eocd_too_short() {
        let result = find_eocd(&[0u8; 5]);
        assert!(result.is_none());
    }

    #[test]
    fn test_jar_invalid_data() {
        let result = read_jar(b"not a jar file");
        assert!(result.is_err());
    }

    #[test]
    fn test_bit_reader_basic() {
        let data = [0b10110101u8];
        let mut r = BitReader::new(&data);
        assert_eq!(r.read_bit().unwrap(), 1); // LSB first
        assert_eq!(r.read_bit().unwrap(), 0);
        assert_eq!(r.read_bit().unwrap(), 1);
        assert_eq!(r.read_bit().unwrap(), 0);
    }
}
