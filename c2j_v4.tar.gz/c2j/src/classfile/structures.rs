//! JVM Class File 구조체 정의
//! 
//! 이 모듈은 JVM Class File Format Specification (Java 11-17)에 따른
//! 모든 구조체를 정의합니다.

use std::collections::HashMap;
use crate::constantpool::ConstantPoolEntry;

/// JVM Class File 전체 구조
#[derive(Debug, Clone)]
pub struct ClassFile {
    pub magic: u32,                          // 0xCAFEBABE
    pub minor_version: u16,
    pub major_version: u16,
    pub constant_pool: Vec<Option<ConstantPoolEntry>>,  // 1-indexed
    pub access_flags: AccessFlags,
    pub this_class: u16,
    pub super_class: u16,
    pub interfaces: Vec<u16>,
    pub fields: Vec<FieldInfo>,
    pub methods: Vec<MethodInfo>,
    pub attributes: Vec<AttributeInfo>,
}

/// Access Flags (bit flags)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AccessFlags(pub u16);

impl AccessFlags {
    pub const PUBLIC: u16 = 0x0001;
    pub const FINAL: u16 = 0x0010;
    pub const SUPER: u16 = 0x0020;
    pub const INTERFACE: u16 = 0x0200;
    pub const ABSTRACT: u16 = 0x0400;
    pub const SYNTHETIC: u16 = 0x1000;
    pub const ANNOTATION: u16 = 0x2000;
    pub const ENUM: u16 = 0x4000;
    pub const MODULE: u16 = 0x8000;

    // Method/Field specific flags
    pub const STATIC: u16 = 0x0008;
    pub const VOLATILE: u16 = 0x0040;
    pub const TRANSIENT: u16 = 0x0080;
    pub const SYNCHRONIZED: u16 = 0x0020;
    pub const NATIVE: u16 = 0x0100;
    pub const STRICT: u16 = 0x0800;
    pub const PRIVATE: u16 = 0x0002;
    pub const PROTECTED: u16 = 0x0004;

    pub fn is_public(&self) -> bool {
        (self.0 & Self::PUBLIC) != 0
    }

    pub fn is_static(&self) -> bool {
        (self.0 & Self::STATIC) != 0
    }

    pub fn is_final(&self) -> bool {
        (self.0 & Self::FINAL) != 0
    }

    pub fn is_abstract(&self) -> bool {
        (self.0 & Self::ABSTRACT) != 0
    }

    pub fn is_interface(&self) -> bool {
        (self.0 & Self::INTERFACE) != 0
    }

    pub fn is_enum(&self) -> bool {
        (self.0 & Self::ENUM) != 0
    }

    pub fn is_synthetic(&self) -> bool {
        (self.0 & Self::SYNTHETIC) != 0
    }

    pub fn is_native(&self) -> bool {
        (self.0 & Self::NATIVE) != 0
    }

    pub fn is_synchronized(&self) -> bool {
        (self.0 & Self::SYNCHRONIZED) != 0
    }

    pub fn is_volatile(&self) -> bool {
        (self.0 & Self::VOLATILE) != 0
    }

    pub fn is_transient(&self) -> bool {
        (self.0 & Self::TRANSIENT) != 0
    }

    pub fn is_private(&self) -> bool {
        (self.0 & Self::PRIVATE) != 0
    }

    pub fn is_protected(&self) -> bool {
        (self.0 & Self::PROTECTED) != 0
    }

    pub fn visibility(&self) -> Visibility {
        if self.is_public() {
            Visibility::Public
        } else if self.is_protected() {
            Visibility::Protected
        } else if self.is_private() {
            Visibility::Private
        } else {
            Visibility::Package
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Visibility {
    Public,
    Protected,
    Private,
    Package,
}

impl std::fmt::Display for Visibility {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Visibility::Public => write!(f, "public"),
            Visibility::Protected => write!(f, "protected"),
            Visibility::Private => write!(f, "private"),
            Visibility::Package => write!(f, ""),
        }
    }
}

/// Field 정보
#[derive(Debug, Clone)]
pub struct FieldInfo {
    pub access_flags: AccessFlags,
    pub name_index: u16,
    pub descriptor_index: u16,
    pub attributes: Vec<AttributeInfo>,
}

/// Method 정보
#[derive(Debug, Clone)]
pub struct MethodInfo {
    pub access_flags: AccessFlags,
    pub name_index: u16,
    pub descriptor_index: u16,
    pub attributes: Vec<AttributeInfo>,
    pub code: Option<CodeAttribute>,  // Code attribute 파싱 결과
}

/// Attribute 정보
#[derive(Debug, Clone)]
pub struct AttributeInfo {
    pub name_index: u16,
    pub data: Vec<u8>,
}

/// Code Attribute (Method body)
#[derive(Debug, Clone)]
pub struct CodeAttribute {
    pub max_stack: u16,
    pub max_locals: u16,
    pub code: Vec<u8>,
    pub exception_table: Vec<ExceptionHandler>,
    pub attributes: Vec<AttributeInfo>,
}

/// Exception Handler (try-catch 정보)
#[derive(Debug, Clone, Copy, Eq, PartialEq, Hash)]
pub struct ExceptionHandler {
    pub start_pc: u16,      // handler 시작 위치
    pub end_pc: u16,        // handler 종료 위치 (포함)
    pub handler_pc: u16,    // 처리 코드 시작
    pub catch_type: u16,    // Constant Pool index (0 = finally)
}

/// Local Variable Table Entry
#[derive(Debug, Clone)]
pub struct LocalVariableEntry {
    pub start_pc: u16,
    pub length: u16,
    pub name_index: u16,
    pub descriptor_index: u16,
    pub index: u16,
}

/// Line Number Table Entry
#[derive(Debug, Clone, Copy)]
pub struct LineNumberEntry {
    pub start_pc: u16,
    pub line_number: u16,
}

/// Inner Class 정보
#[derive(Debug, Clone)]
pub struct InnerClassInfo {
    pub inner_class_info_index: u16,
    pub outer_class_info_index: u16,
    pub inner_name_index: u16,
    pub inner_class_access_flags: AccessFlags,
}

/// Bootstrap Method 정보 (invokedynamic용)
#[derive(Debug, Clone)]
pub struct BootstrapMethod {
    pub bootstrap_method_ref: u16,
    pub bootstrap_arguments: Vec<u16>,
}

/// Annotation 정보
#[derive(Debug, Clone)]
pub struct AnnotationInfo {
    pub type_index: u16,
    pub element_value_pairs: Vec<(u16, ElementValue)>,
}

#[derive(Debug, Clone)]
pub enum ElementValue {
    Byte(i8),
    Char(u16),
    Integer(i32),
    Long(i64),
    Float(f32),
    Double(f64),
    Boolean(bool),
    String(u16),           // index to CONSTANT_Utf8
    Enum(u16, u16),        // type_name_index, const_name_index
    Class(u16),            // class_info_index
    Annotation(AnnotationInfo),
    Array(Vec<ElementValue>),
}

/// Method Parameter 정보
#[derive(Debug, Clone)]
pub struct MethodParameter {
    pub name_index: u16,
    pub access_flags: AccessFlags,
}

/// Record Component 정보 (Java 14+)
#[derive(Debug, Clone)]
pub struct RecordComponent {
    pub name_index: u16,
    pub descriptor_index: u16,
    pub attributes: Vec<AttributeInfo>,
}

/// Java 버전 정보 (major_version → 사람이 읽을 수 있는 버전)
pub fn java_version_name(major: u16) -> &'static str {
    match major {
        52 => "Java 8",
        53 => "Java 9",
        54 => "Java 10",
        55 => "Java 11",
        56 => "Java 12",
        57 => "Java 13",
        58 => "Java 14",
        59 => "Java 15",
        60 => "Java 16",
        61 => "Java 17",
        62 => "Java 18",
        63 => "Java 19",
        64 => "Java 20",
        65 => "Java 21",
        66 => "Java 22",
        _ => "Unknown",
    }
}

/// Java 21 신기능 플래그
#[derive(Debug, Clone, Default)]
pub struct Java21Features {
    /// Record 클래스 (Java 16+)
    pub is_record: bool,
    /// Sealed 클래스 (Java 17+)
    pub is_sealed: bool,
    /// Permitted Subclasses 목록 (sealed 전용)
    pub permitted_subclasses: Vec<u16>,
    /// 패턴 매칭 switch (Java 21 정식)
    pub has_pattern_switch: bool,
}

/// NestHost attribute (Java 11+)
#[derive(Debug, Clone)]
pub struct NestHost {
    pub host_class_index: u16,
}

/// NestMembers attribute (Java 11+)
#[derive(Debug, Clone)]
pub struct NestMembers {
    pub classes: Vec<u16>,
}

/// PermittedSubclasses attribute (Java 17+)
#[derive(Debug, Clone)]
pub struct PermittedSubclasses {
    pub classes: Vec<u16>,
}

/// Module attribute (Java 9+)
#[derive(Debug, Clone)]
pub struct ModuleAttribute {
    pub module_name_index: u16,
    pub module_flags: u16,
    pub module_version_index: u16,
    pub requires: Vec<ModuleRequires>,
    pub exports: Vec<ModuleExports>,
    pub opens: Vec<ModuleOpens>,
    pub uses: Vec<u16>,
    pub provides: Vec<ModuleProvides>,
}

#[derive(Debug, Clone)]
pub struct ModuleRequires {
    pub index: u16,
    pub flags: u16,
    pub version_index: u16,
}

#[derive(Debug, Clone)]
pub struct ModuleExports {
    pub index: u16,
    pub flags: u16,
    pub to: Vec<u16>,
}

#[derive(Debug, Clone)]
pub struct ModuleOpens {
    pub index: u16,
    pub flags: u16,
    pub to: Vec<u16>,
}

#[derive(Debug, Clone)]
pub struct ModuleProvides {
    pub index: u16,
    pub with: Vec<u16>,
}
