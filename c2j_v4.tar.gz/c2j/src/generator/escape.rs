//! 문자열·문자 이스케이프

pub fn escape_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    for ch in s.chars() {
        match ch {
            '"'  => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\x08' => out.push_str("\\b"),
            '\x0C' => out.push_str("\\f"),
            c if (c as u32) < 0x20 || c as u32 == 0x7F => {
                out.push_str(&format!("\\u{:04X}", c as u32));
            }
            c => out.push(c),
        }
    }
    out
}

pub fn escape_char(ch: char) -> String {
    match ch {
        '\'' => "\\'".into(),
        '\\' => "\\\\".into(),
        '\n' => "\\n".into(),
        '\r' => "\\r".into(),
        '\t' => "\\t".into(),
        c if (c as u32) < 0x20 => format!("\\u{:04X}", c as u32),
        c => c.to_string(),
    }
}

pub fn is_java_keyword(s: &str) -> bool {
    matches!(s,
        "abstract"|"assert"|"boolean"|"break"|"byte"|"case"|"catch"|"char"|
        "class"|"const"|"continue"|"default"|"do"|"double"|"else"|"enum"|
        "extends"|"final"|"finally"|"float"|"for"|"goto"|"if"|"implements"|
        "import"|"instanceof"|"int"|"interface"|"long"|"native"|"new"|
        "package"|"private"|"protected"|"public"|"return"|"short"|"static"|
        "strictfp"|"super"|"switch"|"synchronized"|"this"|"throw"|"throws"|
        "transient"|"try"|"var"|"void"|"volatile"|"while"|
        // Java 14+ 예약어
        "record"|"sealed"|"permits"|"yield"
    )
}

pub fn safe_name(name: &str) -> String {
    if is_java_keyword(name) {
        format!("{}_", name)
    } else {
        name.to_string()
    }
}
