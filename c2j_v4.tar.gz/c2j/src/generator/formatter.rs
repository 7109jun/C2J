//! Java 소스 포매터

pub struct Formatter {
    indent_level: usize,
    indent_str: String,
    buf: String,
}

impl Formatter {
    pub fn new() -> Self {
        Formatter { indent_level: 0, indent_str: "    ".into(), buf: String::new() }
    }

    pub fn indent(&mut self) { self.indent_level += 1; }
    pub fn dedent(&mut self) { if self.indent_level > 0 { self.indent_level -= 1; } }

    pub fn line(&mut self, s: &str) {
        for _ in 0..self.indent_level { self.buf.push_str(&self.indent_str); }
        self.buf.push_str(s);
        self.buf.push('\n');
    }

    pub fn blank(&mut self) { self.buf.push('\n'); }

    pub fn into_string(self) -> String { self.buf }

    pub fn current(&self) -> &str { &self.buf }
}

impl Default for Formatter {
    fn default() -> Self { Self::new() }
}
