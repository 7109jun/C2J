//! 구조화된 제어문(StructuredStmt) → Java 소스 출력

use crate::ir::structurizer::{StructuredStmt, SwitchCase};
use crate::ir::{IrStmt, IrExpr, CompareOp};
use crate::generator::formatter::Formatter;
use crate::generator::escape::safe_name;
use crate::analysis::stack::JvmType;
use crate::analysis::types::jvm_type_to_java;

/// StructuredStmt 목록 → Formatter에 출력
pub fn gen_structured(stmts: &[StructuredStmt], fmt: &mut Formatter) {
    for stmt in stmts {
        gen_one(stmt, fmt);
    }
}

fn gen_one(stmt: &StructuredStmt, fmt: &mut Formatter) {
    match stmt {
        StructuredStmt::Stmt(ir) => gen_ir_stmt(ir, fmt),

        StructuredStmt::If { cond, then_body, else_body } => {
            fmt.line(&format!("if ({}) {{", gen_expr_str(cond)));
            fmt.indent();
            gen_structured(then_body, fmt);
            fmt.dedent();
            if let Some(else_stmts) = else_body {
                if else_stmts.len() == 1 {
                    if let StructuredStmt::If { .. } = &else_stmts[0] {
                        // else if 패턴
                        fmt.line("} else ");
                        fmt.indent();
                        gen_one(&else_stmts[0], fmt);
                        fmt.dedent();
                        return;
                    }
                }
                fmt.line("} else {");
                fmt.indent();
                gen_structured(else_stmts, fmt);
                fmt.dedent();
            }
            fmt.line("}");
        }

        StructuredStmt::While { cond, body, label } => {
            let label_str = label.as_deref().map(|l| format!("{}: ", l)).unwrap_or_default();
            fmt.line(&format!("{}while ({}) {{", label_str, gen_expr_str(cond)));
            fmt.indent();
            gen_structured(body, fmt);
            fmt.dedent();
            fmt.line("}");
        }

        StructuredStmt::DoWhile { body, cond, label } => {
            let label_str = label.as_deref().map(|l| format!("{}: ", l)).unwrap_or_default();
            fmt.line(&format!("{}do {{", label_str));
            fmt.indent();
            gen_structured(body, fmt);
            fmt.dedent();
            fmt.line(&format!("}} while ({});", gen_expr_str(cond)));
        }

        StructuredStmt::For { init, cond, update, body, label } => {
            let init_s = init.as_ref().map(|s| ir_stmt_inline(s)).unwrap_or_default();
            let cond_s = gen_expr_str(cond);
            let upd_s  = update.as_ref().map(|s| ir_stmt_inline(s)).unwrap_or_default();
            let label_str = label.as_deref().map(|l| format!("{}: ", l)).unwrap_or_default();
            fmt.line(&format!("{}for ({}; {}; {}) {{", label_str, init_s, cond_s, upd_s));
            fmt.indent();
            gen_structured(body, fmt);
            fmt.dedent();
            fmt.line("}");
        }

        StructuredStmt::Switch { expr, cases, default } => {
            fmt.line(&format!("switch ({}) {{", gen_expr_str(expr)));
            fmt.indent();
            for case in cases {
                fmt.line(&format!("case {}:", case.value));
                fmt.indent();
                gen_structured(&case.body, fmt);
                if case.has_break { fmt.line("break;"); }
                fmt.dedent();
            }
            if !default.is_empty() {
                fmt.line("default:");
                fmt.indent();
                gen_structured(default, fmt);
                fmt.line("break;");
                fmt.dedent();
            }
            fmt.dedent();
            fmt.line("}");
        }

        StructuredStmt::Break(label) => {
            if let Some(l) = label {
                fmt.line(&format!("break {};", l));
            } else {
                fmt.line("break;");
            }
        }

        StructuredStmt::Continue(label) => {
            if let Some(l) = label {
                fmt.line(&format!("continue {};", l));
            } else {
                fmt.line("continue;");
            }
        }

        StructuredStmt::Label(name, body) => {
            if name != "_block" {
                fmt.line(&format!("{}: {{", name));
                fmt.indent();
                gen_structured(body, fmt);
                fmt.dedent();
                fmt.line("}");
            } else {
                gen_structured(body, fmt);
            }
        }
    }
}

fn gen_ir_stmt(stmt: &IrStmt, fmt: &mut Formatter) {
    match stmt {
        IrStmt::Assign(name, ty, expr) => {
            fmt.line(&format!("{} = {};", safe_name(name), gen_expr_str(expr)));
        }
        IrStmt::ExprStmt(expr) => {
            fmt.line(&format!("{};", gen_expr_str(expr)));
        }
        IrStmt::Return(None) => { fmt.line("return;"); }
        IrStmt::Return(Some(e)) => { fmt.line(&format!("return {};", gen_expr_str(e))); }
        IrStmt::Throw(e) => { fmt.line(&format!("throw {};", gen_expr_str(e))); }
        IrStmt::Goto(t) => { fmt.line(&format!("/* goto pc_{} */", t)); }
        IrStmt::If(cond, then_pc, _) => {
            fmt.line(&format!("if ({}) {{ /* pc_{} */ }}", gen_expr_str(cond), then_pc));
        }
        IrStmt::Switch(key, cases, def) => {
            fmt.line(&format!("switch ({}) {{", gen_expr_str(key)));
            fmt.indent();
            for (val, pc) in cases {
                fmt.line(&format!("case {}: /* pc_{} */ break;", val, pc));
            }
            fmt.line(&format!("default: /* pc_{} */ break;", def));
            fmt.dedent();
            fmt.line("}");
        }
        IrStmt::Label(pc) => {
            // 불필요한 레이블은 주석으로
        }
        IrStmt::TryCatch { try_stmts, catches, finally } => {
            fmt.line("try {");
            fmt.indent();
            for s in try_stmts { gen_ir_stmt(s, fmt); }
            fmt.dedent();
            for (ty, var, stmts) in catches {
                let ty_s = ty.as_deref().unwrap_or("Throwable");
                fmt.line(&format!("}} catch ({} {}) {{", ty_s, safe_name(var)));
                fmt.indent();
                for s in stmts { gen_ir_stmt(s, fmt); }
                fmt.dedent();
            }
            if let Some(fin) = finally {
                fmt.line("} finally {");
                fmt.indent();
                for s in fin { gen_ir_stmt(s, fmt); }
                fmt.dedent();
            }
            fmt.line("}");
        }
        IrStmt::MonitorEnter(e) => { fmt.line(&format!("// monitorenter {}", gen_expr_str(e))); }
        IrStmt::MonitorExit(e)  => { fmt.line(&format!("// monitorexit {}", gen_expr_str(e))); }
        IrStmt::ArrayStore(arr, idx, val) => {
            fmt.line(&format!("{}[{}] = {};", gen_expr_str(arr), gen_expr_str(idx), gen_expr_str(val)));
        }
        IrStmt::FieldPut(obj, cls, fld, val, is_static) => {
            let target = if *is_static {
                format!("{}.{}", crate::analysis::types::simple_class_name(cls), safe_name(fld))
            } else {
                let o = obj.as_ref().map(|e| gen_expr_str(e)).unwrap_or_else(|| "this".into());
                format!("{}.{}", o, safe_name(fld))
            };
            fmt.line(&format!("{} = {};", target, gen_expr_str(val)));
        }
        IrStmt::Iinc(name, delta) => {
            match delta {
                1  => fmt.line(&format!("{}++;", safe_name(name))),
                -1 => fmt.line(&format!("{}--;", safe_name(name))),
                d if *d > 0 => fmt.line(&format!("{} += {};", safe_name(name), d)),
                d => fmt.line(&format!("{} -= {};", safe_name(name), -d)),
            }
        }
        IrStmt::Nop => {}
    }
}

/// IrStmt → 한 줄 인라인 (for 루프의 init/update용)
pub fn ir_stmt_inline(stmt: &StructuredStmt) -> String {
    match stmt {
        StructuredStmt::Stmt(IrStmt::Assign(n, _, e)) =>
            format!("{} = {}", safe_name(n), gen_expr_str(e)),
        StructuredStmt::Stmt(IrStmt::Iinc(n, 1)) =>
            format!("{}++", safe_name(n)),
        StructuredStmt::Stmt(IrStmt::Iinc(n, -1)) =>
            format!("{}--", safe_name(n)),
        StructuredStmt::Stmt(IrStmt::Iinc(n, d)) =>
            format!("{} += {}", safe_name(n), d),
        StructuredStmt::Stmt(IrStmt::ExprStmt(e)) =>
            gen_expr_str(e),
        _ => String::new(),
    }
}

// ─── 표현식 생성 ────────────────────────────────────────────────────────────

pub fn gen_expr_str(expr: &IrExpr) -> String {
    use IrExpr::*;
    match expr {
        Null           => "null".into(),
        IntLit(n)      => n.to_string(),
        LongLit(n)     => format!("{}L", n),
        FloatLit(f)    => format_float(*f),
        DoubleLit(d)   => format_double(*d),
        BoolLit(b)     => if *b { "true" } else { "false" }.into(),
        StringLit(s)   => crate::ir::textblock::string_to_java_literal(s, true),
        ClassLit(cls)  => format!("{}.class", crate::analysis::types::simple_class_name(cls)),

        This           => "this".into(),
        LocalVar(n, _) => safe_name(n),
        TempVar(id, _) => format!("_t{}", id),

        BinaryOp(a, op, b, _) => {
            match op {
                crate::ir::BinaryOp::LCmp |
                crate::ir::BinaryOp::FCmpL | crate::ir::BinaryOp::FCmpG |
                crate::ir::BinaryOp::DCmpL | crate::ir::BinaryOp::DCmpG => {
                    format!("Long.compare({}, {})", gen_expr_paren(a, op), gen_expr_paren(b, op))
                }
                _ => format!("{} {} {}",
                    gen_expr_paren(a, op), op.to_java_symbol(), gen_expr_paren(b, op))
            }
        }
        UnaryOp(op, e, _) => {
            let sym = match op {
                crate::ir::UnaryOp::Neg => "-",
                crate::ir::UnaryOp::Not => "!",
                crate::ir::UnaryOp::BitwiseNot => "~",
            };
            format!("{}{}", sym, gen_expr_str(e))
        }
        Cast(e, ty) => format!("({}){}", jvm_type_to_java(ty, true), gen_expr_str(e)),

        StaticField(cls, fld, _) =>
            format!("{}.{}", crate::analysis::types::simple_class_name(cls), safe_name(fld)),
        InstanceField(obj, _, fld, _) =>
            format!("{}.{}", gen_expr_str(obj), safe_name(fld)),

        StaticCall(cls, mth, _, args, _) => {
            let args_s = args.iter().map(gen_expr_str).collect::<Vec<_>>().join(", ");
            format!("{}.{}({})", crate::analysis::types::simple_class_name(cls), safe_name(mth), args_s)
        }
        VirtualCall(obj, _, mth, _, args, _) |
        InterfaceCall(obj, _, mth, _, args, _) => {
            let args_s = args.iter().map(gen_expr_str).collect::<Vec<_>>().join(", ");
            format!("{}.{}({})", gen_expr_str(obj), safe_name(mth), args_s)
        }
        SpecialCall(obj, cls, mth, _, args, _) => {
            let args_s = args.iter().map(gen_expr_str).collect::<Vec<_>>().join(", ");
            if mth == "<init>" {
                // super() / this()
                let target = if cls == "super" || cls == "this" { cls.clone() }
                             else { format!("super /*{}*/", crate::analysis::types::simple_class_name(cls)) };
                format!("{}({})", target, args_s)
            } else {
                format!("{}.{}({})", gen_expr_str(obj), safe_name(mth), args_s)
            }
        }
        DynamicCall(name, desc, args, _) => {
            // lambda / method reference
            crate::ir::lambda::dynamic_call_to_lambda(name, desc, args, &dummy_cp(), &[])
        }

        NewObject(cls, args) => {
            let args_s = args.iter().map(gen_expr_str).collect::<Vec<_>>().join(", ");
            format!("new {}({})", crate::analysis::types::simple_class_name(cls), args_s)
        }
        NewArray(ty, sz) =>
            format!("new {}[{}]", jvm_type_to_java(ty, true), gen_expr_str(sz)),
        NewMultiArray(ty, dims) => {
            let ty_s = jvm_type_to_java(ty, true);
            let dims_s = dims.iter().map(|d| format!("[{}]", gen_expr_str(d))).collect::<Vec<_>>().join("");
            format!("new {}{}", ty_s, dims_s)
        }
        ArrayAccess(arr, idx, _) =>
            format!("{}[{}]", gen_expr_str(arr), gen_expr_str(idx)),
        ArrayLength(arr) =>
            format!("{}.length", gen_expr_str(arr)),

        InstanceOf(obj, cls) =>
            format!("{} instanceof {}", gen_expr_str(obj), crate::analysis::types::simple_class_name(cls)),
        Checkcast(obj, cls) =>
            format!("({}){}", crate::analysis::types::simple_class_name(cls), gen_expr_str(obj)),

        CompareOp(a, op, b) => match op {
            crate::ir::CompareOp::Null    => format!("{} == null", gen_expr_str(a)),
            crate::ir::CompareOp::NotNull => format!("{} != null", gen_expr_str(a)),
            _ => format!("{} {} {}", gen_expr_str(a), op.to_java_symbol(), gen_expr_str(b)),
        },
        Ternary(c, t, f, _) =>
            format!("({} ? {} : {})", gen_expr_str(c), gen_expr_str(t), gen_expr_str(f)),
    }
}

fn gen_expr_paren(expr: &IrExpr, parent: &crate::ir::BinaryOp) -> String {
    let s = gen_expr_str(expr);
    match expr {
        IrExpr::BinaryOp(_, op, _, _) if prec(op) < prec(parent) => format!("({})", s),
        _ => s,
    }
}

fn prec(op: &crate::ir::BinaryOp) -> u8 {
    use crate::ir::BinaryOp::*;
    match op {
        Or => 1, Xor => 2, And => 3,
        Add | Sub => 4, Mul | Div | Rem => 5,
        Shl | Shr | UShr => 3,
        _ => 6,
    }
}

fn format_float(f: f32) -> String {
    if f.is_nan() { "Float.NaN".into() }
    else if f.is_infinite() {
        if f > 0.0 { "Float.POSITIVE_INFINITY".into() } else { "Float.NEGATIVE_INFINITY".into() }
    } else { format!("{}f", f) }
}

fn format_double(d: f64) -> String {
    if d.is_nan() { "Double.NaN".into() }
    else if d.is_infinite() {
        if d > 0.0 { "Double.POSITIVE_INFINITY".into() } else { "Double.NEGATIVE_INFINITY".into() }
    } else {
        // 정수인 경우 소수점 유지
        if d.fract() == 0.0 { format!("{}.0d", d as i64) } else { format!("{}d", d) }
    }
}

fn dummy_cp() -> crate::constantpool::ConstantPool {
    crate::constantpool::ConstantPool::new()
}
