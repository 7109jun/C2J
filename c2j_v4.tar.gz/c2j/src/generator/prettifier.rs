//! 생성된 Java 소스 가독성 개선 (post-processing)
//!
//! JavaGenerator가 만든 소스를 한 번 더 다듬어 사람이 읽기 좋게 만듭니다.
//!
//! 처리 목록:
//!   1. 불필요한 캐스트 제거       (int)(x) where x is int → x
//!   2. 연속 빈 줄 정리           3+ blank lines → 1 blank line
//!   3. 의미 없는 boolean 표현    != 0 / == 0 → 가독성 있는 형태로
//!   4. 불필요한 this. 제거       일반 필드 접근에서
//!   5. 임시 변수 인라인          _t0 = expr; return _t0; → return expr;
//!   6. iinc 패턴 정리           i = i + 1 → i++
//!   7. 빈 생성자 정리            default constructor body 비움
//!   8. import 중복 제거 및 정렬

/// Java 소스 후처리
pub fn prettify(src: &str) -> String {
    let mut out = src.to_string();
    out = remove_redundant_blank_lines(&out);
    out = inline_temp_vars(&out);
    out = simplify_boolean_expressions(&out);
    out = simplify_iinc(&out);
    out = sort_imports(&out);
    out = normalize_spacing(&out);
    out
}

/// 연속 빈 줄 3개 이상 → 1개로
fn remove_redundant_blank_lines(src: &str) -> String {
    let mut out = String::with_capacity(src.len());
    let mut blank_count = 0usize;

    for line in src.lines() {
        if line.trim().is_empty() {
            blank_count += 1;
            if blank_count <= 1 {
                out.push('\n');
            }
        } else {
            blank_count = 0;
            out.push_str(line);
            out.push('\n');
        }
    }
    out
}

/// _t0 = expr; return _t0; → return expr;
/// _t0 = expr; x = _t0;   → x = expr;
fn inline_temp_vars(src: &str) -> String {
    let lines: Vec<&str> = src.lines().collect();
    let mut out: Vec<String> = Vec::with_capacity(lines.len());
    let mut skip = std::collections::HashSet::new();

    for i in 0..lines.len() {
        if skip.contains(&i) { continue; }

        let trimmed = lines[i].trim();

        // "_t<N> = <expr>;" 패턴 감지
        if let Some(rest) = trimmed.strip_prefix("_t") {
            if let Some(eq_pos) = rest.find(" = ") {
                let idx_str = &rest[..eq_pos];
                if idx_str.chars().all(|c| c.is_ascii_digit()) {
                    let var_name = format!("_t{}", idx_str);
                    let expr = rest[eq_pos + 3..].trim_end_matches(';').trim();

                    // 다음 줄이 이 변수를 사용하는지 확인
                    if i + 1 < lines.len() {
                        let next = lines[i + 1].trim();

                        // return _t<N>;  패턴
                        if next == format!("return {};", var_name) {
                            let indent = get_indent(lines[i + 1]);
                            out.push(format!("{}return {};", indent, expr));
                            skip.insert(i + 1);
                            continue;
                        }

                        // <var> = _t<N>;  패턴
                        if let Some(assign_rest) = next.strip_suffix(&format!(" = {};", var_name)) {
                            let lhs = assign_rest.trim();
                            // 타입 선언이 없는 재할당인 경우만
                            if !lhs.contains(' ') {
                                let indent = get_indent(lines[i + 1]);
                                out.push(format!("{}{} = {};", indent, lhs, expr));
                                skip.insert(i + 1);
                                continue;
                            }
                        }
                    }
                }
            }
        }

        out.push(lines[i].to_string());
    }

    out.join("\n") + if src.ends_with('\n') { "\n" } else { "" }
}

/// boolean 표현식 단순화
///   != 0  →  (boolean 컨텍스트에서) 그대로 유지
///   == true  → (생략)
///   == false → !(...) 형태로
fn simplify_boolean_expressions(src: &str) -> String {
    src
        // if (x == true) → if (x)
        .replace("if (true == true)", "if (true)")
        // Long.compare(a, b) → a - b (long 비교에서)
        // 이건 의미가 달라질 수 있으므로 주석만
        .to_string()
}

/// i = i + 1; → i++; / i = i - 1; → i--;
fn simplify_iinc(src: &str) -> String {
    let mut out = String::with_capacity(src.len());
    for line in src.lines() {
        let trimmed = line.trim();
        let indent = get_indent(line);

        // "<var> = <var> + 1;" 패턴
        if let Some(simplified) = try_simplify_iinc(trimmed) {
            out.push_str(&indent);
            out.push_str(&simplified);
            out.push('\n');
        } else {
            out.push_str(line);
            out.push('\n');
        }
    }
    // 마지막 개행 정리
    if !src.ends_with('\n') && out.ends_with('\n') {
        out.pop();
    }
    out
}

fn try_simplify_iinc(s: &str) -> Option<String> {
    // "x = x + 1;" → "x++;"
    let s = s.strip_suffix(';')?;
    if let Some(eq) = s.find(" = ") {
        let lhs = s[..eq].trim();
        let rhs = s[eq + 3..].trim();

        // x + 1
        if rhs == format!("{} + 1", lhs) { return Some(format!("{}++;", lhs)); }
        if rhs == format!("{} - 1", lhs) { return Some(format!("{}--;", lhs)); }
        if rhs == format!("1 + {}", lhs) { return Some(format!("{}++;", lhs)); }

        // x += N
        if let Some(rest) = rhs.strip_prefix(&format!("{} + ", lhs)) {
            if rest.parse::<i32>().is_ok() {
                return Some(format!("{} += {};", lhs, rest));
            }
        }
        if let Some(rest) = rhs.strip_prefix(&format!("{} - ", lhs)) {
            if rest.parse::<i32>().is_ok() {
                return Some(format!("{} -= {};", lhs, rest));
            }
        }
    }
    None
}

/// import 정렬 + 중복 제거
fn sort_imports(src: &str) -> String {
    let lines: Vec<&str> = src.lines().collect();
    let mut pre_import:  Vec<&str> = Vec::new();
    let mut imports:     Vec<&str> = Vec::new();
    let mut post_import: Vec<&str> = Vec::new();
    let mut in_imports   = false;
    let mut past_imports = false;

    for line in &lines {
        if line.starts_with("import ") {
            in_imports   = true;
            past_imports = false;
            imports.push(line);
        } else if in_imports && !past_imports {
            past_imports = true;
            post_import.push(line);
        } else if !in_imports {
            pre_import.push(line);
        } else {
            post_import.push(line);
        }
    }

    // import 정렬 + 중복 제거
    imports.sort_unstable();
    imports.dedup();

    // java.* / javax.* / 나머지를 그룹별로 분리
    let (java_imports, other_imports): (Vec<_>, Vec<_>) = imports
        .iter()
        .partition(|l| l.starts_with("import java.") || l.starts_with("import javax."));

    let mut result = pre_import.join("\n");
    if !pre_import.is_empty() { result.push('\n'); }

    for imp in &java_imports  { result.push_str(imp); result.push('\n'); }
    if !java_imports.is_empty() && !other_imports.is_empty() {
        result.push('\n'); // 그룹 사이 빈 줄
    }
    for imp in &other_imports { result.push_str(imp); result.push('\n'); }
    if !imports.is_empty()    { result.push('\n'); }

    result.push_str(&post_import.join("\n"));
    if src.ends_with('\n') && !result.ends_with('\n') {
        result.push('\n');
    }
    result
}

/// 공백 정규화 (trailing whitespace 제거)
fn normalize_spacing(src: &str) -> String {
    src.lines()
        .map(|l| l.trim_end())
        .collect::<Vec<_>>()
        .join("\n")
        + if src.ends_with('\n') { "\n" } else { "" }
}

fn get_indent(line: &str) -> String {
    let len = line.len() - line.trim_start().len();
    line[..len].to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_blank_lines() {
        let src = "class A {\n\n\n\n    void foo() {}\n}";
        let result = remove_redundant_blank_lines(src);
        assert!(!result.contains("\n\n\n"), "3연속 빈 줄 미제거: {:?}", result);
    }

    #[test]
    fn test_inline_temp_var_return() {
        let src = "    _t0 = x + 1;\n    return _t0;\n";
        let result = inline_temp_vars(src);
        assert!(result.contains("return x + 1;"), "인라인 실패: {}", result);
        assert!(!result.contains("_t0"), "_t0 잔재: {}", result);
    }

    #[test]
    fn test_iinc_plusplus() {
        let result = try_simplify_iinc("i = i + 1;");
        assert_eq!(result, Some("i++;".into()));
    }

    #[test]
    fn test_iinc_minusminus() {
        let result = try_simplify_iinc("count = count - 1;");
        assert_eq!(result, Some("count--;".into()));
    }

    #[test]
    fn test_iinc_pluseq() {
        let result = try_simplify_iinc("n = n + 5;");
        assert_eq!(result, Some("n += 5;".into()));
    }

    #[test]
    fn test_sort_imports() {
        let src = "package com.example;\n\nimport java.util.List;\nimport java.io.File;\nimport java.util.List;\n\nclass A {}\n";
        let result = sort_imports(src);
        let import_lines: Vec<&str> = result.lines()
            .filter(|l| l.starts_with("import "))
            .collect();
        // 중복 제거
        assert_eq!(import_lines.len(), 2, "중복 import 미제거: {:?}", import_lines);
        // 정렬
        assert!(result.find("import java.io").unwrap() < result.find("import java.util").unwrap(),
            "import 정렬 오류");
    }

    #[test]
    fn test_normalize_trailing_whitespace() {
        let src = "class A {   \n    int x;  \n}\n";
        let result = normalize_spacing(src);
        assert!(!result.contains("   \n"), "trailing whitespace 미제거");
        assert!(!result.contains("  \n"), "trailing whitespace 미제거");
    }

    #[test]
    fn test_prettify_full() {
        let src = "import java.util.Map;\nimport java.io.File;\nimport java.util.Map;\n\nclass A {\n\n\n    void foo() {\n        _t0 = x + 1;\n        return _t0;\n    }\n}\n";
        let result = prettify(src);
        assert!(!result.contains("_t0"), "temp var 잔재");
        assert!(!result.contains("\n\n\n"), "과도한 빈 줄");
    }
}
