//! C2J CLI 진입점 — JAR 지원 + 전체 파이프라인

use std::fs;
use std::path::{Path, PathBuf};
use clap::Parser;

use c2j::{ClassFileParser, ClassFileValidator, VERSION, decompile};
use c2j::utils::{Result, error::C2JError, DiagnosticCollector, error_to_diagnostic};
use c2j::generator::JavaGenerator;
use c2j::verifier::Verifier;
use c2j::plugins::{PluginManager, PluginPipeline};
use c2j::classfile::{java_version_name, read_jar};
use c2j::utils::parallel::{ParallelProcessor, ProcessStats};

#[derive(Parser, Debug)]
#[command(
    name = "c2j",
    version = VERSION,
    about = "C2J — Class To Java Decompiler (Java 8~22)",
    after_help = "\
Examples:
  c2j Example.class
  c2j Example.class -o Output.java
  c2j MyApp.jar -o src/
  c2j classes/ -o src/
  c2j Example.class --verify --verbose
  c2j Example.class --plugin-dir ./plugins
  c2j MyApp.jar --parallel 4"
)]
struct Args {
    /// 입력: .class / .jar 파일 또는 디렉토리
    #[arg(value_name = "INPUT")]
    input: PathBuf,

    /// 출력: .java 파일 또는 디렉토리
    #[arg(short, long, value_name = "OUTPUT")]
    output: Option<PathBuf>,

    /// javac로 생성된 .java 컴파일 검증
    #[arg(long)]
    verify: bool,

    /// 원본과 실행 결과 비교 검증
    #[arg(long = "verify-runtime")]
    verify_runtime: bool,

    /// 상세 출력
    #[arg(short, long)]
    verbose: bool,

    /// 디버그 모드 (생성 소스 미리보기)
    #[arg(long)]
    debug: bool,

    /// 플러그인 디렉토리 (.so/.dll)
    #[arg(long = "plugin-dir", value_name = "DIR")]
    plugin_dir: Option<PathBuf>,

    /// Java 타겟 버전 (11 / 17 / 21)
    #[arg(long = "java-version", default_value = "17")]
    java_version: u16,

    /// text block 출력 비활성화
    #[arg(long = "no-text-block")]
    no_text_block: bool,

    /// 병렬 스레드 수 (0 = CPU 코어 수 자동)
    #[arg(long, default_value = "0")]
    parallel: usize,

    /// 로드된 플러그인 목록 출력 후 종료
    #[arg(long = "list-plugins")]
    list_plugins: bool,

    /// 클래스 파일 정보만 출력 (변환 없음)
    #[arg(long)]
    info: bool,

    /// 실패해도 계속 진행 (부분 성공 허용)
    #[arg(long = "keep-going")]
    keep_going: bool,
}

fn main() {
    let args = Args::parse();
    if args.verbose || args.debug {
        c2j::utils::logger::init();
    }
    match run(&args) {
        Ok(()) => std::process::exit(0),
        Err(e) => {
            let diag = error_to_diagnostic(&e);
            eprintln!("{}", diag);
            std::process::exit(1);
        }
    }
}

fn run(args: &Args) -> Result<()> {
    // 플러그인 로드
    let pipeline = match &args.plugin_dir {
        Some(dir) => {
            let mut mgr = PluginManager::new();
            let n = mgr.load_from_dir(dir)?;
            if args.verbose { eprintln!("[INFO] 플러그인 {}개 로드", n); }
            PluginPipeline::new(mgr)
        }
        None => PluginPipeline::disabled(),
    };

    if args.list_plugins {
        let plugins = pipeline.list_plugins();
        if plugins.is_empty() { println!("로드된 플러그인 없음"); }
        else { for p in &plugins { println!("  • {}", p); } }
        return Ok(());
    }

    if !args.input.exists() {
        return Err(C2JError::InvalidArgument(
            format!("입력 없음: {:?}", args.input)
        ));
    }

    let ext = args.input.extension().and_then(|e| e.to_str()).unwrap_or("");

    match ext {
        "jar" => run_jar(args, &pipeline),
        "class" => run_single_file(args, &args.input.clone(), args.output.as_deref(), &pipeline),
        _ if args.input.is_dir() => run_directory(args, &pipeline),
        _ => Err(C2JError::InvalidArgument(
            format!("지원하지 않는 입력 형식: {:?}\n사용법: c2j <file.class|file.jar|dir/>", args.input)
        )),
    }
}

// ─── JAR 처리 ──────────────────────────────────────────────────────────────

fn run_jar(args: &Args, pipeline: &PluginPipeline) -> Result<()> {
    let jar_bytes = fs::read(&args.input)?;
    let jar = read_jar(&jar_bytes)?;

    let out_dir = args.output.clone()
        .unwrap_or_else(|| args.input.with_extension(""));

    if args.verbose {
        eprintln!("[INFO] JAR: {}개 클래스 발견", jar.classes.len());
        if let Some(main) = jar.main_class() {
            eprintln!("[INFO] Main-Class: {}", main.replace('/', "."));
        }
    }

    if jar.classes.is_empty() {
        eprintln!("[WARN] JAR에 .class 파일이 없습니다.");
        return Ok(());
    }

    // 병렬 처리
    let n_threads = if args.parallel == 0 {
        std::thread::available_parallelism().map(|n| n.get()).unwrap_or(4)
    } else {
        args.parallel
    };

    let items: Vec<(String, Vec<u8>)> = jar.classes.into_iter().collect();
    let total = items.len();
    let out_dir_clone = out_dir.clone();

    let proc = ParallelProcessor::new(n_threads);
    let results = proc.process(items, move |name, bytes| {
        let cf = ClassFileParser::parse(bytes)
            .map_err(|e| e.to_string())?;
        ClassFileValidator::validate(&cf)
            .map_err(|e| e.to_string())?;
        let src = JavaGenerator::generate(&cf)
            .map_err(|e| e.to_string())?;
        Ok::<(String, String), String>((name.to_string(), src))
    });

    let stats = ProcessStats::from_results(&results);
    let mut written = 0usize;

    for r in &results {
        if let Ok((internal_name, src)) = &r.result {
            // "com/example/Foo.class" → out_dir/com/example/Foo.java
            let rel = PathBuf::from(internal_name).with_extension("java");
            let out_path = out_dir.join(&rel);
            if let Some(parent) = out_path.parent() {
                fs::create_dir_all(parent)?;
            }
            fs::write(&out_path, src)?;
            if args.verbose {
                println!("  ✓ {:?}", rel);
            }
            written += 1;
        }
    }

    println!("\n✓ JAR 디컴파일 완료");
    println!("  클래스: {}개 / 성공: {}개 / 실패: {}개", total, written, stats.failed);
    println!("  출력: {:?}", out_dir);
    if args.verbose { stats.print_summary(); }

    if stats.failed > 0 && !args.keep_going {
        eprintln!("\n실패한 클래스:");
        for e in stats.errors.iter().take(10) {
            eprintln!("  • {}", e);
        }
    }

    Ok(())
}

// ─── 단일 .class 처리 ───────────────────────────────────────────────────────

fn run_single_file(
    args: &Args,
    input: &Path,
    output: Option<&Path>,
    pipeline: &PluginPipeline,
) -> Result<()> {
    let raw = fs::read(input)?;
    let class_name = input.file_stem()
        .and_then(|s| s.to_str()).unwrap_or("Unknown");
    let bytes = pipeline.pre_process_bytes(class_name, raw);

    let class_file = ClassFileParser::parse(&bytes)?;
    ClassFileValidator::validate(&class_file)?;

    if args.info {
        print_class_info(&class_file, input, args.verbose);
        return Ok(());
    }

    if args.verbose {
        print_class_info(&class_file, input, true);
    }

    let java_src = JavaGenerator::generate(&class_file)?;
    let java_src = pipeline.post_process_source(java_src);

    let out_path: PathBuf = if let Some(o) = output {
        o.to_path_buf()
    } else {
        input.with_extension("java")
    };

    if let Some(parent) = out_path.parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent)?;
        }
    }
    fs::write(&out_path, &java_src)?;
    println!("✓  {:?}  →  {:?}", input.file_name().unwrap_or_default(), out_path);

    // 컴파일 검증
    if args.verify {
        print!("   컴파일 검증... ");
        match Verifier::verify_compile(&out_path) {
            Ok(r) if r.compile_ok => println!("✓ OK"),
            Ok(r) => {
                println!("✗ 실패");
                if let Some(err) = &r.compile_error {
                    eprintln!("{}", err.lines().take(8).collect::<Vec<_>>().join("\n"));
                }
            }
            Err(e) => println!("⚠ {}", e),
        }
    }

    // 디버그: 소스 미리보기
    if args.debug {
        println!("\n--- 생성 소스 (50줄) ---");
        for (i, line) in java_src.lines().take(50).enumerate() {
            println!("{:3}: {}", i + 1, line);
        }
        let total = java_src.lines().count();
        if total > 50 { println!("... {}줄 더", total - 50); }
    }

    Ok(())
}

// ─── 디렉토리 일괄 처리 ─────────────────────────────────────────────────────

fn run_directory(args: &Args, pipeline: &PluginPipeline) -> Result<()> {
    let input_dir  = &args.input;
    let output_dir = args.output.clone().unwrap_or_else(|| input_dir.clone());

    let class_files: Vec<PathBuf> = walkdir(input_dir)
        .filter_map(|r| r.ok())
        .filter(|p| p.extension().and_then(|e| e.to_str()) == Some("class"))
        .collect();

    let total = class_files.len();
    if total == 0 {
        println!("처리할 .class 파일 없음: {:?}", input_dir);
        return Ok(());
    }

    let n_threads = if args.parallel == 0 { 1 } else { args.parallel };

    if n_threads > 1 {
        // 병렬 처리
        let items: Vec<(String, Vec<u8>)> = class_files.iter()
            .filter_map(|p| {
                let key = p.to_string_lossy().into_owned();
                fs::read(p).ok().map(|b| (key, b))
            })
            .collect();

        let proc = ParallelProcessor::new(n_threads);
        let results = proc.process(items, |_, bytes| {
            let cf = ClassFileParser::parse(bytes).map_err(|e| e.to_string())?;
            ClassFileValidator::validate(&cf).map_err(|e| e.to_string())?;
            JavaGenerator::generate(&cf).map_err(|e| e.to_string())
        });

        for (path, result) in class_files.iter().zip(results.iter()) {
            match &result.result {
                Ok(src) => {
                    let rel = path.strip_prefix(input_dir).unwrap_or(path);
                    let out = output_dir.join(rel).with_extension("java");
                    if let Some(p) = out.parent() { fs::create_dir_all(p)?; }
                    fs::write(&out, src)?;
                    if args.verbose { println!("  ✓ {:?}", rel); }
                }
                Err(e) => eprintln!("  ✗ {:?}: {}", path.file_name().unwrap_or_default(), e),
            }
        }

        let stats = ProcessStats::from_results(&results);
        println!("\n완료: {} 성공 / {} 전체 ({} 실패)", stats.succeeded, total, stats.failed);
        stats.print_summary();
    } else {
        // 단순 순차 처리
        let mut ok = 0usize;
        let mut errs: Vec<String> = Vec::new();
        for path in &class_files {
            let rel = path.strip_prefix(input_dir).unwrap_or(path);
            let out = output_dir.join(rel).with_extension("java");
            match run_single_file(args, path, Some(out.as_path()), pipeline) {
                Ok(()) => ok += 1,
                Err(e) => {
                    let msg = format!("{:?}: {}", path.file_name().unwrap_or_default(), e);
                    if args.verbose { eprintln!("  ✗ {}", msg); }
                    errs.push(msg);
                }
            }
        }
        println!("\n완료: {} 성공 / {} 전체 ({} 실패)", ok, total, errs.len());
        if !errs.is_empty() && !args.keep_going {
            for e in errs.iter().take(10) { eprintln!("  • {}", e); }
        }
    }

    Ok(())
}

// ─── 클래스 정보 출력 ───────────────────────────────────────────────────────

fn print_class_info(cf: &c2j::ClassFile, path: &Path, verbose: bool) {
    use c2j::constantpool::ConstantPoolEntry;

    let ver = java_version_name(cf.major_version);
    println!("═══════════════════════════════════════");
    println!("파일  : {:?}", path);
    println!("버전  : {} (major={}, minor={})", ver, cf.major_version, cf.minor_version);
    println!("CP    : {} 엔트리", cf.constant_pool.len());
    println!("필드  : {}개", cf.fields.len());
    println!("메서드: {}개", cf.methods.len());
    println!("Attr  : {}개", cf.attributes.len());

    let flags = cf.access_flags;
    print!("플래그: ");
    if flags.is_public()    { print!("public "); }
    if flags.is_final()     { print!("final "); }
    if flags.is_interface() { print!("interface "); }
    if flags.is_abstract()  { print!("abstract "); }
    if flags.is_enum()      { print!("enum "); }
    if flags.is_synthetic() { print!("synthetic "); }
    println!();

    if verbose {
        println!("\n메서드 목록:");
        for m in &cf.methods {
            let name = utf8_from_cp(&cf.constant_pool, m.name_index);
            let desc = utf8_from_cp(&cf.constant_pool, m.descriptor_index);
            let flags = m.access_flags;
            let vis = if flags.is_public() { "pub" }
                else if flags.is_protected() { "prot" }
                else if flags.is_private()   { "priv" }
                else { "pkg" };
            let stat = if flags.is_static() { " static" } else { "" };
            println!("  [{vis}{stat}] {name}{desc}");
        }

        // annotation 정보
        let anns = crate::c2j::ir::annotation_restore::extract_annotations(
            &cf.attributes, &cf.constant_pool
        );
        if !anns.is_empty() {
            println!("\nAnnotations:");
            for a in &anns {
                println!("  {}", c2j::ir::annotation_restore::annotation_to_java(a));
            }
        }
    }
    println!("═══════════════════════════════════════");
}

fn utf8_from_cp(cp: &[Option<c2j::constantpool::ConstantPoolEntry>], idx: u16) -> String {
    cp.get(idx as usize)
        .and_then(|e| e.as_ref())
        .and_then(|e| if let c2j::constantpool::ConstantPoolEntry::Utf8(s) = e { Some(s.clone()) } else { None })
        .unwrap_or_else(|| format!("#{}", idx))
}

// ─── 유틸리티 ───────────────────────────────────────────────────────────────

fn walkdir(dir: &Path) -> impl Iterator<Item = std::io::Result<PathBuf>> {
    let mut paths: Vec<std::io::Result<PathBuf>> = Vec::new();
    collect_files(dir, &mut paths);
    paths.into_iter()
}

fn collect_files(dir: &Path, out: &mut Vec<std::io::Result<PathBuf>>) {
    let rd = match fs::read_dir(dir) {
        Ok(r) => r,
        Err(e) => { out.push(Err(e)); return; }
    };
    let mut entries: Vec<_> = rd.filter_map(|e| e.ok()).collect();
    entries.sort_by_key(|e| e.path());
    for entry in entries {
        let p = entry.path();
        if p.is_dir() { collect_files(&p, out); }
        else { out.push(Ok(p)); }
    }
}
