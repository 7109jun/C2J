//! C2J 플러그인 시스템
pub mod ffi;
pub mod loader;
pub mod pipeline;
pub use loader::PluginManager;
pub use pipeline::PluginPipeline;
