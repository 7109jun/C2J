//! C FFI 타입 정의
//!
//! 플러그인이 구현해야 하는 C 인터페이스.
//! 플러그인은 이 함수들을 export 해야 합니다.

use std::ffi::CStr;

// ─── C-호환 타입 ─────────────────────────────────────────────────────────────

/// 플러그인에 전달되는 단일 명령어 컨텍스트
#[repr(C)]
pub struct C2JInstrContext {
    /// 현재 bytecode 위치 (PC)
    pub pc: u32,
    /// opcode byte
    pub opcode: u8,
    /// 피연산자 바이트 배열 포인터
    pub operands: *const u8,
    /// 피연산자 바이트 수
    pub operand_count: usize,
    /// 스택 깊이
    pub stack_depth: u32,
    /// 현재 메서드 이름 (NUL-terminated)
    pub method_name: *const std::os::raw::c_char,
    /// 현재 클래스 이름 (NUL-terminated)
    pub class_name: *const std::os::raw::c_char,
}

/// 플러그인 정보 구조체
#[repr(C)]
pub struct C2JPluginInfo {
    /// 플러그인 이름 (NUL-terminated)
    pub name: *const std::os::raw::c_char,
    /// 버전 문자열 (NUL-terminated)
    pub version: *const std::os::raw::c_char,
    /// 이 플러그인이 처리할 opcode 목록 (0x00으로 종료)
    pub handled_opcodes: *const u8,
    /// 이 플러그인이 필터할 클래스 패턴 (NULL-terminated array of C strings)
    pub class_patterns: *const *const std::os::raw::c_char,
}

/// 변환 결과 코드
#[repr(C)]
pub enum C2JTransformResult {
    /// 처리 완료, output에 Java 표현식 문자열이 들어 있음
    Ok = 0,
    /// 이 명령어는 처리하지 않음 (기본 변환 사용)
    Skip = 1,
    /// 오류
    Error = 2,
}

// ─── 함수 포인터 타입 ─────────────────────────────────────────────────────────

/// 플러그인 정보 반환 함수 타입
pub type PluginInfoFn = unsafe extern "C" fn() -> *const C2JPluginInfo;

/// 명령어 변환 함수 타입
///   ctx    : 명령어 컨텍스트
///   output : Java 표현식 문자열을 쓸 버퍼
///   out_cap: 버퍼 최대 크기
/// 반환값: 실제 쓴 바이트 수 (0이면 skip)
pub type TransformFn = unsafe extern "C" fn(
    ctx: *const C2JInstrContext,
    output: *mut u8,
    out_cap: usize,
) -> C2JTransformResult;

/// 클래스 필터 함수 타입
///   class_name: 내부 클래스 이름 ("java/lang/String")
///   data      : .class 파일 바이트
///   len       : 바이트 길이
/// 반환값: 수정된 바이트 배열 포인터 (NULL이면 변경 없음)
pub type ClassFilterFn = unsafe extern "C" fn(
    class_name: *const std::os::raw::c_char,
    data: *const u8,
    len: usize,
    out_len: *mut usize,
) -> *mut u8;

/// 변환 결과 메모리 해제 함수
pub type FreeFn = unsafe extern "C" fn(ptr: *mut u8);
