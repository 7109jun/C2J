//! 플러그인 로더
//!
//! 디렉토리의 .so/.dll 파일을 스캔하여 C2J 플러그인을 동적으로 로드합니다.

use std::path::{Path, PathBuf};
use std::collections::HashMap;
use std::ffi::CStr;
use crate::plugins::ffi::{PluginInfoFn, TransformFn, ClassFilterFn, FreeFn, C2JInstrContext, C2JTransformResult};
use crate::utils::{Result, C2JError};

/// 로드된 단일 플러그인
pub struct LoadedPlugin {
    pub name: String,
    pub version: String,
    pub handled_opcodes: Vec<u8>,
    pub class_patterns: Vec<String>,

    // libloading 대신 raw dlopen으로 처리
    #[cfg(unix)]
    handle: *mut libc::c_void,

    transform_fn: Option<TransformFn>,
    filter_fn: Option<ClassFilterFn>,
    free_fn: Option<FreeFn>,
}

impl LoadedPlugin {
    /// 명령어 변환 실행
    pub fn transform(&self, ctx: &C2JInstrContext) -> Option<String> {
        let transform = self.transform_fn?;

        let mut buf = vec![0u8; 4096];
        let result = unsafe {
            transform(ctx as *const _, buf.as_mut_ptr(), buf.len())
        };

        match result {
            C2JTransformResult::Ok => {
                let len = buf.iter().position(|&b| b == 0).unwrap_or(buf.len());
                String::from_utf8(buf[..len].to_vec()).ok()
            }
            _ => None,
        }
    }

    /// 클래스 파일 필터
    pub fn filter_class(&self, class_name: &str, data: &[u8]) -> Option<Vec<u8>> {
        let filter = self.filter_fn?;
        let c_name = std::ffi::CString::new(class_name).ok()?;
        let mut out_len: usize = 0;

        let ptr = unsafe {
            filter(c_name.as_ptr(), data.as_ptr(), data.len(), &mut out_len)
        };

        if ptr.is_null() { return None; }

        let result = unsafe {
            std::slice::from_raw_parts(ptr, out_len).to_vec()
        };

        // 메모리 해제
        if let Some(free) = self.free_fn {
            unsafe { free(ptr); }
        }

        Some(result)
    }
}

unsafe impl Send for LoadedPlugin {}
unsafe impl Sync for LoadedPlugin {}

impl Drop for LoadedPlugin {
    fn drop(&mut self) {
        #[cfg(unix)]
        if !self.handle.is_null() {
            unsafe { libc::dlclose(self.handle); }
        }
    }
}

/// 플러그인 관리자
pub struct PluginManager {
    plugins: Vec<LoadedPlugin>,
    /// opcode → 처리 플러그인 인덱스
    opcode_map: HashMap<u8, usize>,
}

impl PluginManager {
    pub fn new() -> Self {
        PluginManager {
            plugins: Vec::new(),
            opcode_map: HashMap::new(),
        }
    }

    /// 디렉토리에서 플러그인 로드
    pub fn load_from_dir(&mut self, dir: &Path) -> Result<usize> {
        if !dir.exists() { return Ok(0); }

        let mut count = 0;
        for entry in std::fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");

            let is_plugin = cfg!(unix) && (ext == "so")
                || cfg!(windows) && ext == "dll"
                || cfg!(target_os = "macos") && ext == "dylib";

            if is_plugin {
                match self.load_plugin(&path) {
                    Ok(()) => { count += 1; }
                    Err(e) => {
                        eprintln!("[WARN] Failed to load plugin {:?}: {}", path, e);
                    }
                }
            }
        }

        Ok(count)
    }

    /// 단일 플러그인 파일 로드
    pub fn load_plugin(&mut self, path: &Path) -> Result<()> {
        #[cfg(unix)]
        {
            use std::ffi::CString;
            let path_c = CString::new(path.to_str().unwrap_or(""))
                .map_err(|e| C2JError::PluginError(format!("{}", e)))?;

            let handle = unsafe {
                libc::dlopen(path_c.as_ptr(), libc::RTLD_LAZY | libc::RTLD_LOCAL)
            };

            if handle.is_null() {
                let err = unsafe {
                    let e = libc::dlerror();
                    if e.is_null() { "unknown".to_string() }
                    else { CStr::from_ptr(e).to_string_lossy().to_string() }
                };
                return Err(C2JError::PluginError(format!("dlopen failed: {}", err)));
            }

            // c2j_plugin_info 심볼 찾기
            let info_fn = unsafe {
                let sym = libc::dlsym(handle, b"c2j_plugin_info\0".as_ptr() as *const _);
                if sym.is_null() {
                    libc::dlclose(handle);
                    return Err(C2JError::PluginError("missing c2j_plugin_info".into()));
                }
                std::mem::transmute::<*mut libc::c_void, PluginInfoFn>(sym)
            };

            let info = unsafe { info_fn() };
            if info.is_null() {
                unsafe { libc::dlclose(handle); }
                return Err(C2JError::PluginError("c2j_plugin_info returned NULL".into()));
            }

            let name = unsafe { CStr::from_ptr((*info).name).to_string_lossy().to_string() };
            let version = unsafe { CStr::from_ptr((*info).version).to_string_lossy().to_string() };

            // handled_opcodes 수집
            let mut handled_opcodes = Vec::new();
            let mut op_ptr = unsafe { (*info).handled_opcodes };
            while !op_ptr.is_null() {
                let op = unsafe { *op_ptr };
                if op == 0 { break; }
                handled_opcodes.push(op);
                op_ptr = unsafe { op_ptr.add(1) };
            }

            // c2j_transform 심볼 (선택)
            let transform_fn: Option<TransformFn> = unsafe {
                let sym = libc::dlsym(handle, b"c2j_transform\0".as_ptr() as *const _);
                if sym.is_null() { None }
                else { Some(std::mem::transmute(sym)) }
            };

            // c2j_class_filter 심볼 (선택)
            let filter_fn: Option<ClassFilterFn> = unsafe {
                let sym = libc::dlsym(handle, b"c2j_class_filter\0".as_ptr() as *const _);
                if sym.is_null() { None }
                else { Some(std::mem::transmute(sym)) }
            };

            let free_fn: Option<FreeFn> = unsafe {
                let sym = libc::dlsym(handle, b"c2j_free\0".as_ptr() as *const _);
                if sym.is_null() { None }
                else { Some(std::mem::transmute(sym)) }
            };

            let plugin_idx = self.plugins.len();
            for &op in &handled_opcodes {
                self.opcode_map.insert(op, plugin_idx);
            }

            self.plugins.push(LoadedPlugin {
                name,
                version,
                handled_opcodes,
                class_patterns: Vec::new(),
                handle,
                transform_fn,
                filter_fn,
                free_fn,
            });

            Ok(())
        }

        #[cfg(not(unix))]
        Err(C2JError::PluginError("Plugin loading only supported on Unix".into()))
    }

    /// opcode에 대한 플러그인 변환 실행
    pub fn transform_opcode(&self, ctx: &C2JInstrContext) -> Option<String> {
        let plugin_idx = self.opcode_map.get(&ctx.opcode)?;
        self.plugins.get(*plugin_idx)?.transform(ctx)
    }

    /// 클래스 파일 필터 적용 (모든 플러그인 순차 적용)
    pub fn filter_class(&self, class_name: &str, data: Vec<u8>) -> Vec<u8> {
        let mut current = data;
        for plugin in &self.plugins {
            if plugin.class_patterns.iter().any(|p| class_name.contains(p.as_str())) {
                if let Some(filtered) = plugin.filter_class(class_name, &current) {
                    current = filtered;
                }
            }
        }
        current
    }

    pub fn plugin_count(&self) -> usize { self.plugins.len() }

    pub fn list_plugins(&self) -> Vec<(&str, &str)> {
        self.plugins.iter().map(|p| (p.name.as_str(), p.version.as_str())).collect()
    }
}

impl Default for PluginManager {
    fn default() -> Self { Self::new() }
}
