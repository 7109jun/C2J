//! 플러그인 → 변환 파이프라인 연동
//!
//! JavaGenerator 앞/뒤에 플러그인 훅을 삽입합니다.
//! - pre_class  : 클래스 파일 바이트 변환 (class_filter)
//! - post_source: 생성된 Java 소스 후처리

use crate::plugins::loader::PluginManager;
use crate::classfile::ClassFile;
use crate::utils::Result;

/// 플러그인 파이프라인
pub struct PluginPipeline {
    manager: PluginManager,
    enabled: bool,
}

impl PluginPipeline {
    pub fn new(manager: PluginManager) -> Self {
        PluginPipeline { manager, enabled: true }
    }

    pub fn disabled() -> Self {
        PluginPipeline { manager: PluginManager::new(), enabled: false }
    }

    /// 클래스 파일 바이트를 플러그인으로 전처리
    pub fn pre_process_bytes(&self, class_name: &str, bytes: Vec<u8>) -> Vec<u8> {
        if !self.enabled || self.manager.plugin_count() == 0 {
            return bytes;
        }
        self.manager.filter_class(class_name, bytes)
    }

    /// 생성된 Java 소스를 플러그인으로 후처리
    pub fn post_process_source(&self, src: String) -> String {
        // 현재는 pass-through — 향후 Java 소스 레벨 변환 훅 추가
        src
    }

    pub fn plugin_count(&self) -> usize { self.manager.plugin_count() }

    pub fn list_plugins(&self) -> Vec<String> {
        self.manager.list_plugins()
            .iter()
            .map(|(name, ver)| format!("{} v{}", name, ver))
            .collect()
    }
}

impl Default for PluginPipeline {
    fn default() -> Self { Self::disabled() }
}
