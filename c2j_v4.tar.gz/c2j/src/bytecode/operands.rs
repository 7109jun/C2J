#[derive(Debug, Clone)]
pub enum Operand {
    Byte(i8),
    Short(i16),
    Int(i32),
    Index(u16),
}
