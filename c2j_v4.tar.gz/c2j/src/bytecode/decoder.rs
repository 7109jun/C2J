//! Bytecode Decoder
//!
//! JVM .class 파일의 Code 속성에서 bytecode를 디코딩합니다.
//! 각 명령어의 피연산자를 포함하여 완전한 Instruction 스트림을 생성합니다.

use byteorder::{BigEndian, ByteOrder};
use crate::utils::{Result, C2JError};
use crate::bytecode::instruction::Opcode;

/// 완전한 JVM Instruction (피연산자 포함)
#[derive(Debug, Clone, PartialEq)]
pub struct Instruction {
    pub pc: u32,
    pub opcode: Opcode,
    pub operands: InstructionOperand,
    pub byte_size: u32,   // 이 명령어의 총 바이트 크기
}

/// 명령어별 피연산자
#[derive(Debug, Clone, PartialEq)]
pub enum InstructionOperand {
    None,
    LocalVarIndex(u16),                      // iload, istore 등
    LocalVarIndexAndConst(u16, i16),         // iinc
    ConstantPoolIndex(u16),                  // ldc, getfield, invokevirtual 등
    BranchOffset(i32),                       // goto, if*, jsr
    IntValue(i32),                           // bipush, sipush
    TypeIndex(u16),                          // new, anewarray, checkcast, instanceof
    InvokeInterface(u16, u8),               // invokeinterface (index, count)
    InvokeDynamic(u16),                     // invokedynamic
    NewArray(ArrayType),                    // newarray
    MultiNewArray(u16, u8),                 // multianewarray (type_index, dimensions)
    TableSwitch {
        default_offset: i32,
        low: i32,
        high: i32,
        offsets: Vec<i32>,
    },
    LookupSwitch {
        default_offset: i32,
        pairs: Vec<(i32, i32)>,             // (match, offset)
    },
    WideLocalVarIndex(u16),                  // wide iload 등
    WideIinc(u16, i16),                     // wide iinc
    Ret(u16),                               // ret (subroutine)
}

/// newarray의 배열 타입
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ArrayType {
    Boolean = 4,
    Char = 5,
    Float = 6,
    Double = 7,
    Byte = 8,
    Short = 9,
    Int = 10,
    Long = 11,
}

impl ArrayType {
    pub fn from_byte(b: u8) -> Option<Self> {
        match b {
            4 => Some(ArrayType::Boolean),
            5 => Some(ArrayType::Char),
            6 => Some(ArrayType::Float),
            7 => Some(ArrayType::Double),
            8 => Some(ArrayType::Byte),
            9 => Some(ArrayType::Short),
            10 => Some(ArrayType::Int),
            11 => Some(ArrayType::Long),
            _ => None,
        }
    }

    pub fn to_java_type(&self) -> &'static str {
        match self {
            ArrayType::Boolean => "boolean",
            ArrayType::Char => "char",
            ArrayType::Float => "float",
            ArrayType::Double => "double",
            ArrayType::Byte => "byte",
            ArrayType::Short => "short",
            ArrayType::Int => "int",
            ArrayType::Long => "long",
        }
    }
}

pub struct BytecodeDecoder;

impl BytecodeDecoder {
    /// 바이트 배열에서 Instruction 스트림 생성
    pub fn decode(bytecode: &[u8]) -> Result<Vec<Instruction>> {
        let mut instructions = Vec::new();
        let mut pc: usize = 0;

        while pc < bytecode.len() {
            let opcode_byte = bytecode[pc];
            let opcode = Opcode::from_byte(opcode_byte)
                .ok_or_else(|| C2JError::UnsupportedInstruction(opcode_byte))?;

            let (operands, byte_size) = if opcode == Opcode::Wide {
                // Wide prefix: 다음 opcode를 wide 버전으로 디코딩
                Self::decode_wide(bytecode, pc)?
            } else {
                Self::decode_operands(bytecode, pc, &opcode)?
            };

            instructions.push(Instruction {
                pc: pc as u32,
                opcode,
                operands,
                byte_size: byte_size as u32,
            });

            pc += byte_size;
        }

        Ok(instructions)
    }

    /// Wide prefix 처리
    fn decode_wide(bytecode: &[u8], pc: usize) -> Result<(InstructionOperand, usize)> {
        if pc + 1 >= bytecode.len() {
            return Err(C2JError::InvalidBytecode(pc as u16, "wide prefix at end of bytecode".into()));
        }

        let next_opcode_byte = bytecode[pc + 1];
        let next_opcode = Opcode::from_byte(next_opcode_byte)
            .ok_or_else(|| C2JError::UnsupportedInstruction(next_opcode_byte))?;

        match next_opcode {
            Opcode::Iload | Opcode::Lload | Opcode::Fload | Opcode::Dload | Opcode::Aload
            | Opcode::Istore | Opcode::Lstore | Opcode::Fstore | Opcode::Dstore | Opcode::Astore
            | Opcode::Ret => {
                if pc + 3 >= bytecode.len() {
                    return Err(C2JError::InvalidBytecode(pc as u16, "wide load/store truncated".into()));
                }
                let idx = BigEndian::read_u16(&bytecode[pc + 2..pc + 4]);
                Ok((InstructionOperand::WideLocalVarIndex(idx), 4))
            }
            Opcode::Iinc => {
                if pc + 5 >= bytecode.len() {
                    return Err(C2JError::InvalidBytecode(pc as u16, "wide iinc truncated".into()));
                }
                let idx = BigEndian::read_u16(&bytecode[pc + 2..pc + 4]);
                let val = BigEndian::read_i16(&bytecode[pc + 4..pc + 6]);
                Ok((InstructionOperand::WideIinc(idx, val), 6))
            }
            _ => Err(C2JError::InvalidBytecode(pc as u16,
                format!("invalid wide prefix for opcode 0x{:02X}", next_opcode_byte))),
        }
    }

    /// 일반 명령어 피연산자 디코딩
    fn decode_operands(bytecode: &[u8], pc: usize, opcode: &Opcode) -> Result<(InstructionOperand, usize)> {
        let len = bytecode.len();

        macro_rules! need {
            ($n:expr) => {
                if pc + $n > len {
                    return Err(C2JError::InvalidBytecode(
                        pc as u16,
                        format!("truncated at pc={}, need {} bytes, have {}", pc, $n, len - pc),
                    ));
                }
            };
        }

        match opcode {
            // ─── 피연산자 없는 명령어 ─────────────────────────────────────
            Opcode::Nop
            | Opcode::AconstNull
            | Opcode::IconstM1 | Opcode::Iconst0 | Opcode::Iconst1
            | Opcode::Iconst2  | Opcode::Iconst3 | Opcode::Iconst4 | Opcode::Iconst5
            | Opcode::Lconst0  | Opcode::Lconst1
            | Opcode::Fconst0  | Opcode::Fconst1 | Opcode::Fconst2
            | Opcode::Dconst0  | Opcode::Dconst1
            | Opcode::Iload0   | Opcode::Iload1  | Opcode::Iload2  | Opcode::Iload3
            | Opcode::Lload0   | Opcode::Lload1  | Opcode::Lload2  | Opcode::Lload3
            | Opcode::Fload0   | Opcode::Fload1  | Opcode::Fload2  | Opcode::Fload3
            | Opcode::Dload0   | Opcode::Dload1  | Opcode::Dload2  | Opcode::Dload3
            | Opcode::Aload0   | Opcode::Aload1  | Opcode::Aload2  | Opcode::Aload3
            | Opcode::Iaload   | Opcode::Laload  | Opcode::Faload  | Opcode::Daload
            | Opcode::Aaload   | Opcode::Baload  | Opcode::Caload  | Opcode::Saload
            | Opcode::Istore0  | Opcode::Istore1 | Opcode::Istore2 | Opcode::Istore3
            | Opcode::Lstore0  | Opcode::Lstore1 | Opcode::Lstore2 | Opcode::Lstore3
            | Opcode::Fstore0  | Opcode::Fstore1 | Opcode::Fstore2 | Opcode::Fstore3
            | Opcode::Dstore0  | Opcode::Dstore1 | Opcode::Dstore2 | Opcode::Dstore3
            | Opcode::Astore0  | Opcode::Astore1 | Opcode::Astore2 | Opcode::Astore3
            | Opcode::Iastore  | Opcode::Lastore | Opcode::Fastore | Opcode::Dastore
            | Opcode::Aastore  | Opcode::Bastore | Opcode::Castore | Opcode::Sastore
            | Opcode::Pop | Opcode::Pop2
            | Opcode::Dup  | Opcode::DupX1 | Opcode::DupX2
            | Opcode::Dup2 | Opcode::Dup2X1 | Opcode::Dup2X2 | Opcode::Swap
            | Opcode::Iadd  | Opcode::Ladd  | Opcode::Fadd  | Opcode::Dadd
            | Opcode::Isub  | Opcode::Lsub  | Opcode::Fsub  | Opcode::Dsub
            | Opcode::Imul  | Opcode::Lmul  | Opcode::Fmul  | Opcode::Dmul
            | Opcode::Idiv  | Opcode::Ldiv  | Opcode::Fdiv  | Opcode::Ddiv
            | Opcode::Irem  | Opcode::Lrem  | Opcode::Frem  | Opcode::Drem
            | Opcode::Ineg  | Opcode::Lneg  | Opcode::Fneg  | Opcode::Dneg
            | Opcode::Ishl  | Opcode::Lshl  | Opcode::Ishr  | Opcode::Lshr
            | Opcode::Iushr | Opcode::Lushr | Opcode::Iand  | Opcode::Land
            | Opcode::Ior   | Opcode::Lor   | Opcode::Ixor  | Opcode::Lxor
            | Opcode::I2l   | Opcode::I2f   | Opcode::I2d
            | Opcode::L2i   | Opcode::L2f   | Opcode::L2d
            | Opcode::F2i   | Opcode::F2l   | Opcode::F2d
            | Opcode::D2i   | Opcode::D2l   | Opcode::D2f
            | Opcode::I2b   | Opcode::I2c   | Opcode::I2s
            | Opcode::Lcmp  | Opcode::Fcmpl | Opcode::Fcmpg | Opcode::Dcmpl | Opcode::Dcmpg
            | Opcode::Ireturn | Opcode::Lreturn | Opcode::Freturn
            | Opcode::Dreturn | Opcode::Areturn  | Opcode::Return
            | Opcode::Arraylength | Opcode::Athrow
            | Opcode::Monitorenter | Opcode::Monitorexit
            | Opcode::Breakpoint => Ok((InstructionOperand::None, 1)),

            // ─── 단일 바이트 로컬 인덱스 ──────────────────────────────────
            Opcode::Iload | Opcode::Lload | Opcode::Fload
            | Opcode::Dload | Opcode::Aload
            | Opcode::Istore | Opcode::Lstore | Opcode::Fstore
            | Opcode::Dstore | Opcode::Astore => {
                need!(2);
                let idx = bytecode[pc + 1] as u16;
                Ok((InstructionOperand::LocalVarIndex(idx), 2))
            }

            // ret (subroutine return) - Java <=5 에 사용
            Opcode::Ret => {
                need!(2);
                let idx = bytecode[pc + 1] as u16;
                Ok((InstructionOperand::Ret(idx), 2))
            }

            // ─── bipush: 1 바이트 정수 ────────────────────────────────────
            Opcode::Bipush => {
                need!(2);
                let val = bytecode[pc + 1] as i8 as i32;
                Ok((InstructionOperand::IntValue(val), 2))
            }

            // ─── sipush: 2 바이트 정수 ────────────────────────────────────
            Opcode::Sipush => {
                need!(3);
                let val = BigEndian::read_i16(&bytecode[pc + 1..pc + 3]) as i32;
                Ok((InstructionOperand::IntValue(val), 3))
            }

            // ─── ldc: 1 바이트 CP 인덱스 ──────────────────────────────────
            Opcode::Ldc => {
                need!(2);
                let idx = bytecode[pc + 1] as u16;
                Ok((InstructionOperand::ConstantPoolIndex(idx), 2))
            }

            // ─── ldc_w / ldc2_w: 2 바이트 CP 인덱스 ──────────────────────
            Opcode::LdcW | Opcode::Ldc2W => {
                need!(3);
                let idx = BigEndian::read_u16(&bytecode[pc + 1..pc + 3]);
                Ok((InstructionOperand::ConstantPoolIndex(idx), 3))
            }

            // ─── iinc: 로컬 인덱스 + 상수 ────────────────────────────────
            Opcode::Iinc => {
                need!(3);
                let idx = bytecode[pc + 1] as u16;
                let val = bytecode[pc + 2] as i8 as i16;
                Ok((InstructionOperand::LocalVarIndexAndConst(idx, val), 3))
            }

            // ─── 2 바이트 분기 오프셋 ─────────────────────────────────────
            Opcode::Ifeq | Opcode::Ifne | Opcode::Iflt | Opcode::Ifge
            | Opcode::Ifgt | Opcode::Ifle
            | Opcode::IfIcmpeq | Opcode::IfIcmpne | Opcode::IfIcmplt
            | Opcode::IfIcmpge | Opcode::IfIcmpgt | Opcode::IfIcmple
            | Opcode::IfAcmpeq | Opcode::IfAcmpne
            | Opcode::Ifnull | Opcode::Ifnonnull
            | Opcode::Goto | Opcode::Jsr => {
                need!(3);
                let offset = BigEndian::read_i16(&bytecode[pc + 1..pc + 3]) as i32;
                Ok((InstructionOperand::BranchOffset(offset), 3))
            }

            // ─── 4 바이트 분기 오프셋 ─────────────────────────────────────
            Opcode::GotoW | Opcode::JsrW => {
                need!(5);
                let offset = BigEndian::read_i32(&bytecode[pc + 1..pc + 5]);
                Ok((InstructionOperand::BranchOffset(offset), 5))
            }

            // ─── 2 바이트 CP 인덱스 (field/method) ────────────────────────
            Opcode::Getstatic | Opcode::Putstatic
            | Opcode::Getfield | Opcode::Putfield
            | Opcode::Invokevirtual | Opcode::Invokespecial | Opcode::Invokestatic
            | Opcode::New | Opcode::Anewarray
            | Opcode::Checkcast | Opcode::Instanceof => {
                need!(3);
                let idx = BigEndian::read_u16(&bytecode[pc + 1..pc + 3]);
                Ok((InstructionOperand::ConstantPoolIndex(idx), 3))
            }

            // ─── invokeinterface: index(2) + count(1) + 0(1) ──────────────
            Opcode::Invokeinterface => {
                need!(5);
                let idx = BigEndian::read_u16(&bytecode[pc + 1..pc + 3]);
                let count = bytecode[pc + 3];
                // bytecode[pc + 4] == 0 (reserved)
                Ok((InstructionOperand::InvokeInterface(idx, count), 5))
            }

            // ─── invokedynamic: index(2) + 0(1) + 0(1) ───────────────────
            Opcode::Invokedynamic => {
                need!(5);
                let idx = BigEndian::read_u16(&bytecode[pc + 1..pc + 3]);
                // bytecode[pc + 3] == 0, bytecode[pc + 4] == 0
                Ok((InstructionOperand::InvokeDynamic(idx), 5))
            }

            // ─── newarray: atype(1) ───────────────────────────────────────
            Opcode::Newarray => {
                need!(2);
                let atype = bytecode[pc + 1];
                let arr_type = ArrayType::from_byte(atype).ok_or_else(|| {
                    C2JError::InvalidBytecode(pc as u16, format!("invalid array type: {}", atype))
                })?;
                Ok((InstructionOperand::NewArray(arr_type), 2))
            }

            // ─── multianewarray: index(2) + dimensions(1) ────────────────
            Opcode::Multianewarray => {
                need!(4);
                let idx = BigEndian::read_u16(&bytecode[pc + 1..pc + 3]);
                let dims = bytecode[pc + 3];
                Ok((InstructionOperand::MultiNewArray(idx, dims), 4))
            }

            // ─── tableswitch ──────────────────────────────────────────────
            Opcode::Tableswitch => {
                // 1 바이트 opcode 후 0~3 바이트 패딩 (4바이트 정렬)
                let pad = (4 - ((pc + 1) % 4)) % 4;
                let base = pc + 1 + pad;

                need!(base + 12);
                let default_offset = BigEndian::read_i32(&bytecode[base..base + 4]);
                let low  = BigEndian::read_i32(&bytecode[base + 4..base + 8]);
                let high = BigEndian::read_i32(&bytecode[base + 8..base + 12]);

                let count = (high - low + 1) as usize;
                need!(base + 12 + count * 4);

                let mut offsets = Vec::with_capacity(count);
                for i in 0..count {
                    let off = BigEndian::read_i32(&bytecode[base + 12 + i * 4..base + 16 + i * 4]);
                    offsets.push(off);
                }

                let total = (base + 12 + count * 4) - pc;
                Ok((InstructionOperand::TableSwitch { default_offset, low, high, offsets }, total))
            }

            // ─── lookupswitch ─────────────────────────────────────────────
            Opcode::Lookupswitch => {
                let pad = (4 - ((pc + 1) % 4)) % 4;
                let base = pc + 1 + pad;

                need!(base + 8);
                let default_offset = BigEndian::read_i32(&bytecode[base..base + 4]);
                let npairs = BigEndian::read_i32(&bytecode[base + 4..base + 8]) as usize;

                need!(base + 8 + npairs * 8);
                let mut pairs = Vec::with_capacity(npairs);
                for i in 0..npairs {
                    let match_val = BigEndian::read_i32(&bytecode[base + 8 + i * 8..base + 12 + i * 8]);
                    let offset    = BigEndian::read_i32(&bytecode[base + 12 + i * 8..base + 16 + i * 8]);
                    pairs.push((match_val, offset));
                }

                let total = (base + 8 + npairs * 8) - pc;
                Ok((InstructionOperand::LookupSwitch { default_offset, pairs }, total))
            }

            // ─── wide prefix (재귀 방지용 — 실제 처리는 decode() 에서) ────
            Opcode::Wide => Ok((InstructionOperand::None, 1)),

            // ─── LdcDynamic (내부 enum 값, 실제 bytecode 아님) ────────────
            Opcode::LdcDynamic | Opcode::Breakpoint => {
                Ok((InstructionOperand::None, 1))
            }
        }
    }

    /// 주어진 pc에서의 분기 대상 PC 목록 반환 (CFG 빌드용)
    pub fn branch_targets(instr: &Instruction) -> Vec<u32> {
        let pc = instr.pc;
        match &instr.operands {
            InstructionOperand::BranchOffset(off) => {
                vec![(pc as i64 + *off as i64) as u32]
            }
            InstructionOperand::TableSwitch { default_offset, offsets, .. } => {
                let mut targets = vec![(pc as i64 + *default_offset as i64) as u32];
                for off in offsets {
                    targets.push((pc as i64 + *off as i64) as u32);
                }
                targets
            }
            InstructionOperand::LookupSwitch { default_offset, pairs } => {
                let mut targets = vec![(pc as i64 + *default_offset as i64) as u32];
                for (_, off) in pairs {
                    targets.push((pc as i64 + *off as i64) as u32);
                }
                targets
            }
            _ => vec![],
        }
    }

    /// 이 명령어가 무조건 분기(fall-through 없음)인지 여부
    pub fn is_unconditional_branch(opcode: &Opcode) -> bool {
        matches!(
            opcode,
            Opcode::Goto | Opcode::GotoW
                | Opcode::Ireturn | Opcode::Lreturn | Opcode::Freturn
                | Opcode::Dreturn | Opcode::Areturn | Opcode::Return
                | Opcode::Athrow
                | Opcode::Tableswitch | Opcode::Lookupswitch
                | Opcode::Ret
        )
    }

    /// 조건 분기인지 여부
    pub fn is_conditional_branch(opcode: &Opcode) -> bool {
        matches!(
            opcode,
            Opcode::Ifeq | Opcode::Ifne | Opcode::Iflt | Opcode::Ifge
                | Opcode::Ifgt | Opcode::Ifle
                | Opcode::IfIcmpeq | Opcode::IfIcmpne | Opcode::IfIcmplt
                | Opcode::IfIcmpge | Opcode::IfIcmpgt | Opcode::IfIcmple
                | Opcode::IfAcmpeq | Opcode::IfAcmpne
                | Opcode::Ifnull | Opcode::Ifnonnull
                | Opcode::Jsr | Opcode::JsrW
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_decode_simple_add() {
        // iload_0, iload_1, iadd, ireturn
        let code = vec![0x1A, 0x1B, 0x60, 0xAC];
        let instrs = BytecodeDecoder::decode(&code).unwrap();

        assert_eq!(instrs.len(), 4);
        assert_eq!(instrs[0].opcode, Opcode::Iload0);
        assert_eq!(instrs[1].opcode, Opcode::Iload1);
        assert_eq!(instrs[2].opcode, Opcode::Iadd);
        assert_eq!(instrs[3].opcode, Opcode::Ireturn);
    }

    #[test]
    fn test_decode_bipush() {
        // bipush 42
        let code = vec![0x10, 0x2A];
        let instrs = BytecodeDecoder::decode(&code).unwrap();
        assert_eq!(instrs.len(), 1);
        assert_eq!(instrs[0].opcode, Opcode::Bipush);
        assert_eq!(instrs[0].operands, InstructionOperand::IntValue(42));
        assert_eq!(instrs[0].byte_size, 2);
    }

    #[test]
    fn test_decode_goto() {
        // goto +5
        let code = vec![0xA7, 0x00, 0x05];
        let instrs = BytecodeDecoder::decode(&code).unwrap();
        assert_eq!(instrs[0].opcode, Opcode::Goto);
        assert_eq!(instrs[0].operands, InstructionOperand::BranchOffset(5));
    }

    #[test]
    fn test_decode_tableswitch() {
        // tableswitch: pad 3 bytes, default=+20, low=1, high=3, offsets=[+10,+12,+14]
        let mut code = vec![0xAAu8];  // tableswitch opcode
        code.extend_from_slice(&[0, 0, 0]);     // pad (pc=0, pad=3 => 4 byte align)
        code.extend_from_slice(&[0, 0, 0, 20]); // default
        code.extend_from_slice(&[0, 0, 0, 1]);  // low
        code.extend_from_slice(&[0, 0, 0, 3]);  // high
        code.extend_from_slice(&[0, 0, 0, 10]); // offset[0]
        code.extend_from_slice(&[0, 0, 0, 12]); // offset[1]
        code.extend_from_slice(&[0, 0, 0, 14]); // offset[2]

        let instrs = BytecodeDecoder::decode(&code).unwrap();
        assert_eq!(instrs.len(), 1);
        if let InstructionOperand::TableSwitch { default_offset, low, high, offsets } = &instrs[0].operands {
            assert_eq!(*default_offset, 20);
            assert_eq!(*low, 1);
            assert_eq!(*high, 3);
            assert_eq!(offsets.len(), 3);
        } else {
            panic!("expected TableSwitch operand");
        }
    }
}
