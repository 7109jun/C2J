//! Constant Pool 엔트리 정의 및 파싱
//! 
//! JVM의 constant pool은 문자열, 타입, 메서드 참조 등을 저장합니다.
//! 각 엔트리는 1부터 시작하는 인덱스를 가집니다.

use crate::utils::Result;

/// Constant Pool 엔트리
#[derive(Debug, Clone, PartialEq)]
pub enum ConstantPoolEntry {
    // 1.0
    Utf8(String),                                    // tag=1
    Integer(i32),                                    // tag=3
    Float(f32),                                      // tag=4
    Long(i64),                                       // tag=5 (2개 슬롯 차지)
    Double(f64),                                     // tag=6 (2개 슬롯 차지)
    Class(u16),                                      // tag=7 (name_index)
    String(u16),                                     // tag=8 (string_index)
    Fieldref(u16, u16),                              // tag=9 (class_index, name_and_type_index)
    Methodref(u16, u16),                             // tag=10
    InterfaceMethodref(u16, u16),                    // tag=11
    NameAndType(u16, u16),                           // tag=12 (name_index, descriptor_index)

    // 1.7+
    MethodHandle(u8, u16),                           // tag=15 (reference_kind, reference_index)
    MethodType(u16),                                 // tag=16 (descriptor_index)
    Dynamic(u16, u16),                               // tag=17 (bootstrap_method_attr_index, name_and_type_index)
    InvokeDynamic(u16, u16),                         // tag=18 (bootstrap_method_attr_index, name_and_type_index)

    // 1.11+
    Module(u16),                                     // tag=19 (name_index)
    Package(u16),                                    // tag=20 (name_index)
}

impl ConstantPoolEntry {
    pub fn tag(&self) -> u8 {
        match self {
            ConstantPoolEntry::Utf8(_) => 1,
            ConstantPoolEntry::Integer(_) => 3,
            ConstantPoolEntry::Float(_) => 4,
            ConstantPoolEntry::Long(_) => 5,
            ConstantPoolEntry::Double(_) => 6,
            ConstantPoolEntry::Class(_) => 7,
            ConstantPoolEntry::String(_) => 8,
            ConstantPoolEntry::Fieldref(_, _) => 9,
            ConstantPoolEntry::Methodref(_, _) => 10,
            ConstantPoolEntry::InterfaceMethodref(_, _) => 11,
            ConstantPoolEntry::NameAndType(_, _) => 12,
            ConstantPoolEntry::MethodHandle(_, _) => 15,
            ConstantPoolEntry::MethodType(_) => 16,
            ConstantPoolEntry::Dynamic(_, _) => 17,
            ConstantPoolEntry::InvokeDynamic(_, _) => 18,
            ConstantPoolEntry::Module(_) => 19,
            ConstantPoolEntry::Package(_) => 20,
        }
    }

    /// 이 엔트리가 2개 슬롯을 차지하는지 확인 (Long, Double)
    pub fn takes_two_slots(&self) -> bool {
        matches!(self, ConstantPoolEntry::Long(_) | ConstantPoolEntry::Double(_))
    }

    /// 엔트리의 크기를 바이트 단위로 반환
    pub fn byte_size(&self) -> usize {
        match self {
            ConstantPoolEntry::Utf8(s) => 1 + 2 + s.len(),
            ConstantPoolEntry::Integer(_) => 5,
            ConstantPoolEntry::Float(_) => 5,
            ConstantPoolEntry::Long(_) => 9,
            ConstantPoolEntry::Double(_) => 9,
            ConstantPoolEntry::Class(_) => 3,
            ConstantPoolEntry::String(_) => 3,
            ConstantPoolEntry::Fieldref(_, _) => 5,
            ConstantPoolEntry::Methodref(_, _) => 5,
            ConstantPoolEntry::InterfaceMethodref(_, _) => 5,
            ConstantPoolEntry::NameAndType(_, _) => 5,
            ConstantPoolEntry::MethodHandle(_, _) => 4,
            ConstantPoolEntry::MethodType(_) => 3,
            ConstantPoolEntry::Dynamic(_, _) => 5,
            ConstantPoolEntry::InvokeDynamic(_, _) => 5,
            ConstantPoolEntry::Module(_) => 3,
            ConstantPoolEntry::Package(_) => 3,
        }
    }
}

/// Constant Pool 전체
#[derive(Debug, Clone)]
pub struct ConstantPool {
    /// entries[0]은 None (1-indexed)
    pub entries: Vec<Option<ConstantPoolEntry>>,
}

impl ConstantPool {
    pub fn new() -> Self {
        ConstantPool {
            entries: vec![None],  // index 0은 비움
        }
    }

    pub fn get(&self, index: u16) -> Result<&ConstantPoolEntry> {
        let idx = index as usize;
        self.entries
            .get(idx)
            .and_then(|e| e.as_ref())
            .ok_or_else(|| crate::utils::error::C2JError::InvalidConstantPoolIndex(index))
    }

    pub fn get_utf8(&self, index: u16) -> Result<&str> {
        match self.get(index)? {
            ConstantPoolEntry::Utf8(s) => Ok(s),
            _ => Err(crate::utils::error::C2JError::InvalidConstantPoolType(index)),
        }
    }

    pub fn add(&mut self, entry: ConstantPoolEntry) -> u16 {
        let index = self.entries.len() as u16;
        self.entries.push(Some(entry.clone()));

        // Long과 Double은 2개 슬롯 차지
        if entry.takes_two_slots() {
            self.entries.push(None);
        }

        index
    }

    pub fn size(&self) -> u16 {
        self.entries.len() as u16
    }
}

impl Default for ConstantPool {
    fn default() -> Self {
        Self::new()
    }
}
