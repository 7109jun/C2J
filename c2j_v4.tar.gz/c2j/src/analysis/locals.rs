//! Local Variable 분석
//!
//! 각 로컬 변수 슬롯의 타입, 이름, 생존 범위를 추적합니다.
//! LocalVariableTable attribute가 있으면 사용하고, 없으면 타입 추론으로 복원합니다.

use std::collections::HashMap;
use crate::bytecode::decoder::{Instruction, InstructionOperand};
use crate::bytecode::instruction::Opcode;
use crate::analysis::stack::JvmType;

/// 단일 로컬 변수 슬롯 정보
#[derive(Debug, Clone)]
pub struct LocalVariable {
    pub slot: u16,
    pub name: String,
    pub ty: JvmType,
    pub live_from: u32,   // 처음 쓰이는 PC
    pub live_to: u32,     // 마지막 쓰이는 PC
}

/// 메서드 전체의 로컬 변수 분석 결과
pub struct LocalVarAnalysis {
    /// slot → 해당 슬롯에서의 변수 목록 (같은 슬롯 재사용 가능)
    pub vars: HashMap<u16, Vec<LocalVariable>>,
    /// 파라미터 슬롯 수 (this + args)
    pub param_count: usize,
    /// 정적 메서드 여부
    pub is_static: bool,
}

impl LocalVarAnalysis {
    pub fn get_name(&self, slot: u16, pc: u32) -> String {
        if let Some(list) = self.vars.get(&slot) {
            for var in list {
                if pc >= var.live_from && pc <= var.live_to {
                    return var.name.clone();
                }
            }
            // 범위 밖이어도 이름 반환
            if let Some(first) = list.first() {
                return first.name.clone();
            }
        }
        format!("local{}", slot)
    }

    pub fn get_type(&self, slot: u16, pc: u32) -> JvmType {
        if let Some(list) = self.vars.get(&slot) {
            for var in list {
                if pc >= var.live_from && pc <= var.live_to {
                    return var.ty.clone();
                }
            }
        }
        JvmType::Reference(None)
    }
}

pub struct LocalVarAnalyzer;

impl LocalVarAnalyzer {
    /// 명령어 스트림 + 파라미터 타입으로 로컬 변수 분석
    pub fn analyze(
        instructions: &[Instruction],
        param_types: &[JvmType],
        is_static: bool,
        max_locals: u16,
    ) -> LocalVarAnalysis {
        let mut vars: HashMap<u16, Vec<LocalVariable>> = HashMap::new();

        // 1단계: 파라미터 초기화
        let mut slot = 0u16;
        if !is_static {
            vars.entry(0).or_default().push(LocalVariable {
                slot: 0,
                name: "this".into(),
                ty: JvmType::Reference(None),
                live_from: 0,
                live_to: u32::MAX,
            });
            slot += 1;
        }
        for (i, ty) in param_types.iter().enumerate() {
            let arg_name = Self::param_name(i, ty);
            let live_to = instructions.last().map(|i| i.pc).unwrap_or(0);
            vars.entry(slot).or_default().push(LocalVariable {
                slot,
                name: arg_name,
                ty: ty.clone(),
                live_from: 0,
                live_to,
            });
            slot += if matches!(ty, JvmType::Long | JvmType::Double) { 2 } else { 1 };
        }

        // 2단계: store 명령어에서 변수 타입과 범위 추론
        for instr in instructions {
            let pc = instr.pc;
            if let Some((slot_idx, ty)) = Self::extract_store(instr) {
                let list = vars.entry(slot_idx).or_default();
                // 같은 슬롯에서 이미 파라미터가 있으면 skip
                let already = list.iter().any(|v| v.slot == slot_idx && v.live_from == 0);
                if !already {
                    // 새로운 변수 또는 기존 변수 범위 확장
                    if let Some(existing) = list.iter_mut().find(|v| v.ty == ty || v.ty == JvmType::Reference(None)) {
                        existing.live_to = pc;
                    } else {
                        let var_name = format!("var{}_{}", slot_idx, list.len());
                        list.push(LocalVariable {
                            slot: slot_idx,
                            name: var_name,
                            ty: ty.clone(),
                            live_from: pc,
                            live_to: pc,
                        });
                    }
                }
            }
            // load 명령어로 live_to 범위 확장
            if let Some(slot_idx) = Self::extract_load(instr) {
                if let Some(list) = vars.get_mut(&slot_idx) {
                    if let Some(last) = list.last_mut() {
                        if last.live_to < pc {
                            last.live_to = pc;
                        }
                    }
                }
            }
        }

        // 3단계: 이름이 없는 슬롯 채우기
        for slot_idx in 0..max_locals {
            vars.entry(slot_idx).or_insert_with(|| vec![LocalVariable {
                slot: slot_idx,
                name: format!("local{}", slot_idx),
                ty: JvmType::Reference(None),
                live_from: 0,
                live_to: 0,
            }]);
        }

        let param_count = slot as usize;
        LocalVarAnalysis { vars, param_count, is_static }
    }

    fn param_name(idx: usize, ty: &JvmType) -> String {
        match ty {
            JvmType::Int => format!("i{}", idx),
            JvmType::Long => format!("l{}", idx),
            JvmType::Float => format!("f{}", idx),
            JvmType::Double => format!("d{}", idx),
            JvmType::Boolean => format!("b{}", idx),
            JvmType::Byte => format!("by{}", idx),
            JvmType::Char => format!("c{}", idx),
            JvmType::Short => format!("s{}", idx),
            JvmType::Reference(Some(cls)) => {
                let simple = cls.rsplit('/').next().unwrap_or("obj");
                let lower = simple.chars().next().map(|c| c.to_lowercase().to_string()).unwrap_or_default();
                format!("{}{}{}", lower, &simple[lower.len().min(simple.len())..], idx)
            }
            _ => format!("arg{}", idx),
        }
    }

    fn extract_store(instr: &Instruction) -> Option<(u16, JvmType)> {
        let slot = match &instr.opcode {
            Opcode::Istore  => if let InstructionOperand::LocalVarIndex(i) = instr.operands { i } else { return None; },
            Opcode::Istore0 => 0, Opcode::Istore1 => 1, Opcode::Istore2 => 2, Opcode::Istore3 => 3,
            Opcode::Lstore  => if let InstructionOperand::LocalVarIndex(i) = instr.operands { i } else { return None; },
            Opcode::Lstore0 => 0, Opcode::Lstore1 => 1, Opcode::Lstore2 => 2, Opcode::Lstore3 => 3,
            Opcode::Fstore  => if let InstructionOperand::LocalVarIndex(i) = instr.operands { i } else { return None; },
            Opcode::Fstore0 => 0, Opcode::Fstore1 => 1, Opcode::Fstore2 => 2, Opcode::Fstore3 => 3,
            Opcode::Dstore  => if let InstructionOperand::LocalVarIndex(i) = instr.operands { i } else { return None; },
            Opcode::Dstore0 => 0, Opcode::Dstore1 => 1, Opcode::Dstore2 => 2, Opcode::Dstore3 => 3,
            Opcode::Astore  => if let InstructionOperand::LocalVarIndex(i) = instr.operands { i } else { return None; },
            Opcode::Astore0 => 0, Opcode::Astore1 => 1, Opcode::Astore2 => 2, Opcode::Astore3 => 3,
            _ => return None,
        };
        let ty = match &instr.opcode {
            Opcode::Istore | Opcode::Istore0 | Opcode::Istore1 | Opcode::Istore2 | Opcode::Istore3 => JvmType::Int,
            Opcode::Lstore | Opcode::Lstore0 | Opcode::Lstore1 | Opcode::Lstore2 | Opcode::Lstore3 => JvmType::Long,
            Opcode::Fstore | Opcode::Fstore0 | Opcode::Fstore1 | Opcode::Fstore2 | Opcode::Fstore3 => JvmType::Float,
            Opcode::Dstore | Opcode::Dstore0 | Opcode::Dstore1 | Opcode::Dstore2 | Opcode::Dstore3 => JvmType::Double,
            _ => JvmType::Reference(None),
        };
        Some((slot, ty))
    }

    fn extract_load(instr: &Instruction) -> Option<u16> {
        match &instr.opcode {
            Opcode::Iload  | Opcode::Lload  | Opcode::Fload  | Opcode::Dload  | Opcode::Aload =>
                if let InstructionOperand::LocalVarIndex(i) = instr.operands { Some(i) } else { None },
            Opcode::Iload0 | Opcode::Lload0 | Opcode::Fload0 | Opcode::Dload0 | Opcode::Aload0 => Some(0),
            Opcode::Iload1 | Opcode::Lload1 | Opcode::Fload1 | Opcode::Dload1 | Opcode::Aload1 => Some(1),
            Opcode::Iload2 | Opcode::Lload2 | Opcode::Fload2 | Opcode::Dload2 | Opcode::Aload2 => Some(2),
            Opcode::Iload3 | Opcode::Lload3 | Opcode::Fload3 | Opcode::Dload3 | Opcode::Aload3 => Some(3),
            _ => None,
        }
    }
}
