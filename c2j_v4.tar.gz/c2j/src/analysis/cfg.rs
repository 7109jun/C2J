//! Control Flow Graph (CFG)
//!
//! Bytecode 명령어 스트림을 Basic Block 단위로 분할하고,
//! 블록 간 제어 흐름을 Edge로 연결합니다.

use std::collections::{HashMap, HashSet, VecDeque};
use crate::bytecode::instruction::Opcode;
use crate::bytecode::decoder::{BytecodeDecoder, Instruction};
use crate::classfile::structures::ExceptionHandler;
use crate::utils::{Result, C2JError};

/// Basic Block (연속적인 명령어의 묶음)
#[derive(Debug, Clone)]
pub struct BasicBlock {
    pub id: u32,
    pub start_pc: u32,
    pub end_pc: u32,                         // 마지막 명령어 PC (포함)
    pub instructions: Vec<Instruction>,
    pub successors: Vec<BlockEdge>,          // 이 블록 → 다음 블록
    pub predecessors: Vec<u32>,             // 이전 블록 IDs
    pub kind: BlockKind,
}

/// 블록의 종류
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BlockKind {
    Normal,
    Entry,                   // 메서드 진입
    Exit,                    // 반환 (return, athrow)
    ExceptionHandler(u16),  // catch 블록 (catch_type CP index)
}

/// 블록 간 엣지의 종류
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BlockEdge {
    pub target_id: u32,
    pub kind: EdgeKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EdgeKind {
    FallThrough,       // 조건 불충족 또는 순차 진행
    Branch,            // 조건 충족 분기 또는 goto
    Switch(i32),       // switch의 특정 케이스 (match 값)
    SwitchDefault,     // switch default
    Exception,         // exception edge
}

/// CFG 전체
pub struct ControlFlowGraph {
    pub blocks: Vec<BasicBlock>,
    pub entry_id: u32,
    /// PC → Block ID 매핑
    pub pc_to_block: HashMap<u32, u32>,
}

impl ControlFlowGraph {
    pub fn get_block(&self, id: u32) -> Option<&BasicBlock> {
        self.blocks.iter().find(|b| b.id == id)
    }

    pub fn get_block_mut(&mut self, id: u32) -> Option<&mut BasicBlock> {
        self.blocks.iter_mut().find(|b| b.id == id)
    }

    /// 역순 후위 순서로 블록 ID 반환 (지배자 트리 계산에 필요)
    pub fn reverse_post_order(&self) -> Vec<u32> {
        let mut visited = HashSet::new();
        let mut order = Vec::new();
        self.dfs(self.entry_id, &mut visited, &mut order);
        order.reverse();
        order
    }

    fn dfs(&self, id: u32, visited: &mut HashSet<u32>, order: &mut Vec<u32>) {
        if !visited.insert(id) { return; }
        if let Some(block) = self.get_block(id) {
            for edge in &block.successors {
                self.dfs(edge.target_id, visited, order);
            }
        }
        order.push(id);
    }

    /// 루프 헤더 블록 ID 집합 반환 (back edge 감지)
    pub fn find_loop_headers(&self) -> HashSet<u32> {
        let mut headers = HashSet::new();
        let mut visiting = HashSet::new();
        let mut visited = HashSet::new();
        self.find_back_edges(self.entry_id, &mut visiting, &mut visited, &mut headers);
        headers
    }

    fn find_back_edges(
        &self, id: u32,
        visiting: &mut HashSet<u32>,
        visited: &mut HashSet<u32>,
        headers: &mut HashSet<u32>,
    ) {
        if visited.contains(&id) { return; }
        visiting.insert(id);
        if let Some(block) = self.get_block(id) {
            for edge in &block.successors {
                if visiting.contains(&edge.target_id) {
                    headers.insert(edge.target_id);
                } else {
                    self.find_back_edges(edge.target_id, visiting, visited, headers);
                }
            }
        }
        visiting.remove(&id);
        visited.insert(id);
    }
}

/// CFG 생성기
pub struct CfgBuilder;

impl CfgBuilder {
    /// 명령어 스트림 + 예외 테이블 → CFG
    pub fn build(
        instructions: &[Instruction],
        exception_handlers: &[ExceptionHandler],
    ) -> Result<ControlFlowGraph> {
        if instructions.is_empty() {
            return Err(C2JError::InternalError("Empty instruction list".into()));
        }

        // 1단계: 블록 경계(Leaders) 수집
        let leaders = Self::find_leaders(instructions, exception_handlers);

        // 2단계: Basic Block 생성
        let mut blocks = Self::build_blocks(instructions, &leaders);

        // 3단계: PC → Block ID 매핑
        let pc_to_block: HashMap<u32, u32> = blocks.iter()
            .flat_map(|b| b.instructions.iter().map(move |i| (i.pc, b.id)))
            .collect();

        // 4단계: 엣지 연결
        Self::connect_edges(&mut blocks, &pc_to_block, instructions, exception_handlers);

        // 5단계: predecessor 채우기
        Self::fill_predecessors(&mut blocks);

        // 6단계: 진입/종료 블록 종류 표시
        if let Some(first) = blocks.first_mut() {
            first.kind = BlockKind::Entry;
        }
        for block in &mut blocks {
            let last_op = block.instructions.last().map(|i| &i.opcode);
            if matches!(last_op,
                Some(Opcode::Return) | Some(Opcode::Ireturn) | Some(Opcode::Lreturn)
                | Some(Opcode::Freturn) | Some(Opcode::Dreturn) | Some(Opcode::Areturn)
                | Some(Opcode::Athrow)
            ) {
                block.kind = BlockKind::Exit;
            }
        }

        // 7단계: 예외 핸들러 블록 표시
        for eh in exception_handlers {
            let handler_pc = eh.handler_pc as u32;
            if let Some(id) = pc_to_block.get(&handler_pc) {
                if let Some(block) = blocks.iter_mut().find(|b| b.id == *id) {
                    block.kind = BlockKind::ExceptionHandler(eh.catch_type);
                }
            }
        }

        let entry_id = blocks[0].id;

        Ok(ControlFlowGraph { blocks, entry_id, pc_to_block })
    }

    /// Leader PC 집합 수집
    ///   - 첫 명령어는 항상 leader
    ///   - 분기 대상은 leader
    ///   - 분기 다음 명령어는 leader
    ///   - exception handler는 leader
    fn find_leaders(
        instructions: &[Instruction],
        exception_handlers: &[ExceptionHandler],
    ) -> HashSet<u32> {
        let mut leaders = HashSet::new();

        // 첫 명령어
        if let Some(first) = instructions.first() {
            leaders.insert(first.pc);
        }

        // 예외 핸들러
        for eh in exception_handlers {
            leaders.insert(eh.handler_pc as u32);
        }

        // 분기 관련
        for (i, instr) in instructions.iter().enumerate() {
            let is_branch = BytecodeDecoder::is_unconditional_branch(&instr.opcode)
                || BytecodeDecoder::is_conditional_branch(&instr.opcode);

            if is_branch {
                // 분기 대상들
                for target in BytecodeDecoder::branch_targets(instr) {
                    leaders.insert(target);
                }
                // 분기 다음 명령어 (fall-through 후보)
                if let Some(next) = instructions.get(i + 1) {
                    leaders.insert(next.pc);
                }
            }
        }

        leaders
    }

    /// Basic Block 생성
    fn build_blocks(
        instructions: &[Instruction],
        leaders: &HashSet<u32>,
    ) -> Vec<BasicBlock> {
        let mut blocks = Vec::new();
        let mut current: Vec<Instruction> = Vec::new();
        let mut next_id: u32 = 0;

        for instr in instructions {
            if leaders.contains(&instr.pc) && !current.is_empty() {
                let start_pc = current.first().unwrap().pc;
                let end_pc   = current.last().unwrap().pc;
                blocks.push(BasicBlock {
                    id: next_id,
                    start_pc,
                    end_pc,
                    instructions: std::mem::take(&mut current),
                    successors: Vec::new(),
                    predecessors: Vec::new(),
                    kind: BlockKind::Normal,
                });
                next_id += 1;
            }
            current.push(instr.clone());
        }

        // 마지막 블록
        if !current.is_empty() {
            let start_pc = current.first().unwrap().pc;
            let end_pc   = current.last().unwrap().pc;
            blocks.push(BasicBlock {
                id: next_id,
                start_pc,
                end_pc,
                instructions: current,
                successors: Vec::new(),
                predecessors: Vec::new(),
                kind: BlockKind::Normal,
            });
        }

        blocks
    }

    /// 블록 간 엣지 연결
    fn connect_edges(
        blocks: &mut Vec<BasicBlock>,
        pc_to_block: &HashMap<u32, u32>,
        instructions: &[Instruction],
        exception_handlers: &[ExceptionHandler],
    ) {
        let pc_list: Vec<u32> = instructions.iter().map(|i| i.pc).collect();

        for block_idx in 0..blocks.len() {
            let last_instr = match blocks[block_idx].instructions.last() {
                Some(i) => i.clone(),
                None => continue,
            };
            let block_id = blocks[block_idx].id;
            let last_pc = last_instr.pc;
            let last_byte_size = last_instr.byte_size;

            let mut edges: Vec<BlockEdge> = Vec::new();

            if BytecodeDecoder::is_unconditional_branch(&last_instr.opcode) {
                match &last_instr.operands {
                    crate::bytecode::decoder::InstructionOperand::BranchOffset(off) => {
                        let target = (last_pc as i64 + *off as i64) as u32;
                        if let Some(&tid) = pc_to_block.get(&target) {
                            edges.push(BlockEdge { target_id: tid, kind: EdgeKind::Branch });
                        }
                    }
                    crate::bytecode::decoder::InstructionOperand::TableSwitch { default_offset, offsets, low, .. } => {
                        let default_target = (last_pc as i64 + *default_offset as i64) as u32;
                        if let Some(&tid) = pc_to_block.get(&default_target) {
                            edges.push(BlockEdge { target_id: tid, kind: EdgeKind::SwitchDefault });
                        }
                        for (i, off) in offsets.iter().enumerate() {
                            let target = (last_pc as i64 + *off as i64) as u32;
                            if let Some(&tid) = pc_to_block.get(&target) {
                                let match_val = *low + i as i32;
                                edges.push(BlockEdge { target_id: tid, kind: EdgeKind::Switch(match_val) });
                            }
                        }
                    }
                    crate::bytecode::decoder::InstructionOperand::LookupSwitch { default_offset, pairs } => {
                        let default_target = (last_pc as i64 + *default_offset as i64) as u32;
                        if let Some(&tid) = pc_to_block.get(&default_target) {
                            edges.push(BlockEdge { target_id: tid, kind: EdgeKind::SwitchDefault });
                        }
                        for (match_val, off) in pairs {
                            let target = (last_pc as i64 + *off as i64) as u32;
                            if let Some(&tid) = pc_to_block.get(&target) {
                                edges.push(BlockEdge { target_id: tid, kind: EdgeKind::Switch(*match_val) });
                            }
                        }
                    }
                    _ => {} // return, athrow → 종료
                }
            } else if BytecodeDecoder::is_conditional_branch(&last_instr.opcode) {
                // 조건 분기: branch 대상 + fall-through
                if let crate::bytecode::decoder::InstructionOperand::BranchOffset(off) = last_instr.operands {
                    let target = (last_pc as i64 + off as i64) as u32;
                    if let Some(&tid) = pc_to_block.get(&target) {
                        edges.push(BlockEdge { target_id: tid, kind: EdgeKind::Branch });
                    }
                }
                // fall-through: 다음 명령어의 블록
                let next_pc = last_pc + last_byte_size;
                if let Some(&tid) = pc_to_block.get(&next_pc) {
                    edges.push(BlockEdge { target_id: tid, kind: EdgeKind::FallThrough });
                }
            } else {
                // 일반 명령어: fall-through
                let next_pc = last_pc + last_byte_size;
                if let Some(&tid) = pc_to_block.get(&next_pc) {
                    edges.push(BlockEdge { target_id: tid, kind: EdgeKind::FallThrough });
                }
            }

            // 예외 핸들러 엣지
            for eh in exception_handlers {
                let start = eh.start_pc as u32;
                let end   = eh.end_pc as u32;
                if last_pc >= start && last_pc < end {
                    let handler_pc = eh.handler_pc as u32;
                    if let Some(&tid) = pc_to_block.get(&handler_pc) {
                        if !edges.iter().any(|e| e.target_id == tid) {
                            edges.push(BlockEdge { target_id: tid, kind: EdgeKind::Exception });
                        }
                    }
                }
            }

            blocks[block_idx].successors = edges;
        }
    }

    /// predecessor 채우기
    fn fill_predecessors(blocks: &mut Vec<BasicBlock>) {
        let edges: Vec<(u32, u32)> = blocks.iter()
            .flat_map(|b| b.successors.iter().map(move |e| (b.id, e.target_id)))
            .collect();

        for (from, to) in edges {
            if let Some(block) = blocks.iter_mut().find(|b| b.id == to) {
                if !block.predecessors.contains(&from) {
                    block.predecessors.push(from);
                }
            }
        }
    }
}

/// CFG 시각화 (디버그용)
pub fn dump_cfg(cfg: &ControlFlowGraph) -> String {
    let mut out = String::new();
    out.push_str("=== Control Flow Graph ===\n");
    for block in &cfg.blocks {
        out.push_str(&format!(
            "\nBlock #{} [pc={}-{}] {:?}\n",
            block.id, block.start_pc, block.end_pc, block.kind
        ));
        out.push_str(&format!("  predecessors: {:?}\n", block.predecessors));
        out.push_str("  instructions:\n");
        for instr in &block.instructions {
            out.push_str(&format!("    pc={:4} {:?}\n", instr.pc, instr.opcode));
        }
        out.push_str("  successors:\n");
        for edge in &block.successors {
            out.push_str(&format!("    → Block #{} ({:?})\n", edge.target_id, edge.kind));
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::bytecode::decoder::BytecodeDecoder;

    #[test]
    fn test_simple_linear_cfg() {
        // iload_0, iload_1, iadd, ireturn — 4 instructions, 1 block
        let code = vec![0x1Au8, 0x1B, 0x60, 0xAC];
        let instrs = BytecodeDecoder::decode(&code).unwrap();
        let cfg = CfgBuilder::build(&instrs, &[]).unwrap();

        assert_eq!(cfg.blocks.len(), 1);
        assert_eq!(cfg.blocks[0].instructions.len(), 4);
        assert!(cfg.blocks[0].successors.is_empty());
    }

    #[test]
    fn test_conditional_branch_cfg() {
        // iload_0, ifeq +3, iload_1, ireturn
        // pc: 0=iload_0 (1), 1=ifeq +3 (3), 4=iload_1 (1), 5=ireturn (1)
        // ifeq 대상: pc=1, offset=3 → pc=4 (fall-through)
        // 그래서: 4도 leader가 됨 (분기 대상 4, fall-through도 4)
        let code = vec![
            0x1A,               // iload_0  pc=0
            0x99, 0x00, 0x03,   // ifeq +3  pc=1 → target=4
            0x1B,               // iload_1  pc=4
            0xAC,               // ireturn  pc=5
        ];
        let instrs = BytecodeDecoder::decode(&code).unwrap();
        let cfg = CfgBuilder::build(&instrs, &[]).unwrap();

        // Block 0: [iload_0, ifeq]
        // Block 1: [iload_1, ireturn]
        assert_eq!(cfg.blocks.len(), 2);
        // 첫 블록에서 두 번째 블록으로의 엣지가 있어야 함
        assert!(!cfg.blocks[0].successors.is_empty());
    }
}
