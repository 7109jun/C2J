//! Operand Stack 분석
//!
//! JVM은 스택 기반 머신이므로, 각 PC 위치에서의 스택 상태를 추적합니다.
//! 이 정보는 표현식 트리를 구성하는 기반이 됩니다.

use std::collections::HashMap;
use crate::bytecode::instruction::Opcode;
use crate::bytecode::decoder::{Instruction, InstructionOperand, ArrayType};
use crate::constantpool::{ConstantPool, ConstantPoolEntry};
use crate::utils::{Result, C2JError};

/// JVM 타입 시스템 (카테고리 포함)
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum JvmType {
    // Primitive Category 1
    Int,
    Float,
    Boolean,
    Byte,
    Char,
    Short,

    // Primitive Category 2 (2슬롯)
    Long,
    Double,

    // Reference
    Reference(Option<String>),   // Some("java/lang/String") 또는 None(unknown)
    Array(Box<JvmType>),
    Null,                         // aconst_null

    // Internal
    ReturnAddress,               // jsr/ret 전용
    Top,                         // 미확정 / Category2 상위 슬롯 placeholder
    Void,
}

impl JvmType {
    /// Category 1 (1 스택 슬롯)인지 여부
    pub fn is_category1(&self) -> bool {
        !matches!(self, JvmType::Long | JvmType::Double | JvmType::Top)
    }

    /// Java 소스에서의 타입 이름
    pub fn to_java_source(&self) -> String {
        match self {
            JvmType::Int => "int".into(),
            JvmType::Float => "float".into(),
            JvmType::Boolean => "boolean".into(),
            JvmType::Byte => "byte".into(),
            JvmType::Char => "char".into(),
            JvmType::Short => "short".into(),
            JvmType::Long => "long".into(),
            JvmType::Double => "double".into(),
            JvmType::Null => "null".into(),
            JvmType::Void => "void".into(),
            JvmType::ReturnAddress => "returnAddress".into(),
            JvmType::Top => "?".into(),
            JvmType::Reference(Some(cls)) => cls.replace('/', "."),
            JvmType::Reference(None) => "Object".into(),
            JvmType::Array(inner) => format!("{}[]", inner.to_java_source()),
        }
    }

    /// 내부 descriptor에서 JvmType 파싱
    pub fn from_descriptor_char(c: char) -> Option<Self> {
        match c {
            'I' => Some(JvmType::Int),
            'J' => Some(JvmType::Long),
            'F' => Some(JvmType::Float),
            'D' => Some(JvmType::Double),
            'Z' => Some(JvmType::Boolean),
            'B' => Some(JvmType::Byte),
            'C' => Some(JvmType::Char),
            'S' => Some(JvmType::Short),
            'V' => Some(JvmType::Void),
            _ => None,
        }
    }
}

/// 스택의 단일 슬롯 값 (타입 + 표현식)
#[derive(Debug, Clone)]
pub struct StackValue {
    pub ty: JvmType,
    pub source: ValueSource,
}

/// 이 스택 값이 어디서 왔는지
#[derive(Debug, Clone)]
pub enum ValueSource {
    LocalVar(u16),
    Constant(ConstantValue),
    Computation(Box<Computation>),
    FieldAccess { class: String, field: String, is_static: bool },
    MethodResult { class: String, method: String, descriptor: String },
    ArrayElement,
    NewObject(String),
    NewArray(JvmType),
    This,
    Argument(u16),
    Unknown,
}

#[derive(Debug, Clone)]
pub enum ConstantValue {
    Null,
    Int(i32),
    Long(i64),
    Float(f32),
    Double(f64),
    String(String),
    Class(String),
}

#[derive(Debug, Clone)]
pub struct Computation {
    pub op: ComputationOp,
    pub inputs: Vec<StackValue>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComputationOp {
    // 산술
    IAdd, ISub, IMul, IDiv, IRem, INeg,
    LAdd, LSub, LMul, LDiv, LRem, LNeg,
    FAdd, FSub, FMul, FDiv, FRem, FNeg,
    DAdd, DSub, DMul, DDiv, DRem, DNeg,
    // 비트
    IShl, IShr, IUShr, IAnd, IOr, IXor,
    LShl, LShr, LUShr, LAnd, LOr, LXor,
    // 비교
    LCmp, FCmpL, FCmpG, DCmpL, DCmpG,
    // 변환
    I2L, I2F, I2D, L2I, L2F, L2D,
    F2I, F2L, F2D, D2I, D2L, D2F,
    I2B, I2C, I2S,
    // 타입
    Checkcast, Instanceof, ArrayLength,
}

/// 단일 PC에서의 스택 상태
#[derive(Debug, Clone)]
pub struct StackFrame {
    pub pc: u32,
    pub stack: Vec<StackValue>,
    pub depth: usize,
}

impl StackFrame {
    pub fn empty(pc: u32) -> Self {
        StackFrame { pc, stack: Vec::new(), depth: 0 }
    }
}

/// 스택 분석기 — 각 PC에서의 스택 상태를 계산
pub struct StackAnalyzer<'a> {
    cp: &'a ConstantPool,
    is_static: bool,
    param_types: Vec<JvmType>,
}

/// 스택 분석 결과
pub struct StackAnalysisResult {
    /// PC → 해당 명령어 직전 스택 상태
    pub frames: HashMap<u32, StackFrame>,
    /// 각 명령어가 스택에서 꺼내는 값 목록
    pub pops: HashMap<u32, Vec<StackValue>>,
    /// 각 명령어가 스택에 올리는 값
    pub pushes: HashMap<u32, Vec<StackValue>>,
}

impl<'a> StackAnalyzer<'a> {
    pub fn new(cp: &'a ConstantPool, is_static: bool, param_types: Vec<JvmType>) -> Self {
        StackAnalyzer { cp, is_static, param_types }
    }

    /// 주어진 명령어 스트림 분석
    pub fn analyze(&self, instructions: &[Instruction]) -> Result<StackAnalysisResult> {
        let mut frames: HashMap<u32, StackFrame> = HashMap::new();
        let mut pops: HashMap<u32, Vec<StackValue>> = HashMap::new();
        let mut pushes: HashMap<u32, Vec<StackValue>> = HashMap::new();

        // 초기 스택: 비어 있음
        let mut current_stack: Vec<StackValue> = Vec::new();

        for instr in instructions {
            let pc = instr.pc;

            // 현재 스택 상태 저장
            frames.insert(pc, StackFrame {
                pc,
                stack: current_stack.clone(),
                depth: current_stack.len(),
            });

            // 이 명령어의 pop/push 처리
            let (popped, pushed) = self.simulate(instr, &mut current_stack)?;
            pops.insert(pc, popped);
            pushes.insert(pc, pushed);
        }

        Ok(StackAnalysisResult { frames, pops, pushes })
    }

    /// 단일 명령어에 대한 스택 시뮬레이션
    fn simulate(
        &self,
        instr: &Instruction,
        stack: &mut Vec<StackValue>,
    ) -> Result<(Vec<StackValue>, Vec<StackValue>)> {
        use Opcode::*;
        let pc = instr.pc;

        macro_rules! pop {
            () => {{
                stack.pop().ok_or_else(|| C2JError::InternalError(
                    format!("Stack underflow at pc={}", pc)
                ))?
            }};
        }

        macro_rules! push {
            ($ty:expr, $src:expr) => {
                stack.push(StackValue { ty: $ty, source: $src })
            };
        }

        let mut popped = Vec::new();
        let mut pushed_values = Vec::new();

        match &instr.opcode {
            // ── 상수 ──────────────────────────────────────────────────────
            Nop => {}

            AconstNull => {
                let v = StackValue { ty: JvmType::Null, source: ValueSource::Constant(ConstantValue::Null) };
                pushed_values.push(v.clone());
                stack.push(v);
            }

            IconstM1 | Iconst0 | Iconst1 | Iconst2 | Iconst3 | Iconst4 | Iconst5 => {
                let n: i32 = match instr.opcode {
                    IconstM1 => -1, Iconst0 => 0, Iconst1 => 1,
                    Iconst2 => 2, Iconst3 => 3, Iconst4 => 4, Iconst5 => 5, _ => unreachable!()
                };
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Constant(ConstantValue::Int(n)) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Lconst0 | Lconst1 => {
                let n: i64 = if instr.opcode == Lconst0 { 0 } else { 1 };
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Constant(ConstantValue::Long(n)) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Fconst0 | Fconst1 | Fconst2 => {
                let n: f32 = match instr.opcode { Fconst0 => 0.0, Fconst1 => 1.0, _ => 2.0 };
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Constant(ConstantValue::Float(n)) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Dconst0 | Dconst1 => {
                let n: f64 = if instr.opcode == Dconst0 { 0.0 } else { 1.0 };
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Constant(ConstantValue::Double(n)) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Bipush | Sipush => {
                if let InstructionOperand::IntValue(n) = instr.operands {
                    let v = StackValue { ty: JvmType::Int, source: ValueSource::Constant(ConstantValue::Int(n)) };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }

            Ldc | LdcW | Ldc2W => {
                let v = self.ldc_value(&instr.operands)?;
                pushed_values.push(v.clone()); stack.push(v);
            }

            // ── Load ──────────────────────────────────────────────────────
            Iload | Iload0 | Iload1 | Iload2 | Iload3 => {
                let idx = self.local_index(&instr.opcode, &instr.operands, 0..=3);
                let v = StackValue { ty: JvmType::Int, source: ValueSource::LocalVar(idx) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Lload | Lload0 | Lload1 | Lload2 | Lload3 => {
                let idx = self.local_index(&instr.opcode, &instr.operands, 0..=3);
                let v = StackValue { ty: JvmType::Long, source: ValueSource::LocalVar(idx) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Fload | Fload0 | Fload1 | Fload2 | Fload3 => {
                let idx = self.local_index(&instr.opcode, &instr.operands, 0..=3);
                let v = StackValue { ty: JvmType::Float, source: ValueSource::LocalVar(idx) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Dload | Dload0 | Dload1 | Dload2 | Dload3 => {
                let idx = self.local_index(&instr.opcode, &instr.operands, 0..=3);
                let v = StackValue { ty: JvmType::Double, source: ValueSource::LocalVar(idx) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Aload | Aload0 | Aload1 | Aload2 | Aload3 => {
                let idx = self.local_index(&instr.opcode, &instr.operands, 0..=3);
                let src = if idx == 0 && !self.is_static {
                    ValueSource::This
                } else {
                    ValueSource::LocalVar(idx)
                };
                let v = StackValue { ty: JvmType::Reference(None), source: src };
                pushed_values.push(v.clone()); stack.push(v);
            }

            // ── Array Load ────────────────────────────────────────────────
            Iaload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Int, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Laload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Long, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Faload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Float, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Daload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Double, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Aaload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Reference(None), source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Baload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Byte, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Caload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Char, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }
            Saload => { let _idx = pop!(); let _arr = pop!(); popped.extend([_arr, _idx]);
                let v = StackValue { ty: JvmType::Short, source: ValueSource::ArrayElement };
                pushed_values.push(v.clone()); stack.push(v); }

            // ── Store (스택에서 pop만) ────────────────────────────────────
            Istore | Istore0 | Istore1 | Istore2 | Istore3
            | Lstore | Lstore0 | Lstore1 | Lstore2 | Lstore3
            | Fstore | Fstore0 | Fstore1 | Fstore2 | Fstore3
            | Dstore | Dstore0 | Dstore1 | Dstore2 | Dstore3
            | Astore | Astore0 | Astore1 | Astore2 | Astore3 => {
                let v = pop!(); popped.push(v);
            }

            // ── Array Store ───────────────────────────────────────────────
            Iastore | Lastore | Fastore | Dastore | Aastore | Bastore | Castore | Sastore => {
                let val = pop!(); let idx = pop!(); let arr = pop!();
                popped.extend([arr, idx, val]);
            }

            // ── Stack manipulation ────────────────────────────────────────
            Pop => { let v = pop!(); popped.push(v); }
            Pop2 => {
                let v1 = pop!(); 
                if v1.ty.is_category1() {
                    let v2 = pop!();
                    popped.extend([v2, v1]);
                } else {
                    popped.push(v1);
                }
            }

            Dup => {
                let v = stack.last().cloned().ok_or_else(|| C2JError::InternalError("dup on empty stack".into()))?;
                pushed_values.push(v.clone()); stack.push(v);
            }
            DupX1 => {
                let v1 = pop!(); let v2 = pop!();
                stack.push(v1.clone()); stack.push(v2.clone()); stack.push(v1.clone());
                pushed_values.push(v1);
            }
            DupX2 => {
                let v1 = pop!(); let v2 = pop!();
                if v2.ty.is_category1() {
                    let v3 = pop!();
                    stack.push(v1.clone()); stack.push(v3); stack.push(v2); stack.push(v1.clone());
                } else {
                    stack.push(v1.clone()); stack.push(v2); stack.push(v1.clone());
                }
                pushed_values.push(v1);
            }
            Dup2 => {
                let v1 = pop!();
                if v1.ty.is_category1() {
                    let v2 = pop!();
                    stack.push(v2.clone()); stack.push(v1.clone());
                    stack.push(v2.clone()); stack.push(v1.clone());
                    pushed_values.extend([v2, v1]);
                } else {
                    stack.push(v1.clone()); stack.push(v1.clone());
                    pushed_values.push(v1);
                }
            }
            Dup2X1 => {
                let v1 = pop!(); let v2 = pop!();
                if v1.ty.is_category1() {
                    let v3 = pop!();
                    stack.push(v2.clone()); stack.push(v1.clone());
                    stack.push(v3); stack.push(v2); stack.push(v1.clone());
                } else {
                    stack.push(v1.clone()); stack.push(v2); stack.push(v1.clone());
                }
                pushed_values.push(v1);
            }
            Dup2X2 => {
                // 단순화: Category-1 x 4 케이스만 처리
                let v1 = pop!(); let v2 = pop!(); let v3 = pop!();
                if v1.ty.is_category1() {
                    let v4 = pop!();
                    stack.push(v2.clone()); stack.push(v1.clone());
                    stack.push(v4); stack.push(v3); stack.push(v2); stack.push(v1.clone());
                } else {
                    stack.push(v1.clone()); stack.push(v3); stack.push(v2); stack.push(v1.clone());
                }
                pushed_values.push(v1);
            }
            Swap => {
                let v1 = pop!(); let v2 = pop!();
                stack.push(v1); stack.push(v2);
            }

            // ── 산술 (2 pop, 1 push) ──────────────────────────────────────
            Iadd | Isub | Imul | Idiv | Irem | Iand | Ior | Ixor | Ishl | Ishr | Iushr => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let op = match instr.opcode {
                    Iadd => ComputationOp::IAdd, Isub => ComputationOp::ISub, Imul => ComputationOp::IMul,
                    Idiv => ComputationOp::IDiv, Irem => ComputationOp::IRem, Iand => ComputationOp::IAnd,
                    Ior  => ComputationOp::IOr,  Ixor => ComputationOp::IXor, Ishl => ComputationOp::IShl,
                    Ishr => ComputationOp::IShr, Iushr => ComputationOp::IUShr, _ => unreachable!()
                };
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Ineg => {
                let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::INeg, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Ladd | Lsub | Lmul | Ldiv | Lrem | Land | Lor | Lxor | Lshl | Lshr | Lushr => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::LAdd, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Lneg => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::LNeg, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            Fadd | Fsub | Fmul | Fdiv | Frem => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::FAdd, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Fneg => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::FNeg, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            Dadd | Dsub | Dmul | Ddiv | Drem => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::DAdd, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Dneg => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::DNeg, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }

            Iinc => { /* 로컬 변수 직접 증가, 스택 변화 없음 */ }

            // ── 형 변환 ───────────────────────────────────────────────────
            I2l => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2L, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            I2f => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2F, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            I2d => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2D, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            L2i => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::L2I, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            L2f => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::L2F, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            L2d => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::L2D, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            F2i => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::F2I, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            F2l => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::F2L, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            F2d => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Double, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::F2D, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            D2i => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::D2I, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            D2l => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Long, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::D2L, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            D2f => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Float, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::D2F, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            I2b => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Byte, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2B, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            I2c => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Char, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2C, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }
            I2s => { let a = pop!(); popped.push(a.clone());
                let v = StackValue { ty: JvmType::Short, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::I2S, inputs: vec![a] })) };
                pushed_values.push(v.clone()); stack.push(v); }

            // ── 비교 ──────────────────────────────────────────────────────
            Lcmp => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::LCmp, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Fcmpl | Fcmpg => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let op = if instr.opcode == Fcmpl { ComputationOp::FCmpL } else { ComputationOp::FCmpG };
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Dcmpl | Dcmpg => {
                let b = pop!(); let a = pop!(); popped.extend([a.clone(), b.clone()]);
                let op = if instr.opcode == Dcmpl { ComputationOp::DCmpL } else { ComputationOp::DCmpG };
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op, inputs: vec![a, b] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            // ── 조건 분기 (pop만) ─────────────────────────────────────────
            Ifeq | Ifne | Iflt | Ifge | Ifgt | Ifle | Ifnull | Ifnonnull => {
                let v = pop!(); popped.push(v);
            }
            IfIcmpeq | IfIcmpne | IfIcmplt | IfIcmpge | IfIcmpgt | IfIcmple
            | IfAcmpeq | IfAcmpne => {
                let b = pop!(); let a = pop!(); popped.extend([a, b]);
            }

            // ── 무조건 분기 ───────────────────────────────────────────────
            Goto | GotoW => {}

            // ── 반환 ──────────────────────────────────────────────────────
            Ireturn | Lreturn | Freturn | Dreturn | Areturn => {
                let v = pop!(); popped.push(v);
            }
            Return => {}
            Athrow => { let v = pop!(); popped.push(v); }

            // ── 필드 접근 ─────────────────────────────────────────────────
            Getstatic => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (class, field, ty) = self.resolve_fieldref(idx)?;
                    let v = StackValue { ty, source: ValueSource::FieldAccess { class, field, is_static: true } };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }
            Putstatic => {
                let v = pop!(); popped.push(v);
            }
            Getfield => {
                let obj = pop!(); popped.push(obj);
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (class, field, ty) = self.resolve_fieldref(idx)?;
                    let v = StackValue { ty, source: ValueSource::FieldAccess { class, field, is_static: false } };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }
            Putfield => {
                let val = pop!(); let obj = pop!(); popped.extend([obj, val]);
            }

            // ── 메서드 호출 ───────────────────────────────────────────────
            Invokevirtual | Invokespecial | Invokeinterface => {
                if let InstructionOperand::ConstantPoolIndex(idx)
                    | InstructionOperand::InvokeInterface(idx, _) = instr.operands {
                    let (class, method, desc) = self.resolve_methodref(idx)?;
                    let arg_count = Self::count_method_args(&desc);
                    for _ in 0..arg_count { let v = pop!(); popped.push(v); }
                    let obj = pop!(); popped.push(obj);

                    let ret_ty = Self::parse_return_type(&desc);
                    if ret_ty != JvmType::Void {
                        let v = StackValue {
                            ty: ret_ty,
                            source: ValueSource::MethodResult { class, method, descriptor: desc }
                        };
                        pushed_values.push(v.clone()); stack.push(v);
                    }
                }
            }
            Invokestatic => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let (class, method, desc) = self.resolve_methodref(idx)?;
                    let arg_count = Self::count_method_args(&desc);
                    for _ in 0..arg_count { let v = pop!(); popped.push(v); }

                    let ret_ty = Self::parse_return_type(&desc);
                    if ret_ty != JvmType::Void {
                        let v = StackValue {
                            ty: ret_ty,
                            source: ValueSource::MethodResult { class, method, descriptor: desc }
                        };
                        pushed_values.push(v.clone()); stack.push(v);
                    }
                }
            }
            Invokedynamic => {
                if let InstructionOperand::InvokeDynamic(idx) = instr.operands {
                    // Bootstrap method 처리 — 결과를 lambda로 간주
                    let v = StackValue { ty: JvmType::Reference(None), source: ValueSource::Unknown };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }

            // ── 객체 생성 ─────────────────────────────────────────────────
            New => {
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let class_name = self.resolve_class(idx)?;
                    let v = StackValue {
                        ty: JvmType::Reference(Some(class_name.clone())),
                        source: ValueSource::NewObject(class_name)
                    };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }

            // ── 배열 ──────────────────────────────────────────────────────
            Newarray => {
                let count = pop!(); popped.push(count);
                if let InstructionOperand::NewArray(arr_ty) = &instr.operands {
                    let jty = match arr_ty {
                        ArrayType::Int => JvmType::Int,
                        ArrayType::Long => JvmType::Long,
                        ArrayType::Float => JvmType::Float,
                        ArrayType::Double => JvmType::Double,
                        ArrayType::Boolean => JvmType::Boolean,
                        ArrayType::Byte => JvmType::Byte,
                        ArrayType::Char => JvmType::Char,
                        ArrayType::Short => JvmType::Short,
                    };
                    let v = StackValue {
                        ty: JvmType::Array(Box::new(jty.clone())),
                        source: ValueSource::NewArray(jty)
                    };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }
            Anewarray => {
                let count = pop!(); popped.push(count);
                let v = StackValue { ty: JvmType::Array(Box::new(JvmType::Reference(None))), source: ValueSource::NewArray(JvmType::Reference(None)) };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Multianewarray => {
                if let InstructionOperand::MultiNewArray(_, dims) = instr.operands {
                    for _ in 0..dims { let v = pop!(); popped.push(v); }
                    let v = StackValue { ty: JvmType::Array(Box::new(JvmType::Reference(None))), source: ValueSource::NewArray(JvmType::Reference(None)) };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }

            Arraylength => {
                let arr = pop!(); popped.push(arr);
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::ArrayLength, inputs: vec![] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            // ── 타입 검사 ─────────────────────────────────────────────────
            Checkcast => {
                let obj = pop!(); popped.push(obj);
                if let InstructionOperand::ConstantPoolIndex(idx) = instr.operands {
                    let class_name = self.resolve_class(idx)?;
                    let v = StackValue { ty: JvmType::Reference(Some(class_name)), source: ValueSource::Unknown };
                    pushed_values.push(v.clone()); stack.push(v);
                }
            }
            Instanceof => {
                let obj = pop!(); popped.push(obj);
                let v = StackValue { ty: JvmType::Int, source: ValueSource::Computation(Box::new(Computation { op: ComputationOp::Instanceof, inputs: vec![] })) };
                pushed_values.push(v.clone()); stack.push(v);
            }

            Monitorenter | Monitorexit => {
                let v = pop!(); popped.push(v);
            }

            // ── Wide / 기타 ───────────────────────────────────────────────
            Wide => {}
            Jsr | JsrW => {
                let v = StackValue { ty: JvmType::ReturnAddress, source: ValueSource::Unknown };
                pushed_values.push(v.clone()); stack.push(v);
            }
            Ret => {}

            Tableswitch | Lookupswitch => {
                let v = pop!(); popped.push(v);
            }

            Breakpoint | LdcDynamic => {}
        }

        Ok((popped, pushed_values))
    }

    // ── 헬퍼들 ────────────────────────────────────────────────────────────

    fn local_index(&self, opcode: &Opcode, operands: &InstructionOperand, _range: std::ops::RangeInclusive<u16>) -> u16 {
        match operands {
            InstructionOperand::LocalVarIndex(i) | InstructionOperand::WideLocalVarIndex(i) => *i,
            _ => match opcode {
                Opcode::Iload0 | Opcode::Lload0 | Opcode::Fload0 | Opcode::Dload0 | Opcode::Aload0
                | Opcode::Istore0 | Opcode::Lstore0 | Opcode::Fstore0 | Opcode::Dstore0 | Opcode::Astore0 => 0,
                Opcode::Iload1 | Opcode::Lload1 | Opcode::Fload1 | Opcode::Dload1 | Opcode::Aload1
                | Opcode::Istore1 | Opcode::Lstore1 | Opcode::Fstore1 | Opcode::Dstore1 | Opcode::Astore1 => 1,
                Opcode::Iload2 | Opcode::Lload2 | Opcode::Fload2 | Opcode::Dload2 | Opcode::Aload2
                | Opcode::Istore2 | Opcode::Lstore2 | Opcode::Fstore2 | Opcode::Dstore2 | Opcode::Astore2 => 2,
                _ => 3,
            }
        }
    }

    fn ldc_value(&self, operands: &InstructionOperand) -> Result<StackValue> {
        if let InstructionOperand::ConstantPoolIndex(idx) = operands {
            match self.cp.get(*idx) {
                Ok(ConstantPoolEntry::Integer(n)) => Ok(StackValue { ty: JvmType::Int, source: ValueSource::Constant(ConstantValue::Int(*n)) }),
                Ok(ConstantPoolEntry::Float(f)) => Ok(StackValue { ty: JvmType::Float, source: ValueSource::Constant(ConstantValue::Float(*f)) }),
                Ok(ConstantPoolEntry::Long(n)) => Ok(StackValue { ty: JvmType::Long, source: ValueSource::Constant(ConstantValue::Long(*n)) }),
                Ok(ConstantPoolEntry::Double(d)) => Ok(StackValue { ty: JvmType::Double, source: ValueSource::Constant(ConstantValue::Double(*d)) }),
                Ok(ConstantPoolEntry::String(str_idx)) => {
                    let s = self.cp.get_utf8(*str_idx).unwrap_or("").to_string();
                    Ok(StackValue { ty: JvmType::Reference(Some("java/lang/String".into())), source: ValueSource::Constant(ConstantValue::String(s)) })
                }
                Ok(ConstantPoolEntry::Class(name_idx)) => {
                    let name = self.cp.get_utf8(*name_idx).unwrap_or("").to_string();
                    Ok(StackValue { ty: JvmType::Reference(Some("java/lang/Class".into())), source: ValueSource::Constant(ConstantValue::Class(name)) })
                }
                _ => Ok(StackValue { ty: JvmType::Reference(None), source: ValueSource::Unknown }),
            }
        } else {
            Ok(StackValue { ty: JvmType::Reference(None), source: ValueSource::Unknown })
        }
    }

    fn resolve_fieldref(&self, idx: u16) -> Result<(String, String, JvmType)> {
        if let Ok(ConstantPoolEntry::Fieldref(class_idx, nat_idx)) = self.cp.get(idx) {
            let class_idx = *class_idx; let nat_idx = *nat_idx;
            let class_name = self.resolve_class(class_idx)?;
            if let Ok(ConstantPoolEntry::NameAndType(name_idx, desc_idx)) = self.cp.get(nat_idx) {
                let name_idx = *name_idx; let desc_idx = *desc_idx;
                let field_name = self.cp.get_utf8(name_idx).unwrap_or("?").to_string();
                let desc = self.cp.get_utf8(desc_idx).unwrap_or("I").to_string();
                let ty = Self::parse_field_type(&desc);
                return Ok((class_name, field_name, ty));
            }
        }
        Ok(("?".into(), "?".into(), JvmType::Int))
    }

    fn resolve_methodref(&self, idx: u16) -> Result<(String, String, String)> {
        let entry = self.cp.get(idx);
        let (class_idx, nat_idx) = match entry {
            Ok(ConstantPoolEntry::Methodref(c, n))
            | Ok(ConstantPoolEntry::InterfaceMethodref(c, n)) => (*c, *n),
            _ => return Ok(("?".into(), "?".into(), "()V".into())),
        };
        let class_name = self.resolve_class(class_idx)?;
        if let Ok(ConstantPoolEntry::NameAndType(name_idx, desc_idx)) = self.cp.get(nat_idx) {
            let name_idx = *name_idx; let desc_idx = *desc_idx;
            let method_name = self.cp.get_utf8(name_idx).unwrap_or("?").to_string();
            let desc = self.cp.get_utf8(desc_idx).unwrap_or("()V").to_string();
            return Ok((class_name, method_name, desc));
        }
        Ok((class_name, "?".into(), "()V".into()))
    }

    fn resolve_class(&self, idx: u16) -> Result<String> {
        if let Ok(ConstantPoolEntry::Class(name_idx)) = self.cp.get(idx) {
            let name_idx = *name_idx;
            Ok(self.cp.get_utf8(name_idx).unwrap_or("?").to_string())
        } else {
            Ok("?".into())
        }
    }

    /// descriptor에서 파라미터 개수 파싱: "(ILjava/lang/String;)V" → 2
    fn count_method_args(desc: &str) -> usize {
        let inner = desc.strip_prefix('(').and_then(|s| s.find(')').map(|i| &s[..i]));
        if let Some(inner) = inner {
            Self::parse_type_list(inner).len()
        } else { 0 }
    }

    fn parse_return_type(desc: &str) -> JvmType {
        if let Some(pos) = desc.find(')') {
            let ret = &desc[pos + 1..];
            Self::parse_field_type(ret)
        } else {
            JvmType::Void
        }
    }

    fn parse_field_type(desc: &str) -> JvmType {
        let mut chars = desc.chars();
        match chars.next() {
            Some('I') => JvmType::Int,
            Some('J') => JvmType::Long,
            Some('F') => JvmType::Float,
            Some('D') => JvmType::Double,
            Some('Z') => JvmType::Boolean,
            Some('B') => JvmType::Byte,
            Some('C') => JvmType::Char,
            Some('S') => JvmType::Short,
            Some('V') => JvmType::Void,
            Some('L') => {
                let name = desc[1..].trim_end_matches(';').to_string();
                JvmType::Reference(Some(name))
            }
            Some('[') => JvmType::Array(Box::new(Self::parse_field_type(&desc[1..]))),
            _ => JvmType::Reference(None),
        }
    }

    fn parse_type_list(params: &str) -> Vec<JvmType> {
        let mut types = Vec::new();
        let mut i = 0;
        let bytes = params.as_bytes();
        while i < bytes.len() {
            match bytes[i] as char {
                'I' => { types.push(JvmType::Int); i += 1; }
                'J' => { types.push(JvmType::Long); i += 1; }
                'F' => { types.push(JvmType::Float); i += 1; }
                'D' => { types.push(JvmType::Double); i += 1; }
                'Z' => { types.push(JvmType::Boolean); i += 1; }
                'B' => { types.push(JvmType::Byte); i += 1; }
                'C' => { types.push(JvmType::Char); i += 1; }
                'S' => { types.push(JvmType::Short); i += 1; }
                'V' => { types.push(JvmType::Void); i += 1; }
                'L' => {
                    if let Some(end) = params[i..].find(';') {
                        types.push(JvmType::Reference(Some(params[i+1..i+end].to_string())));
                        i += end + 1;
                    } else { break; }
                }
                '[' => {
                    // 배열 타입 — 재귀적으로 처리
                    types.push(JvmType::Array(Box::new(JvmType::Reference(None))));
                    i += 1;
                }
                _ => { i += 1; }
            }
        }
        types
    }
}
