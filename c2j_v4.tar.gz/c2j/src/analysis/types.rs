//! JVM Descriptor 파싱 및 타입 분석

use crate::analysis::stack::JvmType;

/// JVM Method descriptor 파싱
/// "(ILjava/lang/String;[B)Z" → (params, return_type)
pub fn parse_method_descriptor(desc: &str) -> (Vec<JvmType>, JvmType) {
    let inner = desc.trim_start_matches('(');
    let close = inner.find(')').unwrap_or(inner.len());
    let params_str = &inner[..close];
    let ret_str = &inner[close + 1..];

    let params = parse_type_sequence(params_str);
    let ret = parse_single_type(ret_str).unwrap_or(JvmType::Void);
    (params, ret)
}

/// 타입 시퀀스 파싱
pub fn parse_type_sequence(s: &str) -> Vec<JvmType> {
    let mut types = Vec::new();
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        let (ty, consumed) = parse_type_at(s, i);
        if consumed == 0 { break; }
        types.push(ty);
        i += consumed;
    }
    types
}

/// 단일 타입 파싱 (인덱스 i에서 시작)
pub fn parse_type_at(s: &str, i: usize) -> (JvmType, usize) {
    let bytes = s.as_bytes();
    if i >= bytes.len() { return (JvmType::Void, 0); }

    match bytes[i] as char {
        'I' => (JvmType::Int, 1),
        'J' => (JvmType::Long, 1),
        'F' => (JvmType::Float, 1),
        'D' => (JvmType::Double, 1),
        'Z' => (JvmType::Boolean, 1),
        'B' => (JvmType::Byte, 1),
        'C' => (JvmType::Char, 1),
        'S' => (JvmType::Short, 1),
        'V' => (JvmType::Void, 1),
        'L' => {
            if let Some(end) = s[i..].find(';') {
                let class_name = s[i + 1..i + end].to_string();
                (JvmType::Reference(Some(class_name)), end + 1)
            } else {
                (JvmType::Reference(None), 1)
            }
        }
        '[' => {
            let (inner, consumed) = parse_type_at(s, i + 1);
            (JvmType::Array(Box::new(inner)), consumed + 1)
        }
        _ => (JvmType::Reference(None), 1),
    }
}

pub fn parse_single_type(s: &str) -> Option<JvmType> {
    let (ty, _) = parse_type_at(s, 0);
    Some(ty)
}

/// 내부 클래스명 → Java 소스명
/// "java/lang/String" → "String"
/// "java/util/List"   → "List"
pub fn simple_class_name(internal: &str) -> &str {
    internal.rsplit('/').next().unwrap_or(internal)
        .split('$').next().unwrap_or(internal)   // 익명 클래스 처리
}

/// 내부 클래스명 → 패키지명
pub fn package_name(internal: &str) -> Option<String> {
    let slash_pos = internal.rfind('/')?;
    Some(internal[..slash_pos].replace('/', "."))
}

/// JvmType → 가독성 있는 Java 타입명
pub fn jvm_type_to_java(ty: &JvmType, use_simple_names: bool) -> String {
    match ty {
        JvmType::Int => "int".into(),
        JvmType::Long => "long".into(),
        JvmType::Float => "float".into(),
        JvmType::Double => "double".into(),
        JvmType::Boolean => "boolean".into(),
        JvmType::Byte => "byte".into(),
        JvmType::Char => "char".into(),
        JvmType::Short => "short".into(),
        JvmType::Void => "void".into(),
        JvmType::Null => "null".into(),
        JvmType::ReturnAddress => "/*returnAddress*/int".into(),
        JvmType::Top => "Object".into(),
        JvmType::Reference(None) => "Object".into(),
        JvmType::Reference(Some(name)) => {
            if use_simple_names {
                simple_class_name(name).to_string()
            } else {
                name.replace('/', ".")
            }
        }
        JvmType::Array(inner) => format!("{}[]", jvm_type_to_java(inner, use_simple_names)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_method_descriptor() {
        let (params, ret) = parse_method_descriptor("(ILjava/lang/String;)Z");
        assert_eq!(params.len(), 2);
        assert_eq!(params[0], JvmType::Int);
        assert!(matches!(&params[1], JvmType::Reference(Some(s)) if s == "java/lang/String"));
        assert_eq!(ret, JvmType::Boolean);
    }

    #[test]
    fn test_parse_array_descriptor() {
        let (params, _) = parse_method_descriptor("([I[Ljava/lang/String;)V");
        assert_eq!(params.len(), 2);
        assert!(matches!(&params[0], JvmType::Array(_)));
    }

    #[test]
    fn test_simple_class_name() {
        assert_eq!(simple_class_name("java/lang/String"), "String");
        assert_eq!(simple_class_name("com/example/Foo$Bar"), "Foo");
    }
}
