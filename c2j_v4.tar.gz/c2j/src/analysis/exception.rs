//! Exception Handler 분석
//!
//! try/catch/finally 블록을 bytecode의 exception table에서 복원합니다.

use std::collections::HashMap;
use crate::classfile::structures::ExceptionHandler;
use crate::analysis::cfg::ControlFlowGraph;

/// 논리적인 try/catch/finally 구조
#[derive(Debug, Clone)]
pub struct TryCatchBlock {
    pub try_start_pc: u32,
    pub try_end_pc: u32,
    pub handlers: Vec<CatchHandler>,
    pub finally_pc: Option<u32>,
}

#[derive(Debug, Clone)]
pub struct CatchHandler {
    pub handler_pc: u32,
    pub catch_type: Option<String>,  // None = finally
}

pub struct ExceptionAnalyzer;

impl ExceptionAnalyzer {
    /// exception table → 논리적 try/catch 구조
    pub fn analyze(
        handlers: &[ExceptionHandler],
        cfg: &ControlFlowGraph,
        cp: &crate::constantpool::ConstantPool,
    ) -> Vec<TryCatchBlock> {
        // try 범위별로 핸들러 그룹화
        let mut groups: HashMap<(u32, u32), Vec<CatchHandler>> = HashMap::new();

        for eh in handlers {
            let key = (eh.start_pc as u32, eh.end_pc as u32);
            let catch_type = if eh.catch_type == 0 {
                None // finally
            } else {
                cp.get(eh.catch_type)
                    .ok()
                    .and_then(|e| {
                        if let crate::constantpool::ConstantPoolEntry::Class(name_idx) = e {
                            cp.get_utf8(*name_idx).ok().map(|s| s.replace('/', "."))
                        } else { None }
                    })
            };

            groups.entry(key).or_default().push(CatchHandler {
                handler_pc: eh.handler_pc as u32,
                catch_type,
            });
        }

        let mut blocks: Vec<TryCatchBlock> = groups.into_iter().map(|((start, end), handlers)| {
            let finally_pc = handlers.iter()
                .find(|h| h.catch_type.is_none())
                .map(|h| h.handler_pc);
            let catch_handlers: Vec<CatchHandler> = handlers.into_iter()
                .filter(|h| h.catch_type.is_some())
                .collect();

            TryCatchBlock {
                try_start_pc: start,
                try_end_pc: end,
                handlers: catch_handlers,
                finally_pc,
            }
        }).collect();

        // 범위 기준으로 정렬 (중첩된 try 처리를 위해)
        blocks.sort_by_key(|b| (b.try_start_pc, u32::MAX - b.try_end_pc));
        blocks
    }
}
