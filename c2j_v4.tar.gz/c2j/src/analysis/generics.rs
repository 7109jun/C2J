//! Generic Signature 파싱 및 Java 소스 복원
//!
//! JVM Signature attribute는 제네릭 타입 정보를 담고 있습니다.
//! 예: "(Ljava/util/List<Ljava/lang/String;>;)V"
//!   → "(List<String>) -> void"
//!
//! 지원:
//!   - TypeVariable: T, E, K, V 등
//!   - Parameterized type: List<String>, Map<K, V>
//!   - Wildcard: ?, ? extends Foo, ? super Bar
//!   - Array: T[], List<String>[]
//!   - Intersection: T extends Comparable & Serializable
//!   - Class signature: <T extends Foo> class Bar<T>
//!   - Method signature: <T> T method(List<T> arg)

/// 제네릭 타입 표현
#[derive(Debug, Clone, PartialEq)]
pub enum GenericType {
    /// 기본 타입 (int, void 등)
    Primitive(char),
    /// 클래스 참조 (제네릭 없음)
    Class(String),
    /// 제네릭 클래스: List<String>
    Parameterized(String, Vec<TypeArg>),
    /// 타입 변수: T, E, K, V
    TypeVar(String),
    /// 배열: T[] or List<String>[]
    Array(Box<GenericType>),
    /// 와일드카드: ?
    Wildcard,
    /// 상한 와일드카드: ? extends Foo
    WildcardUpper(Box<GenericType>),
    /// 하한 와일드카드: ? super Bar
    WildcardLower(Box<GenericType>),
    /// void
    Void,
}

/// 타입 인수
#[derive(Debug, Clone, PartialEq)]
pub enum TypeArg {
    Type(GenericType),
    Wildcard,
    Upper(GenericType),  // ? extends T
    Lower(GenericType),  // ? super T
}

/// 클래스 Signature 파싱 결과
#[derive(Debug, Clone)]
pub struct ClassSignature {
    /// 타입 파라미터: <T extends Comparable, E>
    pub type_params: Vec<TypeParam>,
    /// super class
    pub super_class: GenericType,
    /// interfaces
    pub interfaces: Vec<GenericType>,
}

/// 메서드 Signature 파싱 결과
#[derive(Debug, Clone)]
pub struct MethodSignature {
    pub type_params: Vec<TypeParam>,
    pub params: Vec<GenericType>,
    pub return_type: GenericType,
    pub throws: Vec<GenericType>,
}

/// 타입 파라미터 정의
#[derive(Debug, Clone)]
pub struct TypeParam {
    pub name: String,
    pub class_bound: Option<GenericType>,
    pub interface_bounds: Vec<GenericType>,
}

// ─── 파서 ─────────────────────────────────────────────────────────────────

pub struct SignatureParser<'a> {
    input: &'a [u8],
    pos: usize,
}

impl<'a> SignatureParser<'a> {
    pub fn new(sig: &'a str) -> Self {
        SignatureParser { input: sig.as_bytes(), pos: 0 }
    }

    fn peek(&self) -> Option<char> {
        self.input.get(self.pos).map(|&b| b as char)
    }

    fn next(&mut self) -> Option<char> {
        let c = self.input.get(self.pos).map(|&b| b as char);
        if c.is_some() { self.pos += 1; }
        c
    }

    fn expect(&mut self, c: char) {
        if self.peek() == Some(c) { self.pos += 1; }
    }

    fn consume_until(&mut self, stop: char) -> String {
        let mut s = String::new();
        while let Some(c) = self.peek() {
            if c == stop { break; }
            s.push(c);
            self.pos += 1;
        }
        s
    }

    // ─── 공개 진입점 ────────────────────────────────────────────────────

    /// 클래스 Signature 파싱
    pub fn parse_class_signature(sig: &str) -> Option<ClassSignature> {
        let mut p = Self::new(sig);
        let type_params = if p.peek() == Some('<') { p.parse_type_params() } else { vec![] };
        let super_class = p.parse_class_type()?;
        let mut interfaces = vec![];
        while p.pos < p.input.len() {
            if let Some(iface) = p.parse_class_type() {
                interfaces.push(iface);
            } else { break; }
        }
        Some(ClassSignature { type_params, super_class, interfaces })
    }

    /// 메서드 Signature 파싱
    pub fn parse_method_signature(sig: &str) -> Option<MethodSignature> {
        let mut p = Self::new(sig);
        let type_params = if p.peek() == Some('<') { p.parse_type_params() } else { vec![] };
        p.expect('(');
        let mut params = vec![];
        while p.peek() != Some(')') && p.pos < p.input.len() {
            if let Some(ty) = p.parse_type() { params.push(ty); } else { break; }
        }
        p.expect(')');
        let return_type = p.parse_type().unwrap_or(GenericType::Void);
        let mut throws = vec![];
        while p.peek() == Some('^') {
            p.next();
            if let Some(ty) = p.parse_class_type() { throws.push(ty); }
        }
        Some(MethodSignature { type_params, params, return_type, throws })
    }

    /// 단일 필드 Signature 파싱
    pub fn parse_field_signature(sig: &str) -> Option<GenericType> {
        Self::new(sig).parse_type()
    }

    // ─── 내부 파서 ───────────────────────────────────────────────────────

    fn parse_type_params(&mut self) -> Vec<TypeParam> {
        self.expect('<');
        let mut params = vec![];
        while self.peek() != Some('>') && self.pos < self.input.len() {
            let name = self.consume_until(':');
            self.expect(':');

            // class bound (optional — 추가 ':' 이전에 ':'만 있을 수 있음)
            let class_bound = if self.peek() != Some(':') && self.peek() != Some('>') {
                self.parse_type()
            } else { None };

            let mut interface_bounds = vec![];
            while self.peek() == Some(':') {
                self.expect(':');
                if let Some(ty) = self.parse_type() { interface_bounds.push(ty); }
            }
            params.push(TypeParam { name, class_bound, interface_bounds });
        }
        self.expect('>');
        params
    }

    fn parse_type(&mut self) -> Option<GenericType> {
        match self.peek()? {
            'B' => { self.next(); Some(GenericType::Primitive('B')) }
            'C' => { self.next(); Some(GenericType::Primitive('C')) }
            'D' => { self.next(); Some(GenericType::Primitive('D')) }
            'F' => { self.next(); Some(GenericType::Primitive('F')) }
            'I' => { self.next(); Some(GenericType::Primitive('I')) }
            'J' => { self.next(); Some(GenericType::Primitive('J')) }
            'S' => { self.next(); Some(GenericType::Primitive('S')) }
            'Z' => { self.next(); Some(GenericType::Primitive('Z')) }
            'V' => { self.next(); Some(GenericType::Void) }
            'L' => self.parse_class_type(),
            'T' => {
                self.next();
                let name = self.consume_until(';');
                self.expect(';');
                Some(GenericType::TypeVar(name))
            }
            '[' => {
                self.next();
                let inner = self.parse_type()?;
                Some(GenericType::Array(Box::new(inner)))
            }
            _ => None,
        }
    }

    fn parse_class_type(&mut self) -> Option<GenericType> {
        if self.peek() != Some('L') { return None; }
        self.next();

        // 클래스 이름 (슬래시 포함): java/util/List
        let mut class_name = String::new();
        while let Some(c) = self.peek() {
            match c {
                '<' | ';' | '.' => break,
                c => { class_name.push(c); self.next(); }
            }
        }

        // 타입 인수
        let type_args = if self.peek() == Some('<') {
            self.next(); // '<'
            let mut args = vec![];
            while self.peek() != Some('>') && self.pos < self.input.len() {
                if let Some(arg) = self.parse_type_arg() { args.push(arg); }
                else { break; }
            }
            self.expect('>');
            args
        } else { vec![] };

        // inner class
        while self.peek() == Some('.') {
            self.next();
            let inner = self.consume_until(';');
            class_name.push('$');
            class_name.push_str(&inner);
        }

        self.expect(';');

        if type_args.is_empty() {
            Some(GenericType::Class(class_name))
        } else {
            Some(GenericType::Parameterized(class_name, type_args))
        }
    }

    fn parse_type_arg(&mut self) -> Option<TypeArg> {
        match self.peek()? {
            '*' => { self.next(); Some(TypeArg::Wildcard) }
            '+' => {
                self.next();
                let ty = self.parse_type()?;
                Some(TypeArg::Upper(ty))
            }
            '-' => {
                self.next();
                let ty = self.parse_type()?;
                Some(TypeArg::Lower(ty))
            }
            _ => {
                let ty = self.parse_type()?;
                Some(TypeArg::Type(ty))
            }
        }
    }
}

// ─── Java 소스 변환 ─────────────────────────────────────────────────────────

/// GenericType → Java 소스 문자열 (simple name 사용)
pub fn generic_type_to_java(ty: &GenericType) -> String {
    match ty {
        GenericType::Primitive('B') => "byte".into(),
        GenericType::Primitive('C') => "char".into(),
        GenericType::Primitive('D') => "double".into(),
        GenericType::Primitive('F') => "float".into(),
        GenericType::Primitive('I') => "int".into(),
        GenericType::Primitive('J') => "long".into(),
        GenericType::Primitive('S') => "short".into(),
        GenericType::Primitive('Z') => "boolean".into(),
        GenericType::Primitive(_)   => "?".into(),
        GenericType::Void           => "void".into(),
        GenericType::Wildcard       => "?".into(),
        GenericType::WildcardUpper(b) => format!("? extends {}", generic_type_to_java(b)),
        GenericType::WildcardLower(b) => format!("? super {}", generic_type_to_java(b)),
        GenericType::TypeVar(name)    => name.clone(),
        GenericType::Class(name) => simple_name(name),
        GenericType::Parameterized(name, args) => {
            let args_s = args.iter().map(type_arg_to_java).collect::<Vec<_>>().join(", ");
            format!("{}<{}>", simple_name(name), args_s)
        }
        GenericType::Array(inner) => format!("{}[]", generic_type_to_java(inner)),
    }
}

fn type_arg_to_java(arg: &TypeArg) -> String {
    match arg {
        TypeArg::Wildcard     => "?".into(),
        TypeArg::Type(t)      => generic_type_to_java(t),
        TypeArg::Upper(t)     => format!("? extends {}", generic_type_to_java(t)),
        TypeArg::Lower(t)     => format!("? super {}", generic_type_to_java(t)),
    }
}

fn simple_name(internal: &str) -> String {
    internal.rsplit('/').next().unwrap_or(internal)
        .split('$').next().unwrap_or(internal)
        .to_string()
}

/// 타입 파라미터 선언 → Java 소스: "<T extends Comparable & Serializable>"
pub fn type_params_to_java(params: &[TypeParam]) -> String {
    if params.is_empty() { return String::new(); }
    let parts: Vec<String> = params.iter().map(|p| {
        let mut s = p.name.clone();
        if let Some(cb) = &p.class_bound {
            s.push_str(&format!(" extends {}", generic_type_to_java(cb)));
        }
        for ib in &p.interface_bounds {
            s.push_str(&format!(" & {}", generic_type_to_java(ib)));
        }
        s
    }).collect();
    format!("<{}>", parts.join(", "))
}

/// ClassSignature → 클래스 선언의 제네릭 부분
pub fn class_sig_to_java(sig: &ClassSignature) -> (String, String, Vec<String>) {
    let type_params = type_params_to_java(&sig.type_params);
    let super_cls   = generic_type_to_java(&sig.super_class);
    let interfaces  = sig.interfaces.iter().map(generic_type_to_java).collect();
    (type_params, super_cls, interfaces)
}

/// MethodSignature → 메서드 제네릭 부분
pub fn method_sig_to_java(sig: &MethodSignature) -> (String, Vec<String>, String) {
    let type_params = type_params_to_java(&sig.type_params);
    let params      = sig.params.iter().map(generic_type_to_java).collect();
    let ret         = generic_type_to_java(&sig.return_type);
    (type_params, params, ret)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simple_class() {
        let ty = SignatureParser::parse_field_signature("Ljava/lang/String;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "String");
    }

    #[test]
    fn test_parameterized() {
        let ty = SignatureParser::parse_field_signature("Ljava/util/List<Ljava/lang/String;>;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "List<String>");
    }

    #[test]
    fn test_wildcard_upper() {
        let ty = SignatureParser::parse_field_signature("Ljava/util/List<+Ljava/lang/Number;>;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "List<? extends Number>");
    }

    #[test]
    fn test_wildcard_lower() {
        let ty = SignatureParser::parse_field_signature("Ljava/util/List<-Ljava/lang/Integer;>;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "List<? super Integer>");
    }

    #[test]
    fn test_wildcard_unbounded() {
        let ty = SignatureParser::parse_field_signature("Ljava/util/List<*>;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "List<?>");
    }

    #[test]
    fn test_type_variable() {
        let ty = SignatureParser::parse_field_signature("TT;").unwrap();
        assert_eq!(generic_type_to_java(&ty), "T");
    }

    #[test]
    fn test_array() {
        let ty = SignatureParser::parse_field_signature("[I").unwrap();
        assert_eq!(generic_type_to_java(&ty), "int[]");
    }

    #[test]
    fn test_nested_generics() {
        let ty = SignatureParser::parse_field_signature(
            "Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;>;"
        ).unwrap();
        assert_eq!(generic_type_to_java(&ty), "Map<String, List<Integer>>");
    }

    #[test]
    fn test_method_signature() {
        let sig = SignatureParser::parse_method_signature(
            "<T:Ljava/lang/Comparable;>(TT;TT;)I"
        ).unwrap();
        assert_eq!(sig.type_params.len(), 1);
        assert_eq!(sig.type_params[0].name, "T");
        assert_eq!(sig.params.len(), 2);
        assert_eq!(generic_type_to_java(&sig.return_type), "int");
    }

    #[test]
    fn test_class_signature() {
        let sig = SignatureParser::parse_class_signature(
            "<T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;"
        ).unwrap();
        assert_eq!(sig.type_params.len(), 1);
        assert_eq!(sig.interfaces.len(), 1);
    }

    #[test]
    fn test_type_params_to_java() {
        let params = vec![
            TypeParam {
                name: "T".into(),
                class_bound: Some(GenericType::Class("java/lang/Comparable".into())),
                interface_bounds: vec![GenericType::Class("java/io/Serializable".into())],
            }
        ];
        let result = type_params_to_java(&params);
        assert_eq!(result, "<T extends Comparable & Serializable>");
    }
}
