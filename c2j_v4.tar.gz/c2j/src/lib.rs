//! C2J — Class To Java Decompiler
//!
//! JVM .class / .jar 파일을 재컴파일 가능한 .java 소스 코드로 변환합니다.
//! Java 8~22 지원, 동작 의미 완전 보존 최우선.
//!
//! # 빠른 시작
//! ```rust,ignore
//! // 단일 클래스 파일
//! let java = c2j::decompile(&class_bytes)?;
//!
//! // JAR 파일
//! let jar = c2j::decompile_jar(&jar_bytes)?;
//! for (name, src) in &jar { println!("{}: {} chars", name, src.len()); }
//! ```

pub mod utils;
pub mod classfile;
pub mod constantpool;
pub mod bytecode;
pub mod analysis;
pub mod ir;
pub mod ast;
pub mod generator;
pub mod verifier;
pub mod cli;
pub mod plugins;

pub use classfile::{ClassFile, ClassFileParser, ClassFileValidator};
pub use generator::JavaGenerator;
pub use utils::error::{C2JError, Result};
pub use utils::diagnostics::{DiagnosticCollector, error_to_diagnostic};

pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// 가장 간단한 API: .class 바이트 → .java 소스
///
/// ```rust,ignore
/// let bytes = std::fs::read("Example.class")?;
/// let java  = c2j::decompile(&bytes)?;
/// std::fs::write("Example.java", &java)?;
/// ```
pub fn decompile(class_bytes: &[u8]) -> Result<String> {
    let class_file = ClassFileParser::parse(class_bytes)?;
    ClassFileValidator::validate(&class_file)?;
    JavaGenerator::generate(&class_file)
}

/// JAR 파일 → (클래스 내부 경로, .java 소스) 목록
///
/// ```rust,ignore
/// let jar_bytes = std::fs::read("MyApp.jar")?;
/// let results = c2j::decompile_jar(&jar_bytes)?;
/// for (path, src) in &results {
///     println!("// {}", path);
///     println!("{}", src);
/// }
/// ```
pub fn decompile_jar(jar_bytes: &[u8]) -> Result<Vec<(String, String)>> {
    let jar = classfile::read_jar(jar_bytes)?;
    let mut out = Vec::new();

    for (internal_path, class_bytes) in &jar.classes {
        match decompile(class_bytes) {
            Ok(src) => {
                let java_path = internal_path
                    .trim_end_matches(".class")
                    .to_string() + ".java";
                out.push((java_path, src));
            }
            Err(e) => {
                // 실패한 클래스는 주석으로 대체
                let java_path = internal_path
                    .trim_end_matches(".class")
                    .to_string() + ".java";
                out.push((java_path, format!(
                    "// C2J: 디컴파일 실패 — {}\n// 원본: {}\n",
                    e, internal_path
                )));
            }
        }
    }

    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}

/// 진단 포함 디컴파일 (부분 실패 허용)
pub fn decompile_with_diagnostics(
    class_bytes: &[u8],
) -> (std::result::Result<String, C2JError>, DiagnosticCollector) {
    let mut diag = DiagnosticCollector::new();

    let result = (|| -> Result<String> {
        let class_file = ClassFileParser::parse(class_bytes)
            .map_err(|e| { diag.add(error_to_diagnostic(&e)); e })?;

        ClassFileValidator::validate(&class_file)
            .map_err(|e| { diag.add(error_to_diagnostic(&e)); e })?;

        JavaGenerator::generate(&class_file)
            .map_err(|e| { diag.add(error_to_diagnostic(&e)); e })
    })();

    (result, diag)
}
