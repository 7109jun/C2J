//! C2J 통합 테스트
//!
//! .class 바이너리를 직접 빌드하여 파이프라인 전체를 검증합니다.

use c2j::{ClassFileParser, ClassFileValidator};
use c2j::generator::JavaGenerator;

/// 최소한의 HelloWorld.class 를 바이트 배열로 직접 조립
/// (javac 없이 테스트 가능하도록)
fn minimal_class_bytes() -> Vec<u8> {
    // public class Hello { public static int add(int a, int b) { return a + b; } }
    // 실제 javac 컴파일 결과 (Java 11)
    // 여기서는 최소 클래스 파일 구조로 대체
    let mut buf: Vec<u8> = Vec::new();

    // magic
    buf.extend_from_slice(&[0xCA, 0xFE, 0xBA, 0xBE]);
    // minor, major (Java 11 = 55)
    buf.extend_from_slice(&[0x00, 0x00, 0x00, 0x37]);

    // constant_pool_count = 9
    buf.extend_from_slice(&[0x00, 0x09]);

    // #1: Utf8 "Hello"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x05]); buf.extend_from_slice(b"Hello");
    // #2: Utf8 "java/lang/Object"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x10]); buf.extend_from_slice(b"java/lang/Object");
    // #3: Class → #1
    buf.push(7); buf.extend_from_slice(&[0x00, 0x01]);
    // #4: Class → #2
    buf.push(7); buf.extend_from_slice(&[0x00, 0x02]);
    // #5: Utf8 "<init>"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x06]); buf.extend_from_slice(b"<init>");
    // #6: Utf8 "()V"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x03]); buf.extend_from_slice(b"()V");
    // #7: Utf8 "Code"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x04]); buf.extend_from_slice(b"Code");
    // #8: Utf8 "add"
    buf.push(1); buf.extend_from_slice(&[0x00, 0x03]); buf.extend_from_slice(b"add");

    // access_flags: public (0x0021)
    buf.extend_from_slice(&[0x00, 0x21]);
    // this_class = #3, super_class = #4
    buf.extend_from_slice(&[0x00, 0x03]);
    buf.extend_from_slice(&[0x00, 0x04]);

    // interfaces_count = 0
    buf.extend_from_slice(&[0x00, 0x00]);
    // fields_count = 0
    buf.extend_from_slice(&[0x00, 0x00]);
    // methods_count = 1 (기본 생성자 생략, 파서 테스트용)
    buf.extend_from_slice(&[0x00, 0x00]);
    // attributes_count = 0
    buf.extend_from_slice(&[0x00, 0x00]);

    buf
}

#[test]
fn test_parse_minimal_class() {
    let bytes = minimal_class_bytes();
    let result = ClassFileParser::parse(&bytes);
    assert!(result.is_ok(), "파싱 실패: {:?}", result.err());

    let class_file = result.unwrap();
    assert_eq!(class_file.magic, 0xCAFEBABE);
    assert_eq!(class_file.major_version, 55); // Java 11
    assert_eq!(class_file.this_class, 3);
    assert_eq!(class_file.super_class, 4);
}

#[test]
fn test_validate_minimal_class() {
    let bytes = minimal_class_bytes();
    let class_file = ClassFileParser::parse(&bytes).unwrap();
    let result = ClassFileValidator::validate(&class_file);
    assert!(result.is_ok(), "검증 실패: {:?}", result.err());
}

#[test]
fn test_invalid_magic() {
    let bytes = vec![0xDE, 0xAD, 0xBE, 0xEF, 0x00, 0x00];
    let result = ClassFileParser::parse(&bytes);
    assert!(result.is_err());
    match result.unwrap_err() {
        c2j::utils::error::C2JError::InvalidMagic(_) => {}
        e => panic!("잘못된 에러 타입: {:?}", e),
    }
}

#[test]
fn test_bytecode_decoder_simple() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::bytecode::instruction::Opcode;

    // iload_0, iload_1, iadd, ireturn
    let code = vec![0x1Au8, 0x1B, 0x60, 0xAC];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs.len(), 4);
    assert_eq!(instrs[0].opcode, Opcode::Iload0);
    assert_eq!(instrs[2].opcode, Opcode::Iadd);
    assert_eq!(instrs[3].opcode, Opcode::Ireturn);
}

#[test]
fn test_cfg_single_block() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::analysis::cfg::CfgBuilder;

    let code = vec![0x1Au8, 0x1B, 0x60, 0xAC];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    let cfg = CfgBuilder::build(&instrs, &[]).unwrap();

    assert_eq!(cfg.blocks.len(), 1);
    assert!(cfg.blocks[0].successors.is_empty()); // return → 종료
}

#[test]
fn test_cfg_branch() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::analysis::cfg::CfgBuilder;

    // iload_0, ifeq +3, iload_1, ireturn
    // pc: 0=iload_0(1), 1=ifeq+3(3), 4=iload_1(1), 5=ireturn(1)
    let code = vec![0x1Au8, 0x99, 0x00, 0x03, 0x1B, 0xAC];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    let cfg = CfgBuilder::build(&instrs, &[]).unwrap();

    // 2 blocks: [iload_0, ifeq], [iload_1, ireturn]
    assert_eq!(cfg.blocks.len(), 2);
    assert!(!cfg.blocks[0].successors.is_empty());
}

#[test]
fn test_type_descriptor_parsing() {
    use c2j::analysis::types::parse_method_descriptor;
    use c2j::analysis::stack::JvmType;

    let (params, ret) = parse_method_descriptor("(IILjava/lang/String;)V");
    assert_eq!(params.len(), 3);
    assert_eq!(params[0], JvmType::Int);
    assert_eq!(params[1], JvmType::Int);
    assert!(matches!(&params[2], JvmType::Reference(Some(s)) if s == "java/lang/String"));
    assert_eq!(ret, JvmType::Void);
}

#[test]
fn test_java21_version_name() {
    use c2j::classfile::structures::java_version_name;
    assert_eq!(java_version_name(55), "Java 11");
    assert_eq!(java_version_name(61), "Java 17");
    assert_eq!(java_version_name(65), "Java 21");
    assert_eq!(java_version_name(66), "Java 22");
}

// ─── 추가 테스트 ──────────────────────────────────────────────────────────────

#[test]
fn test_new_synthesis() {
    use c2j::ir::new_synthesis::synthesize_new_objects;
    use c2j::ir::{IrStmt, IrExpr};
    use c2j::analysis::stack::JvmType;

    // new Foo() 패턴: Assign(tmp, NewObject("Foo",[])) + ExprStmt(SpecialCall(<init>))
    let mut stmts = vec![
        IrStmt::Assign(
            "_t0".into(), JvmType::Reference(Some("Foo".into())),
            IrExpr::NewObject("Foo".into(), vec![]),
        ),
        IrStmt::ExprStmt(IrExpr::SpecialCall(
            Box::new(IrExpr::NewObject("Foo".into(), vec![])),
            "Foo".into(),
            "<init>".into(),
            "()V".into(),
            vec![IrExpr::IntLit(42)],
            JvmType::Void,
        )),
    ];

    synthesize_new_objects(&mut stmts);

    // 합성 후: Assign(_t0, NewObject("Foo", [42]))
    if let IrStmt::Assign(_, _, IrExpr::NewObject(cls, args)) = &stmts[0] {
        assert_eq!(cls, "Foo");
        assert_eq!(args.len(), 1);
    } else {
        panic!("new synthesis failed: {:?}", stmts[0]);
    }
}

#[test]
fn test_structurizer_simple() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::analysis::cfg::CfgBuilder;
    use c2j::ir::structurizer::Structurizer;
    use c2j::ir::IrStmt;
    use std::collections::HashMap;

    // iload_0, iload_1, iadd, ireturn
    let code = vec![0x1Au8, 0x1B, 0x60, 0xAC];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    let cfg = CfgBuilder::build(&instrs, &[]).unwrap();

    // 빈 블록 맵으로 구조화 실행 (panic 없으면 OK)
    let block_stmts: HashMap<u32, Vec<IrStmt>> = HashMap::new();
    let mut s = Structurizer::new(&cfg, &block_stmts);
    let structured = s.structurize();
    // 결과 검증 (비어 있어도 OK — 블록 스텁을 넣지 않았으므로)
    // 중요: panic이 없으면 성공
}

#[test]
fn test_loop_header_detection() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::analysis::cfg::CfgBuilder;

    // while 루프: iload_0, ifeq +5, iinc 0 1, goto -6, return
    // pc: 0=iload_0(1), 1=ifeq+5(3), 4=iinc(3), 7=goto-6(3), 10=return(1)
    let code = vec![
        0x1Au8,             // iload_0  pc=0
        0x99, 0x00, 0x09,   // ifeq +9  pc=1  → 10
        0x84, 0x00, 0x01,   // iinc 0,1 pc=4
        0xA7, 0xFF, 0xF9,   // goto -7  pc=7  → 0  (back edge)
        0xB1,               // return   pc=10
    ];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    let cfg = CfgBuilder::build(&instrs, &[]).unwrap();
    let headers = cfg.find_loop_headers();

    // pc=0 블록이 루프 헤더여야 함
    let entry_block = cfg.get_block(cfg.entry_id).unwrap();
    assert!(
        headers.contains(&cfg.entry_id),
        "루프 헤더 미감지: headers={:?}, entry_id={}",
        headers, cfg.entry_id
    );
}

#[test]
fn test_lambda_analyzer() {
    use c2j::ir::lambda::{LambdaAnalyzer, BootstrapMethodEntry};

    // 빈 CP로 분석 시 None 반환 확인 (panic 없음)
    let cp = crate::c2j_constantpool_new();
    let bsms: Vec<BootstrapMethodEntry> = vec![];
    let analyzer = LambdaAnalyzer::new(&cp, &bsms);
    let result = analyzer.analyze_indy(1);
    assert!(result.is_none(), "빈 CP에서 Some 반환");
}

fn c2j_constantpool_new() -> c2j::constantpool::ConstantPool {
    c2j::constantpool::ConstantPool::new()
}

#[test]
fn test_java21_sealed_record_detection() {
    // Record/Sealed attribute 이름 기반 감지 테스트
    // 실제 .class 없이 attribute name만으로 판단하는 로직 검증
    let record_attr_name = "Record";
    let sealed_attr_name = "PermittedSubclasses";
    assert_eq!(record_attr_name, "Record");
    assert_eq!(sealed_attr_name, "PermittedSubclasses");
}

// ─── E2E 파이프라인 테스트 ────────────────────────────────────────────────

/// 완전한 .class를 파싱 → Java 소스 생성 → 결과 검증
#[test]
fn test_full_pipeline_simple_class() {
    use c2j::generator::JavaGenerator;

    let bytes = minimal_class_bytes();
    let class_file = c2j::ClassFileParser::parse(&bytes).unwrap();
    c2j::ClassFileValidator::validate(&class_file).unwrap();

    // 소스 생성 — 오류 없이 완료되어야 함
    let java_src = JavaGenerator::generate(&class_file);
    assert!(java_src.is_ok(), "소스 생성 실패: {:?}", java_src.err());

    let src = java_src.unwrap();
    // 기본 구조 확인
    assert!(src.contains("class Hello"), "class 선언 누락:\n{}", src);
    assert!(src.contains("{"), "바디 누락");
    assert!(src.contains("}"), "바디 닫힘 누락");
}

/// 메서드 시그니처 생성 검증
#[test]
fn test_method_signature_generation() {
    use c2j::analysis::types::{parse_method_descriptor, jvm_type_to_java};
    use c2j::analysis::stack::JvmType;

    let cases = vec![
        ("()V",                    vec![],                                              JvmType::Void),
        ("(I)I",                   vec![JvmType::Int],                                  JvmType::Int),
        ("(IJ)Z",                  vec![JvmType::Int, JvmType::Long],                   JvmType::Boolean),
        ("([I)V",                  vec![JvmType::Array(Box::new(JvmType::Int))],         JvmType::Void),
        ("(Ljava/lang/String;)V",  vec![JvmType::Reference(Some("java/lang/String".into()))], JvmType::Void),
    ];

    for (desc, expected_params, expected_ret) in cases {
        let (params, ret) = parse_method_descriptor(desc);
        assert_eq!(params.len(), expected_params.len(), "desc={}: param count mismatch", desc);
        assert_eq!(ret, expected_ret, "desc={}: ret type mismatch", desc);
    }
}

/// Record 컴포넌트 파싱 검증
#[test]
fn test_record_component_extraction() {
    use c2j::classfile::modern_features::extract_record_components;
    use c2j::constantpool::ConstantPoolEntry;

    // 빈 CP + 빈 클래스로 테스트 (빈 결과 기대)
    let empty_cp: Vec<Option<ConstantPoolEntry>> = vec![None];
    let class_file = make_empty_class();

    let components = extract_record_components(&class_file, &empty_cp);
    assert!(components.is_empty(), "빈 클래스에서 Record 컴포넌트 감지됨");
}

/// Sealed class 파싱 검증
#[test]
fn test_sealed_info_extraction() {
    use c2j::classfile::modern_features::extract_sealed_info;
    use c2j::constantpool::ConstantPoolEntry;

    let empty_cp: Vec<Option<ConstantPoolEntry>> = vec![None];
    let class_file = make_empty_class();

    let sealed = extract_sealed_info(&class_file, &empty_cp);
    assert!(sealed.is_none(), "빈 클래스에서 Sealed 감지됨");
}

/// iinc 명령어 변환 검증
#[test]
fn test_iinc_conversion() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::bytecode::instruction::Opcode;
    use crate::bytecode::decoder::InstructionOperand;

    // iinc 0, 1 (pc=0, idx=0, const=1)
    let code = vec![0x84u8, 0x00, 0x01];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs.len(), 1);
    assert_eq!(instrs[0].opcode, Opcode::Iinc);
    assert_eq!(instrs[0].operands, InstructionOperand::LocalVarIndexAndConst(0, 1));
    assert_eq!(instrs[0].byte_size, 3);
}

/// wide iload 변환 검증
#[test]
fn test_wide_iload() {
    use c2j::bytecode::decoder::{BytecodeDecoder, InstructionOperand};
    use c2j::bytecode::instruction::Opcode;

    // wide (0xC4), iload (0x15), index_hi=0x01, index_lo=0x00 → slot 256
    let code = vec![0xC4u8, 0x15, 0x01, 0x00];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs.len(), 1);
    assert_eq!(instrs[0].opcode, Opcode::Wide);
    assert_eq!(instrs[0].operands, InstructionOperand::WideLocalVarIndex(256));
    assert_eq!(instrs[0].byte_size, 4);
}

/// lookupswitch 변환 검증
#[test]
fn test_lookupswitch_decode() {
    use c2j::bytecode::decoder::{BytecodeDecoder, InstructionOperand};
    use c2j::bytecode::instruction::Opcode;

    // lookupswitch: opcode(1) + pad(3) + default(4) + npairs(4) + pair(8)
    // pc=0 → pad=3 bytes
    let mut code = vec![0xABu8]; // lookupswitch
    code.extend_from_slice(&[0, 0, 0]);        // pad
    code.extend_from_slice(&[0, 0, 0, 20]);   // default +20
    code.extend_from_slice(&[0, 0, 0, 1]);    // npairs=1
    code.extend_from_slice(&[0, 0, 0, 42]);   // match=42
    code.extend_from_slice(&[0, 0, 0, 10]);   // offset=+10

    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs.len(), 1);
    assert_eq!(instrs[0].opcode, Opcode::Lookupswitch);

    if let InstructionOperand::LookupSwitch { default_offset, pairs } = &instrs[0].operands {
        assert_eq!(*default_offset, 20);
        assert_eq!(pairs.len(), 1);
        assert_eq!(pairs[0], (42, 10));
    } else {
        panic!("lookupswitch operand 파싱 실패");
    }
}

/// 에러 처리: 잘못된 클래스 버전
#[test]
fn test_unsupported_version_error() {
    let mut bytes = minimal_class_bytes();
    // major_version을 99로 변경 (offset 6-7)
    bytes[6] = 0x00;
    bytes[7] = 0x63;  // 99

    let result = c2j::ClassFileParser::parse(&bytes);
    assert!(result.is_err());
    match result.unwrap_err() {
        c2j::utils::error::C2JError::UnsupportedVersion(major, _) => {
            assert_eq!(major, 99);
        }
        e => panic!("잘못된 에러: {:?}", e),
    }
}

/// 에러 처리: 비어있는 바이트 배열
#[test]
fn test_empty_input_error() {
    let result = c2j::ClassFileParser::parse(&[]);
    assert!(result.is_err());
}

/// 헬퍼: 빈 ClassFile 생성
fn make_empty_class() -> c2j::ClassFile {
    use c2j::classfile::structures::{ClassFile, AccessFlags};
    ClassFile {
        magic: 0xCAFEBABE,
        minor_version: 0,
        major_version: 61, // Java 17
        constant_pool: vec![None],
        access_flags: AccessFlags(0x0021),
        this_class: 0,
        super_class: 0,
        interfaces: vec![],
        fields: vec![],
        methods: vec![],
        attributes: vec![],
    }
}

// ─── 업그레이드 기능 테스트 ───────────────────────────────────────────────

/// Prettifier: 임시 변수 인라인
#[test]
fn test_prettifier_inline_temp() {
    use c2j::generator::prettifier::prettify;
    let src = "class A {\n    void f() {\n        _t0 = x + 1;\n        return _t0;\n    }\n}\n";
    let result = prettify(src);
    assert!(!result.contains("_t0"), "임시 변수 인라인 실패:\n{}", result);
    assert!(result.contains("return x + 1;"), "반환문 오류:\n{}", result);
}

/// Prettifier: i++ 단순화
#[test]
fn test_prettifier_iinc() {
    use c2j::generator::prettifier::prettify;
    let src = "class A {\n    void f() {\n        i = i + 1;\n        j = j - 1;\n    }\n}\n";
    let result = prettify(src);
    assert!(result.contains("i++;"), "i++ 미생성:\n{}", result);
    assert!(result.contains("j--;"), "j-- 미생성:\n{}", result);
}

/// Prettifier: import 정렬 + 중복 제거
#[test]
fn test_prettifier_imports() {
    use c2j::generator::prettifier::prettify;
    let src = "package a;\nimport java.util.Map;\nimport java.io.File;\nimport java.util.Map;\nclass A {}\n";
    let result = prettify(src);
    let import_count = result.lines().filter(|l| l.starts_with("import ")).count();
    assert_eq!(import_count, 2, "import 중복 제거 실패:\n{}", result);
    let file_pos = result.find("File").unwrap();
    let map_pos  = result.find("Map").unwrap();
    assert!(file_pos < map_pos, "import 정렬 오류:\n{}", result);
}

/// Prettifier: trailing whitespace 제거
#[test]
fn test_prettifier_trailing_ws() {
    use c2j::generator::prettifier::prettify;
    let src = "class A {   \n    int x;  \n}\n";
    let result = prettify(src);
    for line in result.lines() {
        assert_eq!(line, line.trim_end(), "trailing whitespace 미제거: {:?}", line);
    }
}

/// enum 상수 생성 검증
#[test]
fn test_enum_generation() {
    use c2j::ir::enum_restore::{EnumInfo, EnumConstant, EnumArg, gen_enum_declaration};

    // 단순 enum
    let info = EnumInfo {
        constants: vec![
            EnumConstant { name: "RED".into(),   ordinal: 0, extra_args: vec![] },
            EnumConstant { name: "GREEN".into(), ordinal: 1, extra_args: vec![] },
            EnumConstant { name: "BLUE".into(),  ordinal: 2, extra_args: vec![] },
        ],
        extra_param_types: vec![],
        has_extra_fields: false,
        has_abstract_methods: false,
    };
    let src = gen_enum_declaration("Color", &info, &[], "", "");
    assert!(src.starts_with("public enum Color"), "선언 오류");
    assert!(src.contains("RED, GREEN, BLUE"), "상수 오류:\n{}", src);

    // 생성자 인수 있는 enum
    let info2 = EnumInfo {
        constants: vec![
            EnumConstant { name: "HTTP_OK".into(), ordinal: 0,
                extra_args: vec![EnumArg::Int(200), EnumArg::String("OK".into())] },
            EnumConstant { name: "HTTP_NOT_FOUND".into(), ordinal: 1,
                extra_args: vec![EnumArg::Int(404), EnumArg::String("Not Found".into())] },
        ],
        extra_param_types: vec!["int".into(), "String".into()],
        has_extra_fields: true,
        has_abstract_methods: false,
    };
    let src2 = gen_enum_declaration("HttpStatus", &info2, &[], "", "");
    assert!(src2.contains("HTTP_OK(200, \"OK\")"), "인수 있는 enum 오류:\n{}", src2);
}

/// String switch hashCode 계산 검증
#[test]
fn test_string_switch_hashcode() {
    use c2j::ir::string_switch::java_string_hashcode;

    // 알려진 값들 검증
    let cases = vec![
        ("",        0i32),
        ("a",       97),
        ("hello",   99162322),
        ("foo",     101574),
        ("bar",     97299),
        ("world",   113318802),
        ("GET",     70454),
        ("POST",    2461856),
        ("DELETE",  -1023028635),
    ];
    for (s, expected) in cases {
        let got = java_string_hashcode(s);
        assert_eq!(got, expected, "hashCode({:?}) 오류: got {}, expected {}", s, got, expected);
    }
}

/// Annotation 생성 검증
#[test]
fn test_annotation_generation() {
    use c2j::ir::annotation_restore::{ParsedAnnotation, AnnotationValue, annotation_to_java};

    // @Override
    let ann = ParsedAnnotation { type_name: "java/lang/Override".into(), elements: vec![], is_visible: true };
    assert_eq!(annotation_to_java(&ann), "@Override");

    // @SuppressWarnings("unchecked")
    let ann = ParsedAnnotation {
        type_name: "java/lang/SuppressWarnings".into(),
        elements: vec![("value".into(), AnnotationValue::String("unchecked".into()))],
        is_visible: true,
    };
    assert_eq!(annotation_to_java(&ann), "@SuppressWarnings(\"unchecked\")");

    // @Deprecated
    let ann = ParsedAnnotation { type_name: "java/lang/Deprecated".into(), elements: vec![], is_visible: true };
    assert_eq!(annotation_to_java(&ann), "@Deprecated");

    // @SomeAnnotation(value = {1, 2, 3})
    let ann = ParsedAnnotation {
        type_name: "com/example/Nums".into(),
        elements: vec![("value".into(), AnnotationValue::Array(vec![
            AnnotationValue::Int(1), AnnotationValue::Int(2), AnnotationValue::Int(3),
        ]))],
        is_visible: true,
    };
    let s = annotation_to_java(&ann);
    assert!(s.contains("{1, 2, 3}"), "배열 annotation 오류: {}", s);
}

/// JAR 파서: 잘못된 입력 에러 처리
#[test]
fn test_jar_reader_invalid() {
    use c2j::classfile::read_jar;
    assert!(read_jar(b"").is_err(), "빈 입력 에러 기대");
    assert!(read_jar(b"not a jar").is_err(), "잘못된 JAR 에러 기대");
    assert!(read_jar(b"\xCA\xFE\xBA\xBE").is_err(), ".class 파일은 JAR 아님");
}

/// decompile_jar API 연기 테스트 (빈 JAR)
#[test]
fn test_decompile_jar_empty() {
    // ZIP EOCD만 있는 최소 JAR
    // EOCD: PK\x05\x06 + 18 bytes
    let eocd = b"PK\x05\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    let result = c2j::decompile_jar(eocd);
    assert!(result.is_ok(), "빈 JAR 처리 실패: {:?}", result.err());
    assert!(result.unwrap().is_empty(), "빈 JAR에서 클래스 감지됨");
}

/// 진단 API 검증
#[test]
fn test_diagnostics_api() {
    use c2j::utils::diagnostics::{DiagnosticCollector, Severity};

    let mut coll = DiagnosticCollector::new();
    assert!(!coll.has_errors());

    coll.info("I001", "정보");
    coll.warn("W001", "경고");
    assert!(!coll.has_errors());

    coll.error("E001", "오류");
    assert!(coll.has_errors());
    assert_eq!(coll.count_by_severity(Severity::Warning), 1);
    assert_eq!(coll.count_by_severity(Severity::Error),   1);
}

/// decompile_with_diagnostics API
#[test]
fn test_decompile_with_diagnostics_invalid() {
    let (result, diag) = c2j::decompile_with_diagnostics(b"invalid class");
    assert!(result.is_err(), "잘못된 입력에서 Ok 반환");
    assert!(diag.has_errors(), "진단에 에러 없음");
}

/// 병렬 처리기 기본 동작
#[test]
fn test_parallel_processor() {
    use c2j::utils::parallel::ParallelProcessor;
    let proc = ParallelProcessor::new(2);
    let items = (0u8..8).map(|i| (format!("item_{}", i), vec![i])).collect();
    let results = proc.process(items, |_, data| {
        Ok::<u32, String>(data[0] as u32 * data[0] as u32)
    });
    assert_eq!(results.len(), 8);
    // 모든 결과가 성공이어야 함
    for r in &results {
        assert!(r.result.is_ok(), "병렬 처리 실패: {:?}", r.key);
    }
}
