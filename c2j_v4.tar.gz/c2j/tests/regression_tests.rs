//! JDK 클래스 파일 회귀 테스트
//!
//! 실제 JDK의 .class 파일을 파싱하여 파이프라인 안정성을 검증합니다.
//! java.base 모듈에서 대표 클래스들을 대상으로 합니다.

use std::path::{Path, PathBuf};
use std::fs;
use c2j::{ClassFileParser, ClassFileValidator};
use c2j::generator::JavaGenerator;

/// JDK .class 파일 경로 탐색
fn find_jdk_classes() -> Vec<PathBuf> {
    // JDK 설치 경로 후보
    let candidates = vec![
        "/usr/lib/jvm/java-21-openjdk-amd64",
        "/usr/lib/jvm/java-17-openjdk-amd64",
        "/usr/lib/jvm/java-11-openjdk-amd64",
        "/usr/local/lib/jvm/java-21",
        "/usr/lib/jvm/temurin-21",
        "/Library/Java/JavaVirtualMachines/jdk-21.jdk/Contents/Home",
    ];

    for base in &candidates {
        let p = Path::new(base);
        if p.exists() {
            // java.base 모듈에서 클래스 수집
            let mut classes = Vec::new();
            collect_classes(p, &mut classes, 50);
            if !classes.is_empty() {
                eprintln!("[회귀 테스트] JDK 발견: {}", base);
                return classes;
            }
        }
    }

    // jar 방식 (JDK 9+): ct.sym 또는 java.base.jmod
    let jmod_candidates = vec![
        "/usr/lib/jvm/java-21-openjdk-amd64/jmods/java.base.jmod",
        "/usr/lib/jvm/java-17-openjdk-amd64/jmods/java.base.jmod",
    ];
    for jmod in &jmod_candidates {
        if Path::new(jmod).exists() {
            eprintln!("[회귀 테스트] jmod 발견: {} (직접 추출은 생략)", jmod);
        }
    }

    Vec::new()
}

fn collect_classes(dir: &Path, out: &mut Vec<PathBuf>, limit: usize) {
    if out.len() >= limit { return; }
    let rd = match fs::read_dir(dir) { Ok(r) => r, Err(_) => return };
    for entry in rd {
        if out.len() >= limit { break; }
        let entry = match entry { Ok(e) => e, Err(_) => continue };
        let p = entry.path();
        if p.is_dir() {
            collect_classes(&p, out, limit);
        } else if p.extension().and_then(|e| e.to_str()) == Some("class") {
            out.push(p);
        }
    }
}

/// 회귀 테스트: 파싱만 수행 (생성 없이)
#[test]
fn test_jdk_classes_parse() {
    let classes = find_jdk_classes();

    if classes.is_empty() {
        eprintln!("[SKIP] JDK를 찾을 수 없음 — 회귀 테스트 스킵");
        return;
    }

    let mut ok = 0;
    let mut err = 0;
    let mut errors: Vec<String> = Vec::new();

    for path in &classes {
        let bytes = match fs::read(path) {
            Ok(b) => b,
            Err(e) => { errors.push(format!("{:?}: {}", path, e)); err += 1; continue; }
        };

        match ClassFileParser::parse(&bytes) {
            Ok(cf) => {
                match ClassFileValidator::validate(&cf) {
                    Ok(()) => ok += 1,
                    Err(e) => { errors.push(format!("{:?}: validate: {}", path, e)); err += 1; }
                }
            }
            Err(e) => { errors.push(format!("{:?}: parse: {}", path, e)); err += 1; }
        }
    }

    eprintln!("[회귀 테스트 파싱] OK={}, ERR={}/{}", ok, err, classes.len());
    for e in &errors { eprintln!("  ERR: {}", e); }

    // 에러 비율이 10% 미만이어야 함
    let total = classes.len();
    if total > 0 {
        let err_rate = err as f64 / total as f64;
        assert!(
            err_rate < 0.10,
            "파싱 에러율 {:.1}% >= 10% — JDK 회귀 테스트 실패\n에러:\n{}",
            err_rate * 100.0,
            errors.join("\n")
        );
    }
}

/// 회귀 테스트: 파싱 + Java 소스 생성
#[test]
fn test_jdk_classes_generate() {
    let classes = find_jdk_classes();

    if classes.is_empty() {
        eprintln!("[SKIP] JDK를 찾을 수 없음 — 생성 테스트 스킵");
        return;
    }

    // 처음 20개만 생성 테스트
    let subset: Vec<&PathBuf> = classes.iter().take(20).collect();
    let mut ok = 0;
    let mut err = 0;
    let mut errors: Vec<String> = Vec::new();

    for path in &subset {
        let bytes = match fs::read(path) { Ok(b) => b, Err(_) => continue };
        let cf = match ClassFileParser::parse(&bytes) { Ok(cf) => cf, Err(_) => continue };

        match JavaGenerator::generate(&cf) {
            Ok(src) => {
                // 기본 구조 검증
                if src.contains("class ") || src.contains("interface ") || src.contains("enum ") {
                    ok += 1;
                } else {
                    errors.push(format!("{:?}: 클래스 선언 없음", path));
                    err += 1;
                }
            }
            Err(e) => { errors.push(format!("{:?}: gen: {}", path, e)); err += 1; }
        }
    }

    eprintln!("[회귀 테스트 생성] OK={}, ERR={}/{}", ok, err, subset.len());
    for e in &errors { eprintln!("  ERR: {}", e); }
}

// ─── 내장 바이트코드 패턴 테스트 ─────────────────────────────────────────────

/// 실제 Java 패턴: String 조작 메서드
#[test]
fn test_string_concat_pattern() {
    use c2j::bytecode::decoder::{BytecodeDecoder, InstructionOperand};
    use c2j::bytecode::instruction::Opcode;

    // StringBuilder.append 패턴:
    // new #StringBuilder, dup, invokespecial <init>,
    // aload_0, invokevirtual append, invokevirtual toString
    // 여기서는 간단히 invokevirtual만 테스트
    // invokevirtual #7 = 0xB6, 0x00, 0x07
    let code = vec![0xB6u8, 0x00, 0x07];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs[0].opcode, Opcode::Invokevirtual);
    assert_eq!(instrs[0].operands, InstructionOperand::ConstantPoolIndex(7));
}

/// 실제 Java 패턴: null 체크
#[test]
fn test_null_check_pattern() {
    use c2j::bytecode::decoder::{BytecodeDecoder, InstructionOperand};
    use c2j::bytecode::instruction::Opcode;

    // aload_1, ifnonnull +4, athrow
    // pc: 0=aload_1(1), 1=ifnonnull+4(3), 4=athrow(1)
    let code = vec![
        0x2Bu8,             // aload_1
        0xC7, 0x00, 0x04,  // ifnonnull +4 → pc=5
        0xBF,              // athrow
    ];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert_eq!(instrs[0].opcode, Opcode::Aload1);
    assert_eq!(instrs[1].opcode, Opcode::Ifnonnull);
    assert_eq!(instrs[2].opcode, Opcode::Athrow);
}

/// 실제 Java 패턴: for 루프 (int 배열 순회)
#[test]
fn test_for_loop_pattern() {
    use c2j::bytecode::decoder::BytecodeDecoder;
    use c2j::bytecode::instruction::Opcode;
    use c2j::analysis::cfg::CfgBuilder;

    // int[] arr = new int[n];
    // for (int i = 0; i < arr.length; i++) { ... }
    //
    // 전형적 bytecode:
    // pc=0: iload_0 (n)
    // pc=1: newarray int
    // pc=3: astore_1 (arr)
    // pc=4: iconst_0 → istore_2 (i=0)
    // pc=6: iload_2 → aload_1 → arraylength → if_icmpge +END → body → iinc 2,1 → goto -loop
    let code = vec![
        0x1Au8,              // iload_0        pc=0
        0xBC, 0x0A,          // newarray int   pc=1
        0x3Cu8,              // istore_1       pc=3 (arr)
        0x03u8,              // iconst_0       pc=4
        0x3Du8,              // istore_2       pc=5 (i=0)
        0x1Cu8,              // iload_2        pc=6
        0x2Bu8,              // aload_1        pc=7
        0xBEu8,              // arraylength    pc=8
        0xA2u8, 0x00, 0x07,  // if_icmpge +7  pc=9 → pc=16
        0x84u8, 0x02, 0x01,  // iinc 2,1      pc=12
        0xA7u8, 0xFF, 0xF7,  // goto -9       pc=15 → pc=6
        0xB1u8,              // return         pc=18
    ];
    let instrs = BytecodeDecoder::decode(&code).unwrap();
    assert!(instrs.len() > 5, "명령어 수 부족");

    let cfg = CfgBuilder::build(&instrs, &[]).unwrap();
    let headers = cfg.find_loop_headers();
    assert!(!headers.is_empty(), "루프 헤더 감지 실패 — for 루프 패턴");
}

/// Generic 타입 → Java 소스 변환 통합 테스트
#[test]
fn test_generic_sig_integration() {
    use c2j::analysis::generics::{SignatureParser, generic_type_to_java};

    let cases = vec![
        ("Ljava/util/List<Ljava/lang/String;>;", "List<String>"),
        ("Ljava/util/Map<TK;TV;>;", "Map<K, V>"),
        ("Ljava/util/List<+Ljava/lang/Number;>;", "List<? extends Number>"),
        ("Ljava/util/List<*>;", "List<?>"),
        ("[Ljava/lang/String;", "String[]"),
        ("TT;", "T"),
        ("I", "int"),
    ];

    for (sig, expected) in cases {
        let ty = SignatureParser::parse_field_signature(sig)
            .expect(&format!("파싱 실패: {}", sig));
        let result = generic_type_to_java(&ty);
        assert_eq!(result, expected, "sig={}", sig);
    }
}

/// Text block 복원 통합 테스트
#[test]
fn test_text_block_integration() {
    use c2j::ir::textblock::{string_to_java_literal, try_text_block};

    // SQL 쿼리 패턴
    let sql = "SELECT u.name, u.email\nFROM users u\nWHERE u.active = true\nORDER BY u.name\n";
    let result = string_to_java_literal(sql, true);
    assert!(result.starts_with("\"\"\""), "SQL text block 실패: {}", result);
    assert!(result.contains("SELECT"), "SQL 내용 누락");

    // JSON 패턴
    let json = "{\n  \"key\": \"value\",\n  \"num\": 42\n}\n";
    let result = string_to_java_literal(json, true);
    assert!(result.starts_with("\"\"\""), "JSON text block 실패");

    // 단일 줄은 일반 문자열
    let single = "Hello, World!";
    let result = string_to_java_literal(single, true);
    assert!(result.starts_with('"') && !result.starts_with("\"\"\""),
        "단일 줄이 text block으로 변환됨: {}", result);
}

/// 회귀: 에러 처리 안정성
#[test]
fn test_error_resilience() {
    // 다양한 잘못된 입력에 대해 panic 없이 Err 반환 확인
    let bad_inputs: Vec<Vec<u8>> = vec![
        vec![],
        vec![0x00],
        vec![0xCA, 0xFE, 0xBA, 0xBF],                    // wrong magic
        vec![0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x00],         // truncated
        vec![0xCA, 0xFE, 0xBA, 0xBE, 0x00, 0x00, 0xFF, 0xFF], // bad version
        b"Not a class file at all!".to_vec(),
        vec![0xFF; 100],
    ];

    for (i, input) in bad_inputs.iter().enumerate() {
        let result = ClassFileParser::parse(input);
        assert!(result.is_err(), "입력 {} 에서 Err 기대했으나 Ok 반환", i);
    }
}
