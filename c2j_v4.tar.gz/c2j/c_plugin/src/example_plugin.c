/**
 * example_plugin.c
 *
 * 예제 C 플러그인: monitorenter(0xC2) / monitorexit(0xC3)를
 * Java synchronized 블록 형태의 주석으로 보완합니다.
 *
 * 빌드:
 *   gcc -shared -fPIC -o example_plugin.so example_plugin.c
 *   또는:
 *   g++ -shared -fPIC -o example_plugin.so example_plugin.cpp
 */
#include "../include/c2j_plugin.h"
#include <stdio.h>
#include <string.h>

/* ─── 플러그인 메타 정보 ────────────────────────────────────────────── */

static const uint8_t HANDLED_OPCODES[] = {
    0xC2,   /* monitorenter */
    0xC3,   /* monitorexit  */
    0x00    /* terminator   */
};

static const char *CLASS_PATTERNS[] = { NULL };  /* 모든 클래스 */

static const C2JPluginInfo PLUGIN_INFO = {
    .name            = "SynchronizedPlugin",
    .version         = "1.0.0",
    .handled_opcodes = HANDLED_OPCODES,
    .class_patterns  = CLASS_PATTERNS,
};

const C2JPluginInfo *c2j_plugin_info(void) {
    return &PLUGIN_INFO;
}

/* ─── 명령어 변환 ───────────────────────────────────────────────────── */

C2JTransformResult c2j_transform(const C2JInstrContext *ctx,
                                  char *output, size_t out_cap) {
    if (!ctx || !output || out_cap == 0) return C2J_ERROR;

    switch (ctx->opcode) {
        case 0xC2:   /* monitorenter */
            snprintf(output, out_cap,
                "/* monitorenter: synchronized block start */");
            return C2J_OK;

        case 0xC3:   /* monitorexit */
            snprintf(output, out_cap,
                "/* monitorexit: synchronized block end */");
            return C2J_OK;

        default:
            return C2J_SKIP;
    }
}

/* ─── 클래스 필터 (이 예제는 구현 안 함) ──────────────────────────── */

uint8_t *c2j_class_filter(const char *class_name,
                            const uint8_t *data, size_t len,
                            size_t *out_len) {
    (void)class_name; (void)data; (void)len; (void)out_len;
    return NULL;  /* 변경 없음 */
}

void c2j_free(uint8_t *ptr) {
    free(ptr);
}
