/**
 * lambda_plugin.cpp
 *
 * C++ 플러그인: invokedynamic(0xBA) 을 lambda 표현식으로 변환 보조.
 * LambdaMetafactory bootstrap을 인식하여 더 읽기 좋은 주석을 추가합니다.
 *
 * 빌드:
 *   g++ -std=c++17 -shared -fPIC -o lambda_plugin.so lambda_plugin.cpp
 */
#include "../include/c2j_plugin.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>

extern "C" {

/* ─── 플러그인 메타 정보 ────────────────────────────────────────────── */

static constexpr uint8_t HANDLED_OPCODES[] = {
    0xBA,   /* invokedynamic */
    0x00
};

static const char *CLASS_PATTERNS[] = { nullptr };

static const C2JPluginInfo PLUGIN_INFO = {
    "LambdaPlugin",
    "1.0.0",
    HANDLED_OPCODES,
    CLASS_PATTERNS,
};

const C2JPluginInfo *c2j_plugin_info() {
    return &PLUGIN_INFO;
}

/* ─── invokedynamic → lambda 주석 보조 ─────────────────────────────── */

C2JTransformResult c2j_transform(const C2JInstrContext *ctx,
                                  char *output, size_t out_cap) {
    if (!ctx || ctx->opcode != 0xBA) return C2J_SKIP;

    // 피연산자: 2 바이트 CP 인덱스 + 2 바이트 0
    if (ctx->operand_count < 2) return C2J_SKIP;

    uint16_t cp_idx = (uint16_t)(ctx->operands[0] << 8 | ctx->operands[1]);

    // 주석 형태로 invokedynamic 정보를 남김
    // (실제 CP 접근은 Rust 측에서 이미 처리)
    snprintf(output, out_cap,
        "/* invokedynamic #%u in %s::%s — likely lambda or method reference */",
        cp_idx,
        ctx->class_name ? ctx->class_name : "?",
        ctx->method_name ? ctx->method_name : "?");

    return C2J_OK;
}

uint8_t *c2j_class_filter(const char *, const uint8_t *, size_t, size_t *) {
    return nullptr;
}

void c2j_free(uint8_t *ptr) {
    free(ptr);
}

} // extern "C"
