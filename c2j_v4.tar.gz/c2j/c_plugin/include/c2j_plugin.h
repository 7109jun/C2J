/**
 * c2j_plugin.h — C2J 플러그인 인터페이스
 *
 * 이 헤더를 포함하여 C 또는 C++ 플러그인을 작성하세요.
 * 컴파일: gcc -shared -fPIC -o my_plugin.so my_plugin.c
 */
#ifndef C2J_PLUGIN_H
#define C2J_PLUGIN_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ─── 변환 컨텍스트 ─────────────────────────────────────────────────── */
typedef struct {
    uint32_t    pc;
    uint8_t     opcode;
    const uint8_t *operands;
    size_t      operand_count;
    uint32_t    stack_depth;
    const char *method_name;
    const char *class_name;
} C2JInstrContext;

/* ─── 플러그인 정보 ─────────────────────────────────────────────────── */
typedef struct {
    const char   *name;
    const char   *version;
    const uint8_t *handled_opcodes;   /* 0x00으로 종료 */
    const char  **class_patterns;     /* NULL-terminated */
} C2JPluginInfo;

/* ─── 결과 코드 ─────────────────────────────────────────────────────── */
typedef enum {
    C2J_OK    = 0,
    C2J_SKIP  = 1,
    C2J_ERROR = 2,
} C2JTransformResult;

/* ─── export 함수 ───────────────────────────────────────────────────── */
const C2JPluginInfo *c2j_plugin_info(void);

C2JTransformResult c2j_transform(const C2JInstrContext *ctx,
                                  char *output, size_t out_cap);

uint8_t *c2j_class_filter(const char *class_name,
                            const uint8_t *data, size_t len,
                            size_t *out_len);

void c2j_free(uint8_t *ptr);

#ifdef __cplusplus
}
#endif
#endif /* C2J_PLUGIN_H */
