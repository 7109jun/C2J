#!/usr/bin/env bash
# build_plugins.sh — C2J 플러그인 빌드 스크립트

set -euo pipefail
cd "$(dirname "$0")"

INCLUDE="-I./include"
OUT_DIR="../plugins"
mkdir -p "$OUT_DIR"

echo "[C2J] Building C plugins..."

# C 플러그인
if command -v gcc &>/dev/null; then
    gcc -std=c11 -shared -fPIC -O2 \
        $INCLUDE \
        -o "$OUT_DIR/example_plugin.so" \
        src/example_plugin.c
    echo "  ✓ example_plugin.so"
fi

# C++ 플러그인
if command -v g++ &>/dev/null; then
    g++ -std=c++17 -shared -fPIC -O2 \
        $INCLUDE \
        -o "$OUT_DIR/lambda_plugin.so" \
        src/lambda_plugin.cpp
    echo "  ✓ lambda_plugin.so"
fi

echo "[C2J] Plugins built in $OUT_DIR/"
echo ""
echo "사용법:"
echo "  c2j Example.class --plugin-dir $OUT_DIR"
