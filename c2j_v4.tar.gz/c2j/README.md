# C2J — Class To Java Decompiler

JVM `.class` 파일을 재컴파일 가능한 `.java` 소스 코드로 변환하는 **프로덕션급 디컴파일러**입니다.

## 핵심 원칙

> `.class → C2J → .java → javac → .class`  
> 변환 전후 **관찰 가능한 실행 동작이 동일**해야 한다.

원본 소스의 변수명/주석/스타일 복원보다 **동작 의미 보존**이 최우선입니다.

---

## 특징

| 기능 | 상태 |
|---|---|
| Java 8~22 완전 지원 (major 52~66) | ✅ |
| JVM 202개 Bytecode opcode 디코딩 | ✅ |
| Operand Stack 시뮬레이션 | ✅ |
| Control Flow Graph (루프/분기/switch) | ✅ |
| goto/label → if/while/for/switch 구조화 | ✅ |
| new+dup+invokespecial → NewObject 합성 | ✅ |
| invokedynamic → lambda/method-reference | ✅ |
| try/catch/finally 복원 | ✅ |
| Generic Signature 완전 복원 | ✅ |
| Java 15+ Text Block 복원 | ✅ |
| Java 17 Record / Sealed class | ✅ |
| Java 21 Pattern Switch 감지 | ✅ |
| C/C++ 플러그인 시스템 (dlopen FFI) | ✅ |
| javac 컴파일 검증 (`--verify`) | ✅ |
| 디렉토리 일괄 처리 | ✅ |

---

## 빌드

```bash
# Rust 설치 (https://rustup.rs)
cargo build --release

# 바이너리: target/release/c2j
```

---

## 사용법

```bash
# 단일 파일 변환
c2j Example.class

# 출력 경로 지정
c2j Example.class -o Output.java

# 디렉토리 일괄 변환
c2j classes/ -o src/

# 컴파일 검증 (javac 필요)
c2j Example.class --verify

# 클래스 파일 정보 출력
c2j Example.class --info --verbose

# 플러그인 사용
c2j Example.class --plugin-dir ./plugins

# 디버그 모드 (생성된 소스 미리보기)
c2j Example.class --debug

# Java 버전 타겟 지정
c2j Example.class --java-version 21
```

---

## 아키텍처

```
.class 파일
    ↓
ClassFile Parser          classfile/parser.rs
    ↓
Constant Pool 분석        constantpool/mod.rs
    ↓
Bytecode Decoder          bytecode/decoder.rs   (202개 opcode)
    ↓
Control Flow Graph        analysis/cfg.rs
    ↓
Stack 분석                analysis/stack.rs
    ↓
Local Variable 분석       analysis/locals.rs
    ↓
Exception 분석            analysis/exception.rs
    ↓
IR 변환 (IrBuilder)      ir/conversion.rs
    ↓
new 합성                  ir/new_synthesis.rs
    ↓
제어문 구조화             ir/structurizer.rs
    ↓
lambda 복원               ir/lambda.rs
    ↓
Generic Signature         analysis/generics.rs
    ↓
Java 코드 생성            generator/code_gen.rs
                          generator/structured_gen.rs
    ↓
Text Block 복원           ir/textblock.rs
    ↓
검증 (선택)               verifier/mod.rs
    ↓
.java 파일
```

---

## 플러그인 개발 (C/C++)

`c_plugin/include/c2j_plugin.h` 헤더를 포함하여 플러그인을 작성합니다.

```c
#include "c2j_plugin.h"

static const uint8_t OPCODES[] = { 0xC2, 0xC3, 0x00 };  // monitorenter, monitorexit

static const C2JPluginInfo INFO = {
    .name            = "MyPlugin",
    .version         = "1.0.0",
    .handled_opcodes = OPCODES,
};

const C2JPluginInfo *c2j_plugin_info(void) { return &INFO; }

C2JTransformResult c2j_transform(const C2JInstrContext *ctx,
                                  char *out, size_t cap) {
    snprintf(out, cap, "/* custom: opcode 0x%02X */", ctx->opcode);
    return C2J_OK;
}
```

빌드:
```bash
gcc -shared -fPIC -o my_plugin.so my_plugin.c
c2j Example.class --plugin-dir .
```

---

## 테스트

```bash
# 단위 + 통합 테스트
cargo test

# 특정 테스트
cargo test test_cfg_branch
cargo test test_generic_sig
cargo test test_text_block

# JDK 회귀 테스트 (JDK 설치 필요)
cargo test test_jdk_classes
```

---

## 지원하는 Java 기능

### 타입
- 모든 기본 타입 (byte, short, int, long, float, double, char, boolean)
- 참조 타입, 배열, null
- Generic (List<T>, Map<K,V>, ? extends, ? super, ?)

### 제어문
- if / if-else / else-if
- while / do-while / for
- switch (표준 + Java 21 pattern switch)
- try / catch / finally / multi-catch
- break / continue (레이블 포함)
- synchronized

### 객체
- 클래스 / 인터페이스 / 열거형
- Java 16 Record
- Java 17 Sealed class + permits
- Inner class / Anonymous class / Static nested class

### 메서드
- 생성자 (super()/this() 포함)
- 정적/인스턴스/추상/native 메서드
- varargs
- lambda / method reference (Java 8+)

### 기타
- Annotation 보존
- String concatenation (+ 연산자 복원)
- Java 15 Text Block 복원
- Generic Signature 완전 복원

---

## 구현 언어

- **Rust** (주요 구현 — ~8700줄)
- **C/C++** (플러그인 인터페이스)

외부 의존성 최소화 (`byteorder`, `thiserror`, `clap`, `libc`만 사용).

---

## 라이선스

MIT
